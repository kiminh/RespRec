Evaluating Trauma Patients: Addressing Missing Covariates with Joint Optimization.

https://www.flyertea.com/thread-2461201-1-1.html

RuntimeError: LaTeX was not able to process the following string:
b'lp'
->
sudo apt-get install texlive-full

## double robust recommendation

Each poster board is 4 feet tall and 8 feet wide.

https://github.com/JoonyoungYi/BiasedMF-tensorflow
https://github.com/xmuffin/cupcake

coat_fm devel/run_drrec.sh
coat_nfm devel/run_drrec.sh
song_fm devel/script/song_drrec.sh
song_nfm drrec/run_nmf.sh

scp -r xiaojie@10.100.229.246:/home/xiaojie/Projects/librec/runs .
scp -r xiaojie@10.100.229.246:/home/xiaojie/Downloads/Webscope_R3 .
scp -r xiaojie@10.100.228.220:/home/xiaojie/Projects/drrec/autorec/amazon .
scp -r xiaojie@10.100.228.220:/home/xiaojie/Projects/drrec/autorec/movie .

#### server

ssh xiaojie@10.100.229.246 # cpu
ssh xiaojie@10.100.228.220 # gpu xw
ssh xiaojie@10.100.228.158 # gpu cz

pip install tensorflow-gpu==1.4.1

#### neumf tensorflow
pip install keras==2.1.4 tensorflow==1.7 sklearn==0.0
pip install keras==1.0.7 theano==0.8.0

https://github.com/chentingpc/NNCF
https://github.com/Tbbaby/cikm17-NNCF
https://github.com/enningxie/Neural-Collaborative-Filtering

python -W ignore mlp.py

#### neufm tensorflow
pip install tensorflow==0.12.0
pip install tensorflow-gpu==0.12.0
pip install sklearn==0.0

python NeuralFM.py --dataset song --hidden_factor 64 --layers '[64]' --keep_prob '[0.8,0.5]' --loss_type square_loss --activation relu --pretrain 0 --optimizer AdagradOptimizer --lr 0.05 --batch_norm 1 --verbose 1 --early_stop 1 --epoch 200

#### Transcript
Introductory Programming	4	92
Mathematical Analysis 1	6	93
Higher Algebra 1	5	90
The Practice of Programming	2	90
Higher Algebra 2	4	95
Mathematical Analysis 2	5	93
Data Structure	4	90
Discrete Mathematics	4	92
Mathematical Analysis 3	5	94
Computer Organization	4	91
Real Variable Function	4	99
Object-oriented Programming	3	89
Digital Logic Circuit	3	91
Probability Theory	4	100
Introduction to Database Systems	4	86
Mathematical Programming	4	95
Operation Research	3	89
Mathematical Modeling	2	100
Ordinary Differential Analysis	4	95
Operating Systems	4	95
Functional Analysis	3	93
Mathematical Statistics	4	94
Algorithm Design and Analysis	3	96
Stochastic Processes	3	100
Complex Analysis	3	90
Introduction to Parallel Computing	2	92
Database Design Practice	2	90
Principles of Compiler Design	3	94
Graph Theory	2	90
Combinatorial Mathematics	2	98
Software Engineering	3	95
Time Series Analysis	2	92
Computer Networks	4	90
Graduation Thesis	4	99
Social Survey and Professional Intership	4	98








### FACEBOOK 
internships_phdstudent@fb.com

TWITTER 
http://t.co/apply 
https://careers.twitter.com/en/work-for-twitter/201808/2019-university-application-full-time-internship.html

### AMAZON 
amazon.jobs/NeurIPS
https://www.amazon.jobs/en/landing_pages/NeurIPS 
NeurIPS2018@amazon.com
amazon job dashboard

### GOOGLE 
chaiwei@google.com 
https://careers.google.com/students/
https://careers.google.com/

### QUANTUMBLACK

### UBER

### WAYFAIR

### JUMP TRADING (Intern Full) 
conferences@jumptrading.com

### D.E. SHAW (Intern Full) 
https://www.deshaw.com/careers/3676
https://www.deshaw.com/careers/3677

### J.P. MORGAN (Intern Full) 
andrea.stefanucci@jpmorgan.com

### TWO SIGMA (Intern Full) 
https://www.twosigma.com/NeurIPS/ 
https://careers.twosigma.com/eventsignup/Events 
https://twosigma.avature.net/eventsignup/eventDetail/Montreal-Montreal-Canada-NeurIPS-2018/4753

BLOOMBERG (Intern) 
jcarberry7@bloomberg.net

CUBIST SYSTEMATIC STRATEGIES (Intern) 
jackie.dai@cubistsystematic.com

################################################################
# no interest
################################################################
IBM RESEARCH
MICROSOFT
CAPITAL ONE
JANE STREET

################################################################
# no intern visa
################################################################
CITADEL
https://www.citadel.com/careers/open-positions/positions-for-students/
Hong Kong

MORGAN STANLEY
AIMLrecruiting@MS.com

################################################################
# no us intern
################################################################
DEEPMIND
https://deepmind.com/careers/

################################################################
# no intern
################################################################
NETFLIX
VOLEON

################################################################
# D.E. SHAW
################################################################
www.deshaw.com/recruit/jobs/SP/NIPSConference

Primary Phone
->
+61 406796247

Please specify your Degree:
->
Bachelor of Science and Bachelor of Engineering

Other Scores
->
IELTS Year: 2015 Total: 7.5

Please list any other awards or significant accomplishments you feel are relevant
->
1. Google Excellence Scholarship, 2015 (only 60 university students in China)
2. Meritorious Winner, American Mathematical Contest in Modeling, 2015 (Top10%)
3. Study Excellence Scholarship, Renmin University of China, 2013–2015 (Top5%)
4. National First Price, Chinese Mathematical Olympiad in Senior, 2011

Please list your most recent employer first.
->
Research Assistant at Renmin University of China, Sep 2014–Jul 2016

Will you require the firm's sponsorship to obtain, maintain, or extend your employment authorization in the location(s) for which you are applying?
->
I am a Chinese citizen. I am now holding a student visa (500) in Australia. I hope I could have the opportunity to collaborate with the analysts and bring my unique skills into the team in New York.

If your work has appeared in any peer­ reviewed publications, please list up to three examples you're especially proud of, indicating author names, article title, journal name, and date of publication.
->
1. Xiaojie Wang, Rui Zhang, Yu Sun, Jianzhong Qi. KDGAN: Knowledge Distillation with Generative Adversarial Networks. The 32nd Conference on Neural Information Processing Systems (NeurIPS), 2018.
2. Xiaojie Wang, Ji-Rong Wen, Zhicheng Dou, Tetsuya Sakai, Rui Zhang. Search Result Diversity Evaluation based on Intent Hierarchies. IEEE Transactions on Knowledge and Data Engineering (TKDE), 2018.
3. XiaojieWang, Zhicheng Dou, Tetsuya Sakai, Ji-RongWen. Evaluating Search Result Diversity using Intent Hierarchies. The 39th International ACM SIGIR conference on Research and Development in Information Retrieval (SIGIR), 2016.

What are the most advanced scientific, technical, or quantitative courses you've completed?
->
1. Probability Theory: 100/100
2. Stochastic Processes: 100/100
3. Mathematical Modeling: 100/100
4. Ordinary Differential Equations: 95/100
5. Mathematical Statistics: 94/100
6. Time Series Analysis: 92/100
7. Operation Research: 89/100
8. Microeconomics: 96/100

How large (in terms of number of lines of code) was the largest programming project you've worked on? What percentage of the project was your contribution? What programming languages were used? Briefly describe the purpose and functionality of the project.
->
The largest programming project I have worked on is about 50,000 lines of code. My contribution to the project is about 40 percent. We use JavaScript and Python for building frontend and backend systems, respectively. The purpose of the project is to help administrators determine prices for goods and manage promoted goods in an online shopping website (https://www.glbuyer.com/). The functionality of the project mainly includes (1) crawling the original prices and the sale prices for a type of goods from different online retailers; (2) analyzing the crawled prices to help administrators find the lowest price and the most discounted goods.

################################################################
# J.P. MORGAN
################################################################
jp morgan my jobpage
https://jpmchase.taleo.net/careersection/10140/mysubmissions.ftl

################################################################
# TWO SIGMA
################################################################
https://twosigma.avature.net/eventsignup/Profile

################################################################
# AMAZON
################################################################
https://resumegenius.com/cover-letters-the-how-to-guide
https://www.amazon.jobs/en/jobs/714754/applied-scientist-intern-machine-learning

To whom it may concern,

My name is Xiaojie Wang. I am writing to apply for the Applied Scientist Intern (Machine Learning) at your company. After reviewing your internship description, I believe that I have the necessary skills and abilities to do the internship.

I am a third-year Ph.D. student majoring in Computer Science at University of Melbourne. My research interests include Machine Learning, Data Mining, Recommendation Systems, and Information Retrieval. While working on academic and extracurricular projects, I have developed proven communication and teamwork skills, which I hope to leverage into implementing state-of-the-art solutions for challenging problems at your company.

After reviewing my resume, I hope you will agree that I am the type of competent and reliable candidate that you are looking for. I look forward to elaborating on how I can do the internship well and help benefit your company. Please contact me at +61 406796247 or via email at xiaojiew94@gmail.com to arrange for a convenient meeting time.

Thank you for your consideration, and I look forward to hearing from you soon.

Best regards,
Xiaojie Wang
