from utils import *
from autorec import AutoRec
from os import path
import tensorflow as tf
import time
import argparse
import pickle

current_time = time.time()

parser = argparse.ArgumentParser(description='I-AutoRec ')
parser.add_argument('--base_dir', default='../data/amazon/amazon.autorec')

parser.add_argument('--hidden_neuron', type=int, default=500)
parser.add_argument('--lambda_value', type=float, default=0.5)

parser.add_argument('--train_epoch', type=int, default=1000)
parser.add_argument('--batch_size', type=int,default=1000)

parser.add_argument('--optimizer_method', choices=['Adam','RMSProp'],default='Adam')
parser.add_argument('--grad_clip', type=bool,default=True)
parser.add_argument('--base_lr', type=float, default=1e-3)
parser.add_argument('--decay_epoch_step', type=int, default=50,
	help="decay the learning rate for each n epochs")
parser.add_argument('--decay_rate', type=float, default=0.96,
  help="decay rate the learning rate")

parser.add_argument('--random_seed', type=int, default=1000)
parser.add_argument('--display_step', type=int, default=1)

args = parser.parse_args()
tf.set_random_seed(args.random_seed)
np.random.seed(args.random_seed)

data_name = 'ml-1m'; num_users = 6040; num_items = 3952; num_total_ratings = 1000209; train_ratio = 0.9
# path = "./data/%s" % data_name + "/"
# path = path.expanduser('~/Downloads/ml-1m/')
# path = path.expanduser('~/Projects/drrec/data/coat/coat.autorec')
# path = path.expanduser('~/Projects/drrec/data/amazon/amazon.autorec')
base_dir = args.base_dir

meta_data_file = base_dir + '.meta.data'
meta_data = pickle.load(open(meta_data_file, 'rb'))
num_users = meta_data['num_users']
num_items = meta_data['num_items']
train_size = meta_data['train_size']
test_size = meta_data['test_size']

result_path = './results/' + data_name + '/' + str(args.random_seed) + '_' + str(args.optimizer_method) + '_' + str(args.base_lr) + "_" + str(current_time)+"/"
R, mask_R, C, train_R, train_mask_R, test_R, test_mask_R,num_train_ratings,num_test_ratings,\
user_train_set,item_train_set,user_test_set,item_test_set \
    = read_rating(base_dir, num_users, num_items, train_size, test_size, 1, 0)

config = tf.ConfigProto()
config.gpu_options.allow_growth=True
with tf.Session(config=config) as sess:
    AutoRec = AutoRec(sess,args,
                      num_users,num_items,
                      R, mask_R, C, train_R, train_mask_R, test_R, test_mask_R,num_train_ratings,num_test_ratings,
                      user_train_set, item_train_set, user_test_set, item_test_set,
                      result_path)
    AutoRec.run()