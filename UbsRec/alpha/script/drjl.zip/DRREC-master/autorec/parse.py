from os import path
import argparse
import os

def main():
  parser = argparse.ArgumentParser()
  parser.add_argument('result_dir', type=str)
  args = parser.parse_args()
  result_dir = args.result_dir

  for file_name in os.listdir(result_dir):
    file_path = path.join(result_dir, file_name)
    with open(file_path) as fin:
      for line in fin.readlines():
        fields = line.strip().split()
        mae = fields[1]
        mse = fields[2]
        print('%s\t%s' % (mae, mse))

if __name__ == '__main__':
  main()