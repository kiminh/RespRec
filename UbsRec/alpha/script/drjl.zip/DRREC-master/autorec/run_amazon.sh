export CUDA_VISIBLE_DEVICES=''
dataset=amazon

out_dir=${dataset}
# rm -rf ${out_dir}
# mkdir -p ${out_dir}

lambda_value_list='0.1 0.5 1.0'
lambda_value_list='1.0 0.5 0.1'
hidden_neuron_list='100 500 1000'
hidden_neuron_list='1000 500 100'

train_epoch=100
base_lr=1e-3
decay_rate=0.96
batch_size_list='1000'
decay_epoch_step_list='20 50'
decay_epoch_step_list='50 20'
for hidden_neuron in ${hidden_neuron_list}
do
  for lambda_value in ${lambda_value_list}
  do
    for batch_size in ${batch_size_list}
    do
      for decay_epoch_step in ${decay_epoch_step_list}
      do

out_file=${out_dir}/${dataset}_${hidden_neuron}_${lambda_value}
out_file=${out_file}_${batch_size}_${decay_epoch_step}.csv
if [ -f ${out_file} ]
then
  echo 'find' ${out_file}
  continue
fi
echo 'not find' ${out_file}
python -W ignore main.py \
  --base_dir ~/Projects/drrec/data/${dataset}/${dataset}.autorec \
  --display_step 1 \
  --random_seed 1000 \
  --hidden_neuron ${hidden_neuron} \
  --lambda_value ${lambda_value} \
  --optimizer_method Adam \
  --grad_clip True \
  --train_epoch ${train_epoch} \
  --base_lr ${base_lr} \
  --decay_rate ${decay_rate} \
  --batch_size ${batch_size} \
  --decay_epoch_step ${decay_epoch_step} \
  > ${out_file}

      done
    done
  done
done
exit

python -W ignore main.py \
  --base_dir ~/Projects/drrec/data/amazon/amazon.autorec \
  --hidden_neuron 500 \
  --lambda_value 0.5 \
  --train_epoch 100 \
  --batch_size 1000 \
  --optimizer_method Adam \
  --grad_clip True \
  --base_lr 1e-3 \
  --decay_epoch_step 50 \
  --decay_rate 0.96 \
  --random_seed 1000 \
  --display_step 1
exit
