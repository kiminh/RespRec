dataset=movie

out_dir=${dataset}
# rm -rf ${out_dir}
# mkdir -p ${out_dir}

lambda_value_list='0.1 0.5 1.0'
hidden_neuron_list='100 500 1000'

train_epoch=1000
base_lr=1e-3
decay_rate=0.96
batch_size_list='500 5000'
decay_epoch_step_list='2 10'
for hidden_neuron in ${hidden_neuron_list}
do
  for lambda_value in ${lambda_value_list}
  do
    for batch_size in ${batch_size_list}
    do
      for decay_epoch_step in ${decay_epoch_step_list}
      do

out_file=${out_dir}/${dataset}_${hidden_neuron}_${lambda_value}
out_file=${out_file}_${batch_size}_${decay_epoch_step}.csv
echo ${out_file}

python -W ignore main.py \
  --base_dir ~/Projects/drrec/data/${dataset}/${dataset}.autorec \
  --display_step 1 \
  --random_seed 1000 \
  --hidden_neuron ${hidden_neuron} \
  --lambda_value ${lambda_value} \
  --optimizer_method Adam \
  --grad_clip True \
  --train_epoch ${train_epoch} \
  --base_lr ${base_lr} \
  --decay_rate ${decay_rate} \
  --batch_size ${batch_size} \
  --decay_epoch_step ${decay_epoch_step} \
  > ${out_file}

      done
    done
  done
done
exit
