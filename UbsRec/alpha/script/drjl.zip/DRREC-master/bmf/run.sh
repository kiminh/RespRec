# export CUDA_VISIBLE_DEVICES=''
python run.py
