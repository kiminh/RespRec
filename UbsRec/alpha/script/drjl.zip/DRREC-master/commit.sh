git add --all
git commit -am 'x'
git push

