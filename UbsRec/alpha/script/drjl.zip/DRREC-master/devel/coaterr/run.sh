pretrain_epochs=60

verbose=1
batch_norm=0
batch_size=64 # 128
num_factors=128
keep_probs='[0.6]'
all_reg_coeff=0.001
pred_learning_rate=0.4 # 0.5
impt_learning_rate=0.4 # 0.5
optimizer_type=sgd # adagrad
impt_weight=1e-3
impt_rating=2.0
python -W ignore drrec.py \
    --base_dir ~/Projects/drrec/data/song/song \
    --verbose ${verbose} \
    --pretrain_epochs ${pretrain_epochs} \
    --interact_epochs 100 \
    --num_impt_epochs 200 \
    --num_pred_epochs 10 \
    --pred_model_name mf \
    --impt_model_name mf \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_learning_rate ${impt_learning_rate} \
    --optimizer_type ${optimizer_type} \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs} \
    --impt_weight ${impt_weight} \
    --impt_rating ${impt_rating}



