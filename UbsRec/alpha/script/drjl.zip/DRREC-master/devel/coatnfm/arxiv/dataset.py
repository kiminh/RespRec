import utils

from os import path
import itertools
import numpy as np

class Dataset(object):
  '''user id and item id start from zero'''
  def __init__(self, data_dir):
    train_file = path.join(data_dir, 'train.rating')
    test_file = path.join(data_dir, 'test.rating')
    user_feature_file = path.join(data_dir, 'user.feature')
    item_feature_file = path.join(data_dir, 'item.feature')

    train_data = self.load_rating_data(train_file)
    self.train_users, self.train_items, self.train_ratings = train_data

    test_data = self.load_rating_data(test_file)
    self.test_users, self.test_items, self.test_ratings = test_data

    self.num_users = max(self.train_users) + 1
    self.num_items = max(self.train_items) + 1

    self.train_size = len(self.train_ratings)
    self.train_weights = np.ones((self.train_size,))

    self.user_feature = utils.load_feature(user_feature_file)
    self.item_feature = utils.load_feature(item_feature_file)

  def load_rating_data(self, file_path):
    users, items, ratings = [], [], []
    with open(file_path, 'r') as fin:
      line = fin.readline()
      while line is not None and line != '':
        arr = line.strip().split()
        user, item, rating = int(arr[0]), int(arr[1]), float(arr[2])
        users.append(user)
        items.append(item)
        ratings.append(rating)
        line = fin.readline()
    users = np.asarray(users)
    items = np.asarray(items)
    ratings = np.asarray(ratings)
    return users, items, ratings

if __name__ == '__main__':
  data_dir = '../data/ml-1m'
  data_dir = '../data/coat'
  dataset = Dataset(data_dir)
  print('#users=%d #items=%d' % (dataset.num_users, dataset.num_items))
  print('train#ratings=%d' % (len(dataset.train_ratings)))
  print('test#ratings=%d' % (len(dataset.test_ratings)))

