from dataset import Dataset

from sklearn import metrics
import numpy as np
import tensorflow as tf

data_dir = '../data/coat'
num_factors = 64
learning_rate = 0.1
reg_all = 0.001 # 0.05 is a bad choice
num_epochs = 100
num_epochs_hat = 100
batch_size = 16

dataset = Dataset(data_dir)
num_users, num_items = dataset.num_users, dataset.num_items
train_size, test_size = dataset.train_size, dataset.test_size

user_input = tf.placeholder(tf.int32, shape=(None,))
item_input = tf.placeholder(tf.int32, shape=(None,))
rating_label = tf.placeholder(tf.float32, shape=(None,))

mean, stddev = 0.0, 0.1
user_initializer = tf.random_normal((num_users, num_factors),
                                    mean=mean,
                                    stddev=stddev,)
item_initializer = tf.random_normal((num_items, num_factors),
                                    mean=mean,
                                    stddev=stddev,)
user_embedding = tf.get_variable('user_embedding',
                                 initializer=user_initializer)
item_embedding = tf.get_variable('item_embedding',
                                 initializer=item_initializer)
user_embedding_hat = tf.get_variable('user_embedding_hat',
                                     initializer=user_initializer)
item_embedding_hat = tf.get_variable('item_embedding_hat',
                                     initializer=item_initializer)

user_latent = tf.nn.embedding_lookup(user_embedding, user_input)
item_latent = tf.nn.embedding_lookup(item_embedding, item_input)
user_latent_hat = tf.nn.embedding_lookup(user_embedding_hat, user_input)
item_latent_hat = tf.nn.embedding_lookup(item_embedding_hat, item_input)

pred_op = tf.multiply(user_latent, item_latent)
pred_op = tf.reduce_sum(pred_op, axis=1)
pred_op_hat = tf.multiply(user_latent_hat, item_latent_hat)
pred_op_hat = tf.reduce_sum(pred_op_hat, axis=1)

error_op = tf.losses.mean_squared_error(rating_label, pred_op)
error_op += tf.losses.mean_squared_error(pred_op_hat, pred_op)
loss_op = tf.add_n([error_op,
                   reg_all * tf.nn.l2_loss(user_embedding),
                   reg_all * tf.nn.l2_loss(item_embedding)])

error_label = tf.square(pred_op - rating_label)
error_pred = tf.square(pred_op - pred_op_hat)
# error_op_hat = tf.losses.mean_squared_error(error_label, pred_op_hat)
error_op_hat = tf.losses.mean_squared_error(error_label, error_pred)
loss_op_hat = tf.add_n([error_op_hat,
                       0.0001 * tf.nn.l2_loss(user_embedding_hat),
                       0.0001 * tf.nn.l2_loss(item_embedding_hat)]) 

optimizer = tf.train.GradientDescentOptimizer(learning_rate)
var_list = [user_embedding, item_embedding]
update_op = optimizer.minimize(loss_op,
                               var_list=var_list)

optimizer_hat = tf.train.GradientDescentOptimizer(0.01)
var_list_hat = [user_embedding_hat, item_embedding_hat]
update_op_hat = optimizer_hat.minimize(loss_op_hat,
                                       var_list=var_list_hat)

def get_train_data(train_matrix):
  user_input, item_input, ratings = [], [], []
  for (user, item) in train_matrix.keys():
      user_input.append(user)
      item_input.append(item)
      rating = train_matrix[user, item]
      ratings.append(rating)
  return user_input, item_input, ratings

init_op = tf.global_variables_initializer()
with tf.train.MonitoredTrainingSession() as sess:
  sess.run(init_op)

  for epoch in range(num_epochs):
    indexes = np.arange(train_size)
    np.random.shuffle(indexes)

    num_batches = train_size // batch_size

    error = 0
    for batch in range(num_batches):
      start = batch * batch_size
      stop = (batch + 1) * batch_size

      users = dataset.train_users[indexes[start:stop]]
      items = dataset.train_items[indexes[start:stop]]
      ratings = dataset.train_ratings[indexes[start:stop]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_label:ratings}
      results = sess.run([update_op, error_op], feed_dict=feed_dict)
      error += results[1] * (stop - start)
    if stop < train_size:
      users = dataset.train_users[indexes[stop:train_size]]
      items = dataset.train_items[indexes[stop:train_size]]
      ratings = dataset.train_ratings[indexes[stop:train_size]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_label:ratings}
      results = sess.run([update_op, error_op], feed_dict=feed_dict)
      error += results[1] * (stop - start)

    feed_dict = {user_input:dataset.test_users,
                 item_input:dataset.test_items}
    predictions = sess.run(pred_op, feed_dict=feed_dict)
    mae = metrics.mean_absolute_error(dataset.test_ratings, predictions)
    mse = metrics.mean_squared_error(dataset.test_ratings, predictions)
    error /= train_size
    print('#%d mae=%.4f mse=%.4f error=%.4f' % (epoch, mae, mse, error))

    for _ in range(num_epochs_hat):
      error_hat = 0.0
      for batch in range(num_batches):
        start = batch * batch_size
        stop = (batch + 1) * batch_size

        users = dataset.train_users[indexes[start:stop]]
        items = dataset.train_items[indexes[start:stop]]
        ratings = dataset.train_ratings[indexes[start:stop]]
        feed_dict = {user_input:users,
                     item_input:items,
                     rating_label:ratings}
        results = sess.run([update_op_hat, error_op_hat],
                           feed_dict=feed_dict)
        error_hat += results[1] * (stop - start)
      if stop < train_size:
        users = dataset.train_users[indexes[stop:train_size]]
        items = dataset.train_items[indexes[stop:train_size]]
        ratings = dataset.train_ratings[indexes[stop:train_size]]
        feed_dict = {user_input:users,
                     item_input:items,
                     rating_label:ratings}
        results = sess.run([update_op_hat, error_op_hat],
                           feed_dict=feed_dict)
        error_hat += results[1] * (train_size - stop)
    print('\t', 'error_hat=%.4f' % (error_hat / train_size))



