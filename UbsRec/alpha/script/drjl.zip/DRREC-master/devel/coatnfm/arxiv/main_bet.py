from dataset import Dataset

from sklearn import metrics
import numpy as np
import tensorflow as tf

data_dir = '../data/coat'
num_factors = 64
batch_size = 16
rp_learning_rate = 0.1
ei_learning_rate = 0.05
rp_reg_coeff = 0.001
ei_reg_coeff = 0.0005
rp_num_epochs = 200
ei_num_epochs = 0

dataset = Dataset(data_dir)
num_users, num_items = dataset.num_users, dataset.num_items
train_size, test_size = dataset.train_size, dataset.test_size

user_input = tf.placeholder(tf.int32, shape=(None,))
item_input = tf.placeholder(tf.int32, shape=(None,))
rating_input = tf.placeholder(tf.float32, shape=(None,))

mean, stddev = 0.0, 0.1
user_initializer = tf.random_normal((num_users, num_factors),
                                    mean=mean,
                                    stddev=stddev,)
item_initializer = tf.random_normal((num_items, num_factors),
                                    mean=mean,
                                    stddev=stddev,)

rp_user_embedding = tf.get_variable('rp_user_embedding',
                                    initializer=user_initializer)
rp_item_embedding = tf.get_variable('rp_item_embedding',
                                    initializer=item_initializer)
ei_user_embedding = tf.get_variable('ei_user_embedding',
                                    initializer=user_initializer)
ei_item_embedding = tf.get_variable('ei_item_embedding',
                                    initializer=item_initializer)

rp_user_latent = tf.nn.embedding_lookup(rp_user_embedding, user_input)
rp_item_latent = tf.nn.embedding_lookup(rp_item_embedding, item_input)
ei_user_latent = tf.nn.embedding_lookup(ei_user_embedding, user_input)
ei_item_latent = tf.nn.embedding_lookup(ei_item_embedding, item_input)

rp_pred_op = tf.multiply(rp_user_latent, rp_item_latent)
rp_pred_op = tf.reduce_sum(rp_pred_op, axis=1)
ei_pred_op = tf.multiply(ei_user_latent, ei_item_latent)
ei_pred_op = tf.reduce_sum(ei_pred_op, axis=1)

rp_error_op = tf.losses.mean_squared_error(rating_input, rp_pred_op)
rp_loss_op = tf.add_n([rp_error_op,
                      rp_reg_coeff * tf.nn.l2_loss(rp_user_embedding),
                      rp_reg_coeff * tf.nn.l2_loss(rp_item_embedding)])

error_label = rating_input - rp_pred_op
ei_error_op = tf.losses.mean_squared_error(error_label, ei_pred_op)
ei_loss_op = tf.add_n([ei_error_op,
                      ei_reg_coeff * tf.nn.l2_loss(ei_user_embedding),
                      ei_reg_coeff * tf.nn.l2_loss(ei_item_embedding)]) 

rp_optimizer = tf.train.GradientDescentOptimizer(rp_learning_rate)
rp_var_list = [rp_user_embedding, rp_item_embedding]
rp_update_op = rp_optimizer.minimize(rp_loss_op,
                                     var_list=rp_var_list)

ei_optimizer = tf.train.GradientDescentOptimizer(ei_learning_rate)
ei_var_list = [ei_user_embedding, ei_item_embedding]
ei_update_op = ei_optimizer.minimize(ei_loss_op,
                                     var_list=ei_var_list)

init_op = tf.global_variables_initializer()
with tf.train.MonitoredTrainingSession() as sess:
  sess.run(init_op)

  best_mae, best_mse, best_epoch = None, None, None

  for rp_epoch in range(rp_num_epochs):
    indexes = np.arange(train_size)
    np.random.shuffle(indexes)

    num_batches = train_size // batch_size
    rp_error = 0
    for batch in range(num_batches):
      start = batch * batch_size
      stop = (batch + 1) * batch_size

      users = dataset.train_users[indexes[start:stop]]
      items = dataset.train_items[indexes[start:stop]]
      ratings = dataset.train_ratings[indexes[start:stop]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_input:ratings}
      results = sess.run([rp_update_op, rp_error_op], feed_dict=feed_dict)
      rp_error += results[1] * (stop - start)
    if stop < train_size:
      users = dataset.train_users[indexes[stop:train_size]]
      items = dataset.train_items[indexes[stop:train_size]]
      ratings = dataset.train_ratings[indexes[stop:train_size]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_input:ratings}
      results = sess.run([rp_update_op, rp_error_op], feed_dict=feed_dict)
      rp_error += results[1] * (stop - start)

    feed_dict = {user_input:dataset.test_users,
                 item_input:dataset.test_items}
    rp_preds = sess.run(rp_pred_op, feed_dict=feed_dict)
    mae = metrics.mean_absolute_error(dataset.test_ratings, rp_preds)
    mse = metrics.mean_squared_error(dataset.test_ratings, rp_preds)
    rp_error /= train_size
    print('#%d mae=%.4f mse=%.4f rp=%.4f' % (rp_epoch, mae, mse, rp_error))

    if best_mse == None or mse < best_mse:
      best_mae = mae
      best_mse = mse
      best_epoch = '#%d' % (rp_epoch)

  for ei_epoch in range(ei_num_epochs):
    indexes = np.arange(train_size)
    np.random.shuffle(indexes)

    num_batches = train_size // batch_size
    ei_error = 0
    for batch in range(num_batches):
      start = batch * batch_size
      stop = (batch + 1) * batch_size

      users = dataset.train_users[indexes[start:stop]]
      items = dataset.train_items[indexes[start:stop]]
      ratings = dataset.train_ratings[indexes[start:stop]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_input:ratings}
      results = sess.run([ei_update_op, ei_error_op], feed_dict=feed_dict)
      ei_error += results[1] * (stop - start)
    if stop < train_size:
      users = dataset.train_users[indexes[stop:train_size]]
      items = dataset.train_items[indexes[stop:train_size]]
      ratings = dataset.train_ratings[indexes[stop:train_size]]
      feed_dict = {user_input:users,
                   item_input:items,
                   rating_input:ratings}
      results = sess.run([ei_update_op, ei_error_op], feed_dict=feed_dict)
      ei_error += results[1] * (stop - start)

    feed_dict = {user_input:dataset.test_users,
                 item_input:dataset.test_items}
    results = sess.run([rp_pred_op, ei_pred_op], feed_dict=feed_dict)
    preds = results[0] + results[1]
    mae = metrics.mean_absolute_error(dataset.test_ratings, preds)
    mse = metrics.mean_squared_error(dataset.test_ratings, preds)
    ei_error /= train_size
    print('#%d mae=%.4f mse=%.4f ei=%.4f' % (ei_epoch, mae, mse, ei_error))

    if best_mse == None or mse < best_mse:
      best_mae = mae
      best_mse = mse
      best_epoch = '#%d#%d' % (rp_epoch, ei_epoch)
  print('mae=%.4f mse=%.4f epoch=%s' % (best_mae, best_mse, best_epoch))
