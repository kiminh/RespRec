from dataset import Dataset
import utils

from sklearn import metrics
import numpy as np
import tensorflow as tf

import logging
logging.basicConfig(level=logging.INFO, format=utils.log_format)

class PredModel():
  def __init__(self, args, dataset):
    pred_num_factors = args.pred_num_factors
    pred_learning_rate = args.pred_learning_rate
    num_users, num_items = dataset.num_users, dataset.num_items

    users = tf.placeholder(utils.itype, shape=(None,))
    items = tf.placeholder(utils.itype, shape=(None,))
    ratings = tf.placeholder(utils.ftype, shape=(None,))
    weights = tf.placeholder(utils.ftype, shape=(None,))
    deltas = tf.placeholder(utils.ftype, shape=(None,))

    scope = 'pred_model'
    mean, stddev = 0.0, 0.1
    with tf.variable_scope(scope):
      user_embedding = tf.get_variable('user_embedding',
          initializer=tf.random_normal((num_users, pred_num_factors),
                                       mean=mean,
                                       stddev=stddev))
      item_embedding = tf.get_variable('item_embedding',
          initializer=tf.random_normal((num_items, pred_num_factors),
                                       mean=mean,
                                       stddev=stddev))
    _user_embedding = tf.nn.embedding_lookup(user_embedding, users)
    _item_embedding = tf.nn.embedding_lookup(item_embedding, items)

    _pred_ratings = tf.multiply(_user_embedding, _item_embedding)
    pred_ratings = tf.reduce_sum(_pred_ratings, axis=1)

    var_list = [user_embedding, item_embedding]

    obs_errors = tf.squared_difference(ratings, pred_ratings)
    obs_error_op = tf.reduce_mean(tf.multiply(obs_errors, weights))
    obs_loss_op = obs_error_op
    for variable in tf.trainable_variables(scope=scope):
      logging.info('regularize %s in obs pred_model' % (variable.name))
      obs_loss_op += args.obs_reg_coeff * tf.nn.l2_loss(variable)
    obs_optimizer = tf.train.GradientDescentOptimizer(pred_learning_rate)
    obs_update_op = obs_optimizer.minimize(obs_loss_op, var_list=var_list)

    mis_error_op = tf.reduce_mean(
        tf.squared_difference(tf.stop_gradient(pred_ratings) + deltas,
                              pred_ratings))
    mis_loss_op = mis_error_op
    for variable in tf.trainable_variables(scope=scope):
      logging.info('regularize %s in mis pred_model' % (variable.name))
      mis_loss_op += args.mis_reg_coeff * tf.nn.l2_loss(variable)
    mis_optimizer = tf.train.GradientDescentOptimizer(pred_learning_rate)
    mis_update_op = mis_optimizer.minimize(mis_loss_op, var_list=var_list)

    self.users, self.items = users, items
    self.ratings = ratings
    self.weights = weights
    self.deltas = deltas
    self.pred_ratings = pred_ratings
    self.obs_error_op = obs_error_op
    self.obs_update_op = obs_update_op
    self.mis_error_op = mis_error_op
    self.mis_update_op = mis_update_op

class ImptModel():
  def __init__(self, args, dataset, pred_model):
    impt_reg_coeff = args.impt_reg_coeff
    impt_num_factors = args.impt_num_factors
    impt_learning_rate = args.impt_learning_rate
    num_users, num_items = dataset.num_users, dataset.num_items

    users, items = pred_model.users, pred_model.items
    deltas = pred_model.ratings - pred_model.pred_ratings

    scope = 'impt_model'
    mean, stddev = 0.0, 0.1
    with tf.variable_scope(scope):
      user_embedding = tf.get_variable('user_embedding',
          initializer=tf.random_normal((num_users, impt_num_factors),
                                       mean=mean,
                                       stddev=stddev))
      item_embedding = tf.get_variable('item_embedding',
          initializer=tf.random_normal((num_items, impt_num_factors),
                                       mean=mean,
                                       stddev=stddev))
    _user_embedding = tf.nn.embedding_lookup(user_embedding, users)
    _item_embedding = tf.nn.embedding_lookup(item_embedding, items)

    _pred_deltas = tf.multiply(_user_embedding, _item_embedding)
    pred_deltas = tf.reduce_sum(_pred_deltas, axis=1)

    errors = tf.squared_difference(deltas, pred_deltas)
    error_op = tf.reduce_mean(tf.multiply(errors, pred_model.weights))
    loss_op = error_op
    for variable in tf.trainable_variables(scope=scope):
      logging.info('regularize %s in impt_model' % (variable.name))
      loss_op += impt_reg_coeff * tf.nn.l2_loss(variable)

    optimizer = tf.train.GradientDescentOptimizer(impt_learning_rate)
    var_list = [user_embedding, item_embedding]
    update_op = optimizer.minimize(loss_op, var_list=var_list)

    self.pred_deltas = pred_deltas
    self.error_op = error_op
    self.update_op = update_op

def obs_train(sess, dataset, index, pred_model):
  users = dataset.train_users[index]
  items = dataset.train_items[index]
  ratings = dataset.train_ratings[index]
  weights = dataset.train_weights[index]
  feed_dict = {pred_model.users:users,
               pred_model.items:items,
               pred_model.ratings:ratings,
               pred_model.weights:weights}
  fetches = [pred_model.obs_update_op, pred_model.obs_error_op]
  results = sess.run(fetches, feed_dict=feed_dict)

def impt_train(sess, dataset, index, pred_model, impt_model):
  users = dataset.train_users[index]
  items = dataset.train_items[index]
  ratings = dataset.train_ratings[index]
  weights = dataset.train_weights[index]
  feed_dict = {pred_model.users:users,
               pred_model.items:items,
               pred_model.ratings:ratings,
               pred_model.weights:weights}
  fetches = [impt_model.update_op, impt_model.error_op]
  _, mse = sess.run(fetches, feed_dict=feed_dict)
  return mse

def evaluate(sess, dataset, pred_model):
  feed_dict = {pred_model.users:dataset.test_users,
               pred_model.items:dataset.test_items}
  pred_ratings = sess.run(pred_model.pred_ratings, feed_dict=feed_dict)
  mae = metrics.mean_absolute_error(dataset.test_ratings, pred_ratings)
  mse = metrics.mean_squared_error(dataset.test_ratings, pred_ratings)
  return mae, mse

def main():
  description = 'Jointly predict ratings and impute errors.'
  args = utils.parse_args(description)
  pred_batch_size = args.pred_batch_size
  impt_batch_size = args.impt_batch_size
  logging.info('%s' % args)

  dataset = Dataset(args.data_dir)
  train_size = dataset.train_size
  pred_model = PredModel(args, dataset)
  impt_model = ImptModel(args, dataset, pred_model)

  bt_mae, bt_mse, bt_epoch = None, None, None
  init_op = tf.global_variables_initializer()
  with tf.train.MonitoredTrainingSession() as sess:
    sess.run(init_op)

    for epoch in range(args.warm_up_epochs):
      indexes = np.arange(train_size)
      np.random.shuffle(indexes)
      num_batches = train_size // pred_batch_size
      for batch in range(num_batches):
        start = batch * pred_batch_size
        stop = (batch + 1) * pred_batch_size
        index = indexes[start:stop]
        obs_train(sess, dataset, index, pred_model)
      if stop < train_size:
        index = indexes[stop:train_size]
        obs_train(sess, dataset, index, pred_model)
      mae, mse = evaluate(sess, dataset, pred_model)
      logging.info('warm-up#%d mae=%.4f mse=%.4f' % (epoch, mae, mse))
      if (bt_epoch == None) or (mse < bt_mse):
        bt_mae, bt_mse = mae, mse
        bt_epoch = 'warm-up#%d' % (epoch)
    logging.info('%s mae=%.4f mse=%.4f' % (bt_epoch, bt_mae, bt_mse))
    # input()
    for epoch in range(args.interact_epochs):
      for impt_epoch in range(args.impt_num_epochs):
        indexes = np.arange(train_size)
        np.random.shuffle(indexes)
        num_batches = train_size // impt_batch_size
        se = 0.0
        for batch in range(num_batches):
          start = batch * impt_batch_size
          stop = (batch + 1) * impt_batch_size
          index = indexes[start:stop]
          mse = impt_train(sess, dataset, index, pred_model, impt_model)
          se += impt_batch_size * mse
        if stop < train_size:
          index = indexes[stop:train_size]
          mse = impt_train(sess, dataset, index, pred_model, impt_model)
          se += (train_size - stop) * mse
        mse = se / train_size
        if (impt_epoch + 1) % 10 == 0:
          logging.info('impt#%d mse=%.4f' % (impt_epoch, mse))
      for pred_epoch in range(args.pred_num_epochs):
        num_batches = train_size // pred_batch_size + 1
        for batch in range(num_batches):
          users = np.random.choice(dataset.num_users, pred_batch_size)
          items = np.random.choice(dataset.num_items, pred_batch_size)
          feed_dict = {pred_model.users:users,
                       pred_model.items:items}
          pred_deltas = sess.run(impt_model.pred_deltas,
                                 feed_dict=feed_dict)
          feed_dict[pred_model.deltas] = pred_deltas
          sess.run(pred_model.mis_update_op, feed_dict=feed_dict)
        mae, mse = evaluate(sess, dataset, pred_model)
        if (bt_epoch == None) or (mse < bt_mse):
          bt_mae, bt_mse = mae, mse
          bt_epoch = 'interact#%d#%d' % (epoch, pred_epoch)
    logging.info('%s mae=%.4f mse=%.4f' % (bt_epoch, bt_mae, bt_mse))

if __name__ == '__main__':
  main()