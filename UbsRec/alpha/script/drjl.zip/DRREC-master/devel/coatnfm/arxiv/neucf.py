from dataset import Dataset
import utils

from sklearn import metrics
import numpy as np
import tensorflow as tf

import logging
logging.basicConfig(level=logging.INFO, format=utils.log_format)

class NeuCF(object):
  def __init__(self, dataset):
    print('#users=%d #items=%d' % (dataset.num_users, dataset.num_items))
    users = tf.placeholder(tf.int32, shape=(None,))
    items = tf.placeholder(tf.int32, shape=(None,))
    ratings = tf.placeholder(tf.float32, shape=(None,))

    user_feature = tf.constant(dataset.user_feature, name='user_feature')
    num_users, num_user_features = user_feature.shape.as_list()
    print('#users=%d #features=%d' % (num_users, num_user_features))
    item_feature = tf.constant(dataset.item_feature, name='item_feature')
    num_items, num_item_features = item_feature.shape.as_list()
    print('#items=%d #features=%d' % (num_items, num_item_features))

    _user_feature = tf.nn.embedding_lookup(user_feature, users)
    _item_feature = tf.nn.embedding_lookup(item_feature, items)
    concat_feature = tf.concat([_user_feature, _item_feature], 1)

    mean, stddev = 0.0, 0.1
    with tf.name_scope('hidden1'):
      weights = tf.Variable(
          tf.truncated_normal((num_user_features+num_item_features,hidden_size),
                              mean=mean,
                              stddev=stddev),
          name='weights')
      biases = tf.Variable(tf.zeros((hidden_size)),
                           name='biases')
      hidden1 = tf.matmul(concat_feature, weights) + biases
      # hidden1 = tf.nn.relu(hidden1)
      # hidden1 = tf.sigmoid(hidden1)
      hidden1 = tf.tanh(hidden1)
    with tf.name_scope('hidden2'):
      weights = tf.Variable(
          tf.truncated_normal((hidden_size,1),
                              mean=mean,
                              stddev=stddev),
          name='weights')
      biases = tf.Variable(tf.zeros((1)),
                           name='biases')
      hidden2 = tf.matmul(hidden1, weights) + biases
    predictions = tf.squeeze(hidden2)
    loss_op = tf.losses.mean_squared_error(ratings, predictions)
    for variable in tf.trainable_variables():
      loss_op += reg_coeff * tf.nn.l2_loss(variable)
    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
    update_op = optimizer.minimize(loss_op)

    self.users = users
    self.items = items
    self.ratings = ratings
    self.predictions = predictions
    self.update_op = update_op

def evaluate(dataset, neucf, sess):
  feed_dict = {neucf.users:dataset.test_users,
               neucf.items:dataset.test_items}
  predictions = sess.run(neucf.predictions, feed_dict=feed_dict)
  mae = metrics.mean_absolute_error(dataset.test_ratings, predictions)
  mse = metrics.mean_squared_error(dataset.test_ratings, predictions)
  print('mae=%.4f mse=%.4f' % (mae, mse))

def test():
  data_dir = '../data/coat'
  dataset = Dataset(data_dir)
  train_size = dataset.train_size
  neucf = NeuCF(dataset)

  init_op = tf.global_variables_initializer()
  with tf.train.MonitoredTrainingSession() as sess:
    sess.run(init_op)

    for epoch in range(num_epochs):
      indexes = np.arange(train_size)
      np.random.shuffle(indexes)

      num_batches = train_size // batch_size
      rp_error = 0
      for batch in range(num_batches):
        start = batch * batch_size
        stop = (batch + 1) * batch_size

        users = dataset.train_users[indexes[start:stop]]
        items = dataset.train_items[indexes[start:stop]]
        ratings = dataset.train_ratings[indexes[start:stop]]
        feed_dict = {neucf.users:users,
                     neucf.items:items,
                     neucf.ratings:ratings}
        results = sess.run([neucf.update_op], feed_dict=feed_dict)
        if batch % eval_interval == 0:
          evaluate(dataset, neucf, sess)

      if stop < train_size:
        users = dataset.train_users[indexes[stop:train_size]]
        items = dataset.train_items[indexes[stop:train_size]]
        ratings = dataset.train_ratings[indexes[stop:train_size]]
        feed_dict = {neucf.users:users,
                     neucf.items:items,
                     neucf.ratings:ratings}
        results = sess.run([neucf.update_op], feed_dict=feed_dict)
      evaluate(dataset, neucf, sess)

def main():
  description = 'Jointly predict ratings and impute errors.'
  args = utils.parse_args(description)

if __name__ == '__main__':
  main()



