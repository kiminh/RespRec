from sys import stdout
import numpy as np
import tensorflow as tf

num_epochs = 50
num_factors = 10
learning_rate = 0.01
mean, stddev = 0.0, 0.5
interval = 5

class PredModel(object):
  def __init__(self):
    user_vector = tf.get_variable('user_vector',
        initializer=tf.random_normal((num_factors,),
                                     mean=mean,
                                     stddev=stddev))
    item_vector = tf.get_variable('item_vector',
        initializer=tf.random_normal((num_factors,),
                                     mean=mean,
                                     stddev=stddev))
    delta = tf.placeholder(tf.float32, shape=())

    prediction = tf.reduce_sum(tf.multiply(user_vector, item_vector))

    diff = prediction - (prediction + delta)
    # diff = prediction - (tf.stop_gradient(prediction) + delta)
    loss_op = tf.square(diff)

    optimizer = tf.train.GradientDescentOptimizer(learning_rate)
    update_op = optimizer.minimize(loss_op)

    self.delta = delta
    self.prediction = prediction
    self.loss_op = loss_op
    self.update_op = update_op

class ImptModel(object):
  def __init__(self):
    self.rating = 5.0

  def compute_delta(self, prediction):
    delta = self.rating - prediction
    return delta

pred_model = PredModel()
impt_model = ImptModel()

init_op = tf.global_variables_initializer()
with tf.train.MonitoredTrainingSession() as sess:
  sess.run(init_op)

  for epoch in range(num_epochs):
    prediction = sess.run(pred_model.prediction)
    delta = impt_model.compute_delta(prediction)
    # print('prediction=%.4f delta=%.4f' % (prediction, delta))

    feed_dict = {pred_model.delta:delta}
    loss = sess.run(pred_model.loss_op, feed_dict=feed_dict)

    if epoch % interval == (interval - 1):
      stdout.write('#%2d=%.4f\n' % (epoch, loss))
    else:
      stdout.write('#%2d=%.4f\t' % (epoch, loss))

    sess.run(pred_model.update_op, feed_dict=feed_dict)








