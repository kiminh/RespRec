from os import path
import argparse
import numpy as np
import tensorflow as tf

itype = tf.int32
ftype = tf.float32
log_format = '%(pathname)s: %(message)s'

def load_feature(file_path):
  feature = np.loadtxt(file_path, dtype=np.float32)
  return feature

def parse_args(description):
  p = argparse.ArgumentParser(description=description)
  ### data
  p.add_argument('--data_dir', type=str, default='../data/coat')
  ### model
  p.add_argument('--pred_num_factors', type=int, default=100)
  p.add_argument('--impt_num_factors', type=int, default=100)
  ### train
  p.add_argument('--warm_up_epochs', type=int, default=100)
  p.add_argument('--interact_epochs', type=int, default=20)
  p.add_argument('--impt_num_epochs', type=int, default=20)
  p.add_argument('--pred_num_epochs', type=int, default=10)
  p.add_argument('--pred_opt', default='sgd', help='adagrad|adam|rmsprop')
  p.add_argument('--obs_reg_coeff', type=float, default=0.001)
  p.add_argument('--mis_reg_coeff', type=float, default=0.0)
  p.add_argument('--pred_batch_size', type=int, default=64)
  p.add_argument('--pred_learning_rate', type=float, default=0.5)
  p.add_argument('--impt_opt', default='sgd', help='adagrad|adam|rmsprop')
  p.add_argument('--impt_reg_coeff', type=float, default=0.001)
  p.add_argument('--impt_batch_size', type=int, default=64)
  p.add_argument('--impt_learning_rate', type=float, default=0.5)
  ### log
  p.add_argument('-v', '--verbose', action='store_true')
  return p.parse_args()

if __name__ == '__main__':
  data_dir = '../data/coat'
