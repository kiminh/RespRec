from os import path
from sys import stdout
import argparse
import numpy as np
import os
import pprint


def load_feature(feature_file, map_file):
  pp = pprint.PrettyPrinter(indent=2)
  
  feature_mat = np.loadtxt(feature_file, dtype=np.int32)
  num_instances, num_features = feature_mat.shape
  feature_list = []
  feature_names = {}
  with open(map_file) as fin:
    for line in fin.readlines():
      arr = line.strip().split(':')
      assert len(arr) == 2
      feature_names[arr[0]] = feature_names.get(arr[0], []) + [arr[1]]
      if (len(feature_list) == 0) or (arr[0] != feature_list[-1]):
        feature_list.append(arr[0])
  feature_indexes = []
  start = 0
  for feature in feature_list:
    stop = start + len(feature_names[feature])
    feature_indexes.append((start, stop))
    start = stop
  assert stop == num_features
  for i in range(num_instances):
    for start, stop in feature_indexes:
      one_hot = feature_mat[i, start:stop]
      assert np.sum(one_hot) == 1
  return feature_mat

def libfm_instance(rating_file, user_feat_mat, item_feat_mat, incl):
  rating_mat = np.loadtxt(rating_file, dtype=np.int32)
  instances = []
  users, items = rating_mat.nonzero()
  for user, item in zip(users, items):
    rating = rating_mat[user, item]
    user_feat_vec = user_feat_mat[user,:]
    item_feat_vec = item_feat_mat[item,:]
    user_features, = user_feat_vec.nonzero()
    item_features, = item_feat_vec.nonzero()
    assert len(user_features) == 4
    assert len(item_features) == 4
    instance = [str(rating)]
    instance += [str(user_ids[user])]
    if incl:
      for user_feature in user_features:
        instance += [str(user_feat_ids[user_feature])]
    instance += [str(item_ids[item])]
    if incl:
      for item_feature in item_features:
        instance += [str(item_feat_ids[item_feature])]
    instances.append(instance)
  return instances

def save_instance(instances, rating_file):
  with open(rating_file, 'w') as fout:
    for instance in instances:
      fout.write('%s\n' % (' '.join(instance)))

parser = argparse.ArgumentParser(description='convert to libfm')
parser.add_argument('dataset', type=str, help='coat|song')
args = parser.parse_args()
dataset = args.dataset
if dataset == 'coat':
  incl = True
elif dataset == 'song':
  incl = False
else:
  raise Exception('unknown dataset %s' % (dataset))

in_dir = path.expanduser('~/Downloads/coat')
feat_dir = path.join(in_dir, 'user_item_features')
data_dir = '../data'
out_dir = path.join(data_dir, dataset)
if not path.exists(out_dir):
  os.makedirs(out_dir)

user_map_file = path.join(feat_dir, 'user_features_map.txt')
user_feat_file = path.join(feat_dir, 'user_features.ascii')
user_feat_mat = load_feature(user_feat_file, user_map_file)

item_map_file = path.join(feat_dir, 'item_features_map.txt')
item_feat_file = path.join(feat_dir, 'item_features.ascii')
item_feat_mat = load_feature(item_feat_file, item_map_file)

num_users, num_user_features = user_feat_mat.shape
print('#user=%d #user_feature=%d' % (num_users, num_user_features))
num_items, num_item_features = item_feat_mat.shape
print('#item=%d #item_feature=%d' % (num_items, num_item_features))

start_id = 0

user_ids = dict()
for user in range(num_users):
  user_ids[user] = start_id + user
start_id += num_users

if incl:
  user_feat_ids = dict()
  for user_feature in range(num_user_features):
    user_feat_ids[user_feature] = start_id + user_feature
  start_id += num_user_features

item_ids = dict()
for item in range(num_items):
  item_ids[item] = start_id + item
start_id += num_items

if incl:
  item_feat_ids = dict()
  for item_feature in range(num_item_features):
    item_feat_ids[item_feature] = start_id + item_feature
  start_id += num_item_features

print('user_ids', user_ids[0], user_ids[num_users - 1])
print('item_ids', item_ids[0], item_ids[num_items - 1])
if incl:
  print('user_feat_ids', user_feat_ids[0], user_feat_ids[num_user_features - 1])
  print('item_feat_ids', item_feat_ids[0], item_feat_ids[num_item_features - 1])

train_file = path.join(in_dir, 'train.ascii')
train_instances = libfm_instance(train_file, user_feat_mat, item_feat_mat, incl)
train_file = path.join(out_dir, '%s.train.libfm' % (dataset))
save_instance(train_instances, train_file)

valid_file = path.join(in_dir, 'test.ascii')
test_instances = libfm_instance(valid_file, user_feat_mat, item_feat_mat, incl)
valid_file = path.join(out_dir, '%s.valid.libfm' % (dataset))
test_file = path.join(out_dir, '%s.test.libfm' % (dataset))
save_instance(test_instances, valid_file)
save_instance(test_instances, test_file)

user_feat_file = path.join(out_dir, '%s.user_feature.mat' % (dataset))
with open(user_feat_file, 'w') as fout:
  for user in range(num_users):
    fout.write('%d' % (user_ids[user]))
    if incl:
      user_feat_vec = user_feat_mat[user,:]
      user_features, = user_feat_vec.nonzero()
      for user_feature in user_features:
        fout.write(' %d' % (user_feat_ids[user_feature]))
    fout.write('\n')

item_feat_file = path.join(out_dir, '%s.item_feature.mat' % (dataset))
with open(item_feat_file, 'w') as fout:
  for item in range(num_items):
    fout.write('%d' % (item_ids[item]))
    if incl:
      item_feat_vec = item_feat_mat[item,:]
      item_features, = item_feat_vec.nonzero()
      for item_feature in item_features:
        fout.write(' %d' % (item_feat_ids[item_feature]))
    fout.write('\n')
