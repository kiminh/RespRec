from utils import fkey, rkey, itype, ftype
import utils

import os
import sys
import math
import numpy as np
import tensorflow as tf
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score
from sklearn.metrics import log_loss
from time import time
import argparse


import logging
logging.basicConfig(level=logging.INFO, format=utils.log_format)


class DrRec(utils.BsRec):
  def __init__(self, args, data):
    super(DrRec, self).__init__(args, data)

    pred_model_name = self._args.pred_model_name
    pred_scope = 'pred_model'
    with tf.variable_scope(pred_scope):
      pred_params, pred_ratings = self._init_graph(pred_model_name)
    self.pred_ratings = pred_ratings
    pred_var_list = [var for var in pred_params.values()]

    impt_model_name = self._args.impt_model_name
    impt_scope = 'impt_model'
    with tf.variable_scope(impt_scope):
      impt_params, pred_errors = self._init_graph(impt_model_name)
    self.pred_errors = pred_errors
    impt_var_list = [var for var in impt_params.values()]

    all_reg_coeff = self._args.all_reg_coeff
    regulizer = tf.contrib.layers.l2_regularizer(all_reg_coeff)

    self.errors = self.ratings - pred_ratings
    #### nn l2 loss is problematic
    # obs_loss = tf.nn.l2_loss(self.errors)
    obs_loss = tf.reduce_mean(tf.square(self.errors))
    self.obs_error = obs_loss
    if all_reg_coeff > 0:
      for parameter in pred_params.values():
        obs_loss += regulizer(parameter)
    self.obs_loss = obs_loss
    pred_learning_rate = self._args.pred_learning_rate
    obs_optimizer = self._init_optimizer(pred_learning_rate)
    self.obs_update = obs_optimizer.minimize(obs_loss,
                                             var_list=pred_var_list)


    #### nn l2 loss is problematic
    # impt_loss = tf.nn.l2_loss(self.errors - pred_errors)
    # impt_loss = tf.reduce_mean(tf.square(self.errors - pred_errors))
    impt_loss = tf.reduce_mean(tf.square(self.errors + self.scale - pred_errors))
    self.impt_loss = impt_loss
    if all_reg_coeff > 0:
      for parameter in impt_params.values():
        impt_loss += regulizer(parameter)
    impt_learning_rate = self._args.impt_learning_rate
    impt_optimizer = self._init_optimizer(impt_learning_rate)
    self.impt_update = impt_optimizer.minimize(impt_loss,
                                               var_list=impt_var_list)

    min_value = self._data.min_value
    max_value = self._data.max_value
    # ratings = tf.stop_gradient(pred_ratings) + pred_errors
    ratings = tf.stop_gradient(pred_ratings) + pred_errors - self.scale
    ratings = tf.clip_by_value(ratings, min_value, max_value)
    #### for testing stop_gradient
    # ratings = pred_ratings + pred_errors
    #### nn l2 loss is problematic
    # mis_loss = tf.nn.l2_loss(ratings - self.pred_ratings)
    #### do not regularize mis_loss
    mis_loss = tf.reduce_mean(tf.square(ratings - self.pred_ratings))
    self.mis_loss = mis_loss
    mis_optimizer = self._init_optimizer(pred_learning_rate)
    self.mis_update = mis_optimizer.minimize(mis_loss,
                                             var_list=pred_var_list)

    self.saver = tf.train.Saver()
    init = tf.global_variables_initializer()
    self.sess = tf.Session()
    self.sess.run(init)

  def train(self):
    pretrain_epochs = self._args.pretrain_epochs
    interact_epochs = self._args.interact_epochs
    num_impt_epochs = self._args.num_impt_epochs
    num_pred_epochs = self._args.num_pred_epochs
    verbose = self._args.verbose
    batch_size = self._args.batch_size
    train_data = self._data.train_data
    valid_data = self._data.valid_data
    test_data = self._data.test_data
    train_size = self._data.train_size
    num_batches = train_size // batch_size

    pred_train_mae, pred_test_mae = [], []
    pred_train_mse, pred_test_mse = [], []

    for epoch in range(pretrain_epochs):
      self._shuffle_in_unison(train_data[fkey], train_data[rkey])
      for batch in range(num_batches):
        obs_data = self._get_obs_data(batch_size)
        self._fit_obs_data(obs_data)

      pred_train_res = self._eval_pred_model(train_data)
      pred_test_res = self._eval_pred_model(test_data)
      pred_train_mae.append(pred_train_res[0])
      pred_train_mse.append(pred_train_res[1])
      pred_test_mae.append(pred_test_res[0])
      pred_test_mse.append(pred_test_res[1])
      if verbose > 0 and (epoch + 1) % verbose == 0:
        f_data = (epoch + 1, pred_train_res[1], pred_test_res[1])
        print('pretrain#%03d train=%.4f test=%.4f' % f_data)
    print('\n%s' % ('-' * 64))
    best_test = min(pred_test_mse)
    best_epoch = pred_test_mse.index(best_test)
    f_data = (best_epoch + 1,
              pred_test_mae[best_epoch],
              pred_test_mse[best_epoch])
    print ('pretrain best=#%03d mae=%.4f mse=%.4f' % f_data)
    print('%s\n' % ('-' * 64))
    # exit()

    for epoch in range(interact_epochs):
      no_dropout = self._args.no_dropout
      feed_dict = {self.features: train_data[fkey], 
                   self.ratings: train_data[rkey], 
                   self.keep_probs: no_dropout,
                   self.train_phase: False}
      train_errors = self.sess.run(self.errors, feed_dict=feed_dict)
      scale = - min(train_errors) + 1
      print('interact#%d scale=%.4f' % (epoch, scale))

      impt_train_mse, impt_valid_mse = [], []
      for i_epoch in range(num_impt_epochs):
        impt_loss = 0.0
        self._shuffle_in_unison(train_data[fkey], train_data[rkey])
        for batch in range(num_batches):
          obs_data = self._get_obs_data(batch_size)
          impt_loss += self._fit_impt_data(obs_data, scale)
        impt_loss /= num_batches
        impt_train_res = self._eval_impt_model(train_data)
        impt_valid_res = self._eval_impt_model(valid_data)
        # f_data = (epoch + 1, i_epoch + 1, impt_loss)
        f_data = (epoch + 1, i_epoch + 1,
                  impt_train_res[1],
                  impt_valid_res[1])
        if verbose > 0 and (i_epoch + 1) % verbose == 0:
          # print('\t#%03d#%03d impt_loss=%.4f' % f_data)
          # print('\timpt_model#%03d#%03d train=%.4f valid=%.4f' % f_data)
          pass
        impt_valid_mse.append(impt_valid_res[1])

        is_overfit = self._check_overfit(impt_valid_mse)
        if is_overfit:
          # print('\timpt_model overfits at #%d' % (i_epoch))
          break
      
      for m_epoch in range(num_pred_epochs):
        for batch in range(num_batches):
          mis_data = self._get_mis_data(batch_size)
          self._fit_mis_data(mis_data, scale)
        pred_train_res = self._eval_pred_model(train_data)
        pred_test_res = self._eval_pred_model(test_data)
        pred_train_mae.append(pred_train_res[0])
        pred_train_mse.append(pred_train_res[1])
        pred_test_mae.append(pred_test_res[0])
        pred_test_mse.append(pred_test_res[1])
        f_data = (epoch + 1, m_epoch + 1,
                  pred_train_res[1],
                  pred_test_res[1])
        if verbose > 0 and (m_epoch + 1) % verbose == 0:
          print('mis#%03d#%03d train=%.4f test=%.4f' % f_data)

      for o_epoch in range(num_pred_epochs):
        self._shuffle_in_unison(train_data[fkey], train_data[rkey])
        for batch in range(num_batches):
          obs_data = self._get_obs_data(batch_size)
          self._fit_obs_data(obs_data)
        pred_train_res = self._eval_pred_model(train_data)
        pred_test_res = self._eval_pred_model(test_data)
        pred_train_mae.append(pred_train_res[0])
        pred_train_mse.append(pred_train_res[1])
        pred_test_mae.append(pred_test_res[0])
        pred_test_mse.append(pred_test_res[1])
        f_data = (epoch + 1, o_epoch + 1,
                  pred_train_res[1],
                  pred_test_res[1])
        if verbose > 0 and (o_epoch + 1) % verbose == 0:
          print('obs#%03d#%03d train=%.4f test=%.4f' % f_data)

    print('\n%s' % ('-' * 64))
    best_test = min(pred_test_mse)
    best_epoch = pred_test_mse.index(best_test)
    f_data = (best_epoch + 1,
              pred_test_mae[best_epoch],
              pred_test_mse[best_epoch])
    print ('interact best=#%03d mae=%.4f mse=%.4f' % f_data)
    print('%s\n' % ('-' * 64))

if __name__ == '__main__':
  description = 'Run a double robust model.'
  args = utils.parse_args(description)
  data = utils.Dataset(args.base_dir)
  # print('\n%s' % ('-' * 64))
  # logging.info(args)
  # print('num_features=%d' % (data.num_features))
  # print('nnz_features=%d' % (data.nnz_features))
  # print('%s\n' % ('-' * 64))
  # exit()

  model = DrRec(args, data)
  # for var in tf.trainable_variables():
  #   logging.info('%s=%s' % (var.name, var.shape))
  model.train()
