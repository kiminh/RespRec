from utils import fkey, rkey
import utils

import math
import os
import numpy as np
import tensorflow as tf
from sklearn.metrics import mean_squared_error
from sklearn.metrics import accuracy_score
from sklearn.metrics import log_loss
from time import time
import argparse

import logging
logging.basicConfig(level=logging.INFO, format=utils.log_format)


class SrNmf(utils.SrRec):
  def __init__(self, args, data):
    super(SrNmf, self).__init__(args, data)

    pred_model_name = self._args.pred_model_name
    pred_scope = 'pred_model'
    with tf.variable_scope(pred_scope):
      pred_params, pred_ratings = self._init_graph(pred_model_name)
    self.pred_ratings = pred_ratings

    all_reg_coeff = self._args.all_reg_coeff
    regulizer = tf.contrib.layers.l2_regularizer(all_reg_coeff)

    self.errors = self.ratings - pred_ratings
    # obs_loss = tf.nn.l2_loss(self.errors)
    obs_loss = tf.reduce_mean(tf.square(self.errors))
    self.obs_error = obs_loss
    if all_reg_coeff > 0:
      # obs_loss += regulizer(pred_params['feature_embedding'])
      for parameter in pred_params.values():
        obs_loss += regulizer(parameter)
    self.obs_loss = obs_loss

    pred_learning_rate = self._args.pred_learning_rate
    obs_optimizer = self._init_optimizer(pred_learning_rate)
    self.obs_update = obs_optimizer.minimize(obs_loss)

    self.saver = tf.train.Saver()
    init = tf.global_variables_initializer()
    self.sess = tf.Session()
    self.sess.run(init)


if __name__ == '__main__':
  description = 'Run a neural matrix factorization model.'
  args = utils.parse_args(description)
  logging.info(args)
  assert args.pred_model_name == 'nmf'
  data = utils.Dataset(args.base_dir)

  model = SrNmf(args, data)
  for var in tf.trainable_variables():
    logging.info('%s=%s' % (var.name, var.shape))
  model.train()
