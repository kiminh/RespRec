# base_dir=~/Projects/drrec/data/coat/coat
base_dir=~/Projects/drrec/data/song/song

batch_norm=0
batch_size=64
num_factors=128
keep_probs='[0.2,0.5]'
all_reg_coeff=0.01
pred_learning_rate=0.05
impt_learning_rate=0.05
layer_sizes='[64]'
optimizer_type=adagrad
python -W ignore drrec.py \
    --base_dir ${base_dir} \
    --verbose 10 \
    --pretrain_epochs 100 \
    --interact_epochs 10 \
    --num_impt_epochs 100 \
    --num_pred_epochs 10 \
    --pred_model_name nfm \
    --impt_model_name nfm \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_learning_rate ${impt_learning_rate} \
    --optimizer_type ${optimizer_type} \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs}
exit

batch_norm=0
batch_size=64 # 128
num_factors=128
keep_probs='[0.6]'
all_reg_coeff=0.001
pred_learning_rate=0.5 # 0.01
impt_learning_rate=0.5 # 0.01
optimizer_type=sgd # adagrad
python -W ignore drrec.py \
    --base_dir ~/Projects/drrec/data/song/song \
    --verbose 10 \
    --pretrain_epochs 100 \
    --interact_epochs 10 \
    --num_impt_epochs 100 \
    --num_pred_epochs 10 \
    --pred_model_name mf \
    --impt_model_name mf \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_learning_rate ${impt_learning_rate} \
    --optimizer_type ${optimizer_type} \
    --verbose 10 \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs}
exit

