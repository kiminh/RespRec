batch_size=64
num_factors=128
all_reg_coeff=0.001
pred_learning_rate=0.5
optimizer_type=sgd
python -W ignore mf.py \
    --base_dir ~/Projects/drrec/data/song/song \
    --pred_model_name mf \
    --num_pred_epochs 200 \
    --verbose 10 \
    --optimizer_type ${optimizer_type} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --pred_learning_rate ${pred_learning_rate}
