base_dir=~/Projects/drrec/data/song/song
batch_norm=0
# batch_norm=1 # better
batch_size=64
num_factors=128
keep_probs='[0.2,0.5]'
all_reg_coeff=0.01
pred_learning_rate=0.05
layer_sizes='[64]'

for batch_size in 32 64 128
# for batch_size in 128 64 32 
do
  for num_factors in 64 128 256
  # for num_factors in 256 128 64
  do
    for pred_learning_rate in 0.01 0.05 0.1
    # for pred_learning_rate in 0.1 0.05 0.01
    do
      for all_reg_coeff in 0.005 0.01 0.05
      # for all_reg_coeff in 0.05 0.01 0.005
      do
        for layer_sizes in '[32]' '[64]' '[128]'
        # for layer_sizes in '[128]' '[64]' '[32]'
        do
          for keep_probs in '[0.2,0.2]' '[0.2,0.5]' '[0.2,0.8]' '[0.5,0.2]' '[0.5,0.5]' '[0.5,0.8]' '[0.8,0.2]' '[0.8,0.5]' '[0.8,0.8]'
          do

python -W ignore nfm.py \
    --base_dir ${base_dir} \
    --pred_model_name nfm \
    --optimizer_type adagrad \
    --num_pred_epochs 400 \
    --verbose 0 \
    --activation_func relu \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --keep_probs ${keep_probs} \
    --all_reg_coeff ${all_reg_coeff} \
    --pred_learning_rate ${pred_learning_rate} \
    --layer_sizes ${layer_sizes}

          done
        done
      done
    done
  done
done
exit

# 0.9846 - 1.0424
# best=#113 mae=0.7659 mse=0.9846
# best=#072 mae=0.7719 mse=0.9940
# best=#049 mae=0.7779 mse=1.0123
# best=#155 mae=0.7784 mse=1.0173
# best=#161 mae=0.7816 mse=1.0237
