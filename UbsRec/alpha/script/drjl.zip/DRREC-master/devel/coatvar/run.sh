base_dir=~/Projects/drrec/data/song/song

batch_norm=0 # better
# batch_norm=1
batch_size=128
num_factors=128
keep_probs='[0.6]'
all_reg_coeff=0.001
num_pred_epochs=1000
pred_learning_rate=0.01
min_weight=0.0001
# for pred_learning_rate in 0.005 0.01 0.05
# for pred_learning_rate in 0.008 0.012 0.016 0.020 0.024 \
#                           0.028 0.032 0.036 0.040 0.044
for pred_learning_rate in 0.006 0.007 0.018 0.019 0.021 0.022
do
  for min_weight in 1e-1 1e-2 1e-3 1e-4 1e-5 \
                    5e-2 5e-3 5e-4 5e-5 5e-6
  do

python -W ignore srrec.py \
    --base_dir ${base_dir} \
    --pred_model_name fm \
    --optimizer_type adagrad \
    --num_pred_epochs ${num_pred_epochs} \
    --verbose 10 \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs} \
    --pred_learning_rate ${pred_learning_rate} \
    --min_weight ${min_weight}

  done
done
exit
# 1.0105 - 1.0420

batch_norm=0
# batch_norm=1 # better
batch_size=64
num_factors=128
keep_probs='[0.2,0.5]'
all_reg_coeff=0.01
pred_learning_rate=0.05
layer_sizes='[64]'
python -W ignore nfm.py \
    --base_dir ${base_dir} \
    --pred_model_name nfm \
    --optimizer_type adagrad \
    --num_pred_epochs 200 \
    --verbose 10 \
    --activation_func relu \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --keep_probs ${keep_probs} \
    --all_reg_coeff ${all_reg_coeff} \
    --pred_learning_rate ${pred_learning_rate} \
    --layer_sizes ${layer_sizes}
exit
# 0.9846 - 1.0424
