import os
from os import path
from sklearn import metrics
from tensorflow.contrib.layers.python.layers import batch_norm
import argparse
import numpy as np
import tensorflow as tf
import time
import pickle
import math

fkey = 'feature'
rkey = 'rating'
pkey = 'propensity'
wkey = 'weight'
itype = tf.int32
ftype = tf.float32
log_format = '%(pathname)-16s%(message)s'


class BsRec(object):
  def __init__(self, args, data):
    self._args = args
    self._args.keep_probs = np.array(eval(args.keep_probs))
    self._args.no_dropout = np.ones_like(args.keep_probs)
    self._args.layer_sizes = eval(args.layer_sizes)
    self._data = data

    # random_seed = int(round(time.time() * 1000))
    random_seed = 2016
    tf.set_random_seed(random_seed)

    self._init_placeholder()

  def _init_placeholder(self):
    nnz_features = self._data.nnz_features

    self.features = tf.placeholder(itype, shape=(None, nnz_features))
    self.ratings = tf.placeholder(ftype, shape=(None,))
    self.weights = tf.placeholder(ftype, shape=(None,))
    self.keep_probs = tf.placeholder(ftype, shape=(None,))
    self.train_phase = tf.placeholder(tf.bool)

  def _init_optimizer(self, learning_rate):
    optimizer_type = self._args.optimizer_type
    if optimizer_type == 'adagrad':
      optimizer = tf.train.AdagradOptimizer(learning_rate=learning_rate,
                                            initial_accumulator_value=1e-8)
    elif optimizer_type == 'adam':
      optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate)
    elif optimizer_type == 'sgd':
      optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)
    elif optimizer_type == 'rmsprop':
      optimizer = tf.train.RMSPropOptimizer(learning_rate=learning_rate)
    else:
      raise Exception('unknown optimizer_type %s' % (optimizer_type))
    return optimizer

  def _get_weight(self, i):
    return 'weight_%d' % (i)

  def _get_bias(self, i):
    return 'bias_%d' % (i)

  def _get_activation(self):
    activation_func = self._args.activation_func
    if activation_func == 'identity':
      activation_function = tf.identity
    elif activation_func == 'relu':
      activation_function = tf.nn.relu
    elif activation_func == 'sigmoid':
      activation_function = tf.sigmoid
    elif activation_func == 'tanh':
      activation_function == tf.tanh
    else:
      raise Exception('unknown activation %s' % (activation_func))
    return activation_function

  def _batch_norm(self, in_tensor, train_phase, scope_bn):
    bn_train = batch_norm(in_tensor,
                          decay=0.9,
                          center=True,
                          scale=True,
                          updates_collections=None,
                          is_training=True,
                          reuse=None,
                          trainable=True,
                          scope=scope_bn)
    bn_test = batch_norm(in_tensor,
                         decay=0.9,
                         center=True,
                         scale=True,
                         updates_collections=None,
                         is_training=False,
                         reuse=True,
                         trainable=True,
                         scope=scope_bn)
    out_tensor = tf.cond(train_phase, lambda: bn_train, lambda: bn_test)
    return out_tensor

  def _init_graph(self, model_name):
    batch_norm = self._args.batch_norm
    optimizer_type = self._args.optimizer_type
    layer_sizes = self._args.layer_sizes
    verbose = self._args.verbose
    num_factors = self._args.num_factors
    num_features = self._data.num_features

    if model_name == 'fm':
      parameters = dict()
      parameters['feature_embedding'] = tf.Variable(
          tf.random_normal([num_features, num_factors], 0.0, 0.01),
          name='%s/feature_embedding' % (model_name))
      parameters['feature_bias'] = tf.Variable(
          tf.random_uniform([num_features,], 0.0, 0.0),
          name='%s/feature_bias' % (model_name))
      parameters['global_bias'] = tf.Variable(
          tf.constant(0.0),
          name='%s/global_bias' % (model_name))

      nnz_embedding = tf.nn.embedding_lookup(parameters['feature_embedding'],
                                             self.features)
      sum_embedding = tf.reduce_sum(nnz_embedding, axis=1)
      # batch_size * num_factors
      sqr_sum_embedding = tf.square(sum_embedding)
      sqr_embedding = tf.square(nnz_embedding)
      # batch_size * num_factors
      sum_sqr_embedding = tf.reduce_sum(sqr_embedding, axis=1)

      predictions = 0.5 * tf.subtract(sqr_sum_embedding, sum_sqr_embedding)
      if batch_norm:
        predictions = self._batch_norm(predictions,
                                       train_phase=self.train_phase,
                                       scope_bn='%s/bn_fm' % (model_name))
      predictions = tf.nn.dropout(predictions, self.keep_probs[-1])

      predictions = tf.reduce_sum(predictions, axis=1)
      feature_bias = tf.reduce_sum(
          tf.nn.embedding_lookup(parameters['feature_bias'], self.features),
          axis=1)
      global_bias = parameters['global_bias'] * tf.ones_like(feature_bias)
      predictions = tf.add_n([predictions, feature_bias, global_bias])
    elif model_name == 'nfm':
      activation_function = self._get_activation()

      parameters = dict()
      parameters['feature_embedding'] = tf.Variable(
          tf.random_normal([num_features, num_factors], 0.0, 0.01),
          name='%s/feature_embedding' % (model_name))
      parameters['feature_bias'] = tf.Variable(
          tf.random_uniform([num_features,], 0.0, 0.0),
          name='%s/feature_bias' % (model_name))
      parameters['global_bias'] = tf.Variable(
          tf.constant(0.0),
          name='%s/global_bias' % (model_name))
      # deep layers
      num_layer = len(layer_sizes)
      if num_layer > 0:
        glorot = np.sqrt(2.0 / (num_factors + layer_sizes[0]))
        parameters[self._get_weight(0)] = tf.Variable(
            np.random.normal(loc=0,
                             scale=glorot,
                             size=(num_factors, layer_sizes[0])),
            dtype=ftype,
            name='%s/%s' % (model_name, self._get_weight(0)))
        parameters[self._get_bias(0)] = tf.Variable(
            np.random.normal(loc=0,
                             scale=glorot,
                             size=(1, layer_sizes[0])),
            dtype=ftype,
            name='%s/%s' % (model_name, self._get_bias(0)))
        for i in range(1, num_layer):
          glorot = np.sqrt(2.0 / (layer_sizes[i-1] + layer_sizes[i]))
          parameters[self._get_weight(i)] = tf.Variable(
              np.random.normal(loc=0,
                               scale=glorot,
                               size=(layer_sizes[i-1], layer_sizes[i])),
              dtype=ftype,
              name='%s/%s' % (model_name, self._get_weight(i)))
          parameters[self._get_bias(i)] = tf.Variable(
              np.random.normal(loc=0,
                               scale=glorot,
                               size=(1, layer_sizes[i])),
              dtype=ftype,
              name='%s/%s' % (model_name, self._get_bias(i)))
        glorot = np.sqrt(2.0 / (layer_sizes[-1] + 1))
        parameters['prediction'] = tf.Variable(
            np.random.normal(loc=0,
                             scale=glorot,
                             size=(layer_sizes[-1], 1)),
            dtype=ftype,
            name='%s/prediction' % (model_name))
      else:
        parameters['prediction'] = tf.Variable(
            np.ones((num_factors, 1)),
            dtype=ftype,
            name='%s/prediction' % (model_name))

      nnz_embedding = tf.nn.embedding_lookup(parameters['feature_embedding'],
                                             self.features)
      sum_embedding = tf.reduce_sum(nnz_embedding, axis=1)
      # batch_size * num_factors
      sqr_sum_embedding = tf.square(sum_embedding)
      sqr_embedding = tf.square(nnz_embedding)
      # batch_size * num_factors
      sum_sqr_embedding = tf.reduce_sum(sqr_embedding, axis=1)
      predictions = 0.5 * tf.subtract(sqr_sum_embedding, sum_sqr_embedding)
      if batch_norm:
        predictions = self._batch_norm(predictions,
                                       train_phase=self.train_phase,
                                       scope_bn='%s/bn_fm' % (model_name))
      predictions = tf.nn.dropout(predictions, self.keep_probs[-1])
      for i in range(0, len(layer_sizes)):
        predictions = tf.add(
            tf.matmul(predictions, parameters[self._get_weight(i)]),
            parameters[self._get_bias(i)])
        if batch_norm:
          scope_bn = '%s/%s' % (model_name, 'bn_%d' % (i))
          predictions = self._batch_norm(predictions,
                                         train_phase=self.train_phase,
                                         scope_bn=scope_bn)
        predictions = activation_function(predictions)
        predictions = tf.nn.dropout(predictions, self.keep_probs[i])
      predictions = tf.matmul(predictions, parameters['prediction'])
      predictions = tf.reduce_sum(predictions, axis=1)
      feature_bias = tf.reduce_sum(
          tf.nn.embedding_lookup(parameters['feature_bias'], self.features),
          axis=1)
      global_bias = parameters['global_bias'] * tf.ones_like(feature_bias)
      predictions = tf.add_n([predictions, feature_bias, global_bias])
    elif model_name == 'mf':
      parameters = dict()
      parameters['feature_embedding'] = tf.Variable(
          tf.random_normal((num_features, num_factors), 0.0, 0.1),
          name='%s/feature_embedding' % (model_name))

      nz_embedding = tf.nn.embedding_lookup(parameters['feature_embedding'],
                                            self.features)
      sum_embedding = tf.reduce_sum(nz_embedding, axis=1)
      # batch_size * num_factors
      sqr_sum_embedding = tf.square(sum_embedding)
      sqr_embedding = tf.square(nz_embedding)
      # batch_size * num_factors
      sum_sqr_embedding = tf.reduce_sum(sqr_embedding, axis=1)

      predictions = 0.5 * (sqr_sum_embedding - sum_sqr_embedding)
      predictions = tf.reduce_sum(predictions, axis=1)
    else:
      raise Exception('unknown model %s' % (model_name))

    return parameters, predictions

  def _shuffle_in_unison(self, features, ratings):
    rng_state = np.random.get_state()
    np.random.shuffle(features)
    np.random.set_state(rng_state)
    np.random.shuffle(ratings)

  def _get_obs_data(self, batch_size):
    train_data = self._data.train_data
    obs_features = []
    obs_ratings = []
    obs_weights = []
    start_index = np.random.randint(0, len(train_data[rkey]) - batch_size)
    # forward to get sample
    i = start_index
    while len(obs_features) < batch_size and i < len(train_data[fkey]):
      if len(train_data[fkey][i]) == len(train_data[fkey][start_index]):
        obs_features.append(train_data[fkey][i])
        obs_ratings.append(train_data[rkey][i])
        obs_weights.append(train_data[wkey][i])
        i = i + 1
      else:
        break
    # backward to get sample
    i = start_index
    while len(obs_features) < batch_size and i >= 0:
      if len(train_data[fkey][i]) == len(train_data[fkey][start_index]):
        obs_features.append(train_data[fkey][i])
        obs_ratings.append(train_data[rkey][i])
        obs_weights.append(train_data[wkey][i])
        i = i - 1
      else:
        break
    obs_data = {fkey: obs_features,
                rkey: obs_ratings,
                wkey: obs_weights}
    return obs_data

  def _fit_obs_data(self, obs_data):
    keep_probs = self._args.keep_probs
    feed_dict = {self.features: obs_data[fkey],
                 self.ratings: obs_data[rkey],
                 self.weights: obs_data[wkey],
                 self.keep_probs: keep_probs,
                 self.train_phase: True}
    fetches = (self.obs_update, self.obs_error, self.obs_loss)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    obs_error = results[1]
    obs_loss = results[2]
    return obs_error

  def _get_mis_data(self, batch_size):
    num_users = self._data.num_users
    num_items = self._data.num_items
    user_features = self._data.user_features
    item_features = self._data.item_features
    users = np.random.choice(num_users, batch_size)
    items = np.random.choice(num_items, batch_size)
    mis_features = []
    for user, item in zip(users, items):
      mis_features.append(user_features[user] + item_features[item])
    mis_data = {fkey: mis_features}
    return mis_data

  def _fit_mis_data(self, mis_data):
    keep_probs = self._args.keep_probs
    feed_dict = {self.features: mis_data[fkey],
                 self.keep_probs: keep_probs,
                 self.train_phase: True}
    fetches = (self.mis_update, self.mis_loss)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    obs_loss = results[1]
    return obs_loss

  def _fit_impt_data(self, obs_data):
    keep_probs = self._args.keep_probs
    feed_dict = {self.features: obs_data[fkey],
                 self.ratings: obs_data[rkey],
                 self.keep_probs: keep_probs,
                 self.train_phase: True}
    fetches = (self.impt_update, self.impt_loss)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    obs_loss = results[1]
    return obs_loss

  def _fit_simultaneously(self, obs_data):
    keep_probs = self._args.keep_probs
    feed_dict = {self.features: obs_data[fkey],
                 self.ratings: obs_data[rkey],
                 self.keep_probs: keep_probs,
                 self.train_phase: True}
    fetches = (self.obs_update, self.impt_update)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    return None

  def _compute_mean_error(self, values, pred_values):
    mae = metrics.mean_absolute_error(values, pred_values)
    mse = metrics.mean_squared_error(values, pred_values)
    return mae, mse

  def _compute_mean_bound(self, errors, eval_data):
    num_users = self._data.num_users
    num_items = self._data.num_items
    num_pairs = num_users * num_items

    eval_size = len(eval_data[rkey])
    propensities = np.asarray(eval_data[pkey]) * 0.05
    mab = num_pairs * np.mean(np.square(np.absolute(errors) / propensities))
    msb = num_pairs * np.mean(np.square(np.square(errors) / propensities))
    scale = math.log(2.0 / 0.0001) / (2 * math.pow(num_pairs, 2.0))
    mab = math.sqrt(scale * mab)
    msb = math.sqrt(scale * msb)
    return mab, msb

  def _eval_pred_model(self, eval_data):
    no_dropout = self._args.no_dropout
    min_value = self._data.min_value
    max_value = self._data.max_value
    eval_size = len(eval_data[rkey])
    feed_dict = {self.features: eval_data[fkey], 
                 self.ratings: eval_data[rkey], 
                 self.keep_probs: no_dropout,
                 self.train_phase: False}
    fetch = self.pred_ratings
    pred_ratings = self.sess.run(fetch, feed_dict=feed_dict)
    pred_ratings = np.reshape(pred_ratings, (eval_size,))
    # pred_ratings = np.maximum(pred_ratings, np.ones(eval_size) * min_value)
    # pred_ratings = np.minimum(pred_ratings, np.ones(eval_size) * max_value)
    ratings = np.reshape(eval_data[rkey], (eval_size,))

    mae, mse = self._compute_mean_error(ratings, pred_ratings)
    bound_errors = ratings - pred_ratings
    mab, msb = self._compute_mean_bound(bound_errors, eval_data)
    return mae, mse, mab, msb

  def _eval_impt_model(self, eval_data):
    no_dropout = self._args.no_dropout
    feed_dict = {self.features: eval_data[fkey], 
                 self.ratings: eval_data[rkey], 
                 self.keep_probs: no_dropout,
                 self.train_phase: False}
    fetches = (self.errors, self.pred_errors, self.impt_errors)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    errors = results[0]
    pred_errors = results[1]
    impt_errors = results[2]

    mae, mse = self._compute_mean_error(errors, pred_errors)
    bound_errors = errors - pred_errors
    mab, msb = self._compute_mean_bound(bound_errors, eval_data)

    # impt_weight = self._args.impt_weight
    impt_weight = 0.60
    impt_errors *= impt_weight
    nae, nse = self._compute_mean_error(errors, impt_errors)
    bound_errors = errors - impt_errors
    nab, nsb = self._compute_mean_bound(bound_errors, eval_data)
    return mae, mse, mab, msb, nae, nse, nab, nsb

  def save_p(self, data, file_name):
    out_dir = self._args.out_dir
    if not path.exists(out_dir):
      os.makedirs(out_dir)
    file_path = path.join(out_dir, file_name)
    pickle.dump(np.asarray(data), open(file_path, 'wb'))

  def _compute_invalid(self, hat_d, bound_d, eval_size):
    assert len(hat_d) == eval_size
    assert len(bound_d) == eval_size
    invalid = 0
    for hat, bound in zip(hat_d, bound_d):
      if hat > bound:
        invalid += 1
    invalid = 1.0 * invalid / eval_size
    return invalid

  def _eval_simultaneously(self, eval_data, epoch):
    no_dropout = self._args.no_dropout
    eval_size = len(eval_data[rkey])
    feed_dict = {self.features: eval_data[fkey], 
                 self.ratings: eval_data[rkey], 
                 self.keep_probs: no_dropout,
                 self.train_phase: False}
    fetches = (self.errors, self.pred_errors, self.impt_errors)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    errors = results[0]
    pred_errors = results[1]

    mae_joint_d = np.absolute(pred_errors)
    mae_error_d = np.absolute(errors)
    mse_joint_d = np.square(pred_errors)
    mse_error_d = np.square(errors)

    # mae_indexes = np.argsort(mae_error_d)
    mae_indexes = np.arange(len(mae_error_d))
    self.save_p(mae_joint_d[mae_indexes], 'mae_joint_d_%d.p' % (epoch))
    self.save_p(mae_error_d[mae_indexes], 'mae_error_d_%d.p' % (epoch))

    # mse_indexes = np.argsort(mse_error_d)
    mse_indexes = np.arange(len(mse_error_d))
    self.save_p(mse_joint_d[mse_indexes], 'mse_joint_d_%d.p' % (epoch))
    self.save_p(mse_error_d[mse_indexes], 'mse_error_d_%d.p' % (epoch))

    invalid_mae = self._compute_invalid(mae_joint_d, mae_error_d, eval_size)
    invalid_mse = self._compute_invalid(mse_joint_d, mse_error_d, eval_size)

    impt_weight = self._args.impt_weight
    impt_errors = results[2]
    mae_naive_d = impt_weight * np.absolute(impt_errors)
    mse_naive_d = impt_weight * np.square(impt_errors)
    self.save_p(mae_naive_d[mae_indexes], 'mae_naive_d_%d.p' % (epoch))
    self.save_p(mse_naive_d[mse_indexes], 'mse_naive_d_%d.p' % (epoch))
    innaive_mae = self._compute_invalid(mae_naive_d, mae_error_d, eval_size)
    innaive_mse = self._compute_invalid(mse_naive_d, mse_error_d, eval_size)
    # print('innaive_mae=%.4f%%' % (innaive_mae * 100))
    # print('innaive_mse=%.4f%%' % (innaive_mse * 100))

    return invalid_mae, invalid_mse, innaive_mae, innaive_mse

  def _check_overfit(self, valid_res):
    tolerance = 3
    if len(valid_res) > tolerance:
      is_overfit = True
      for i in range(-1, -tolerance, -1):
        if valid_res[i] <= valid_res[i - 1]:
          is_overfit = False
          break
    else:
      is_overfit = False
    return is_overfit


class SrRec(BsRec):
  def train(self):
    num_pred_epochs = self._args.num_pred_epochs
    verbose = self._args.verbose
    batch_size = self._args.batch_size
    train_data = self._data.train_data
    valid_data = self._data.valid_data
    test_data = self._data.test_data
    train_size = self._data.train_size

    train_mae, valid_mae, test_mae = [], [], []
    train_mse, valid_mse, test_mse = [], [], []

    for epoch in range(num_pred_epochs):
      self._shuffle_in_unison(train_data[fkey], train_data[rkey])
      num_batches = train_size // batch_size
      for batch in range(num_batches):
        obs_data = self._get_obs_data(batch_size)
        self._fit_obs_data(obs_data)

      train_res = self._eval_pred_model(train_data)
      valid_res = self._eval_pred_model(valid_data)
      test_res = self._eval_pred_model(test_data)
      train_mae.append(train_res[0])
      valid_mae.append(valid_res[0])
      test_mae.append(test_res[0])
      train_mse.append(train_res[1])
      valid_mse.append(valid_res[1])
      test_mse.append(test_res[1])
      if verbose > 0 and (epoch + 1) % verbose == 0:
        print('#%03d train=%.4f valid=%.4f test=%.4f' % 
            (epoch + 1, train_res[1], valid_res[1], test_res[1]))
    print('\n%s' % ('-' * 64))
    best_test = min(test_mse)
    best_epoch = test_mse.index(best_test)
    print ('best=#%03d mae=%.4f mse=%.4f' % 
        (best_epoch + 1, test_mae[best_epoch], test_mse[best_epoch]))
    print('%s\n' % ('-' * 64))

    pred_learning_rate = self._args.pred_learning_rate
    min_weight = self._args.min_weight
    f_data = (trailing_zero(pred_learning_rate),
              trailing_zero(min_weight),)
    test_mae = np.asarray(test_mae)
    test_mse = np.asarray(test_mse)
    mae_file = path.join('data', '%s_%s_mae.p' % f_data)
    pickle.dump(test_mae, open(mae_file, 'wb'))
    mse_file = path.join('data', '%s_%s_mse.p' % f_data)
    pickle.dump(test_mse, open(mse_file, 'wb'))

class Dataset(object):
  def __init__(self, args):
    self._args = args
    base_dir = self._args.base_dir

    self.feat_offset = 2
    self.train_file = base_dir + '.train.libfm'
    self.valid_file = base_dir + '.valid.libfm'
    self.test_file = base_dir + '.test.libfm'
    self.num_features = self.count_num_feature()
    self.nnz_features = self.count_nnz_feature()
    self.train_data, self.valid_data, self.test_data = self.load_data()
    self.train_size = len(self.train_data[fkey])

    user_feat_file = base_dir + '.user_feature.mat'
    self.user_features = self.load_feature(user_feat_file)
    item_feat_file = base_dir + '.item_feature.mat'
    self.item_features = self.load_feature(item_feat_file)

    self.num_users = len(self.user_features)
    self.num_items = len(self.item_features)

  def count_num_feature(self):
    features = set()
    fin = open(self.train_file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      for feature in fields[self.feat_offset:]:
        features.add(feature)
      line = fin.readline()
    fin.close()
    return len(features)

  def count_nnz_feature(self):
    fin = open(self.train_file)
    line = fin.readline()
    fields = line.strip().split()
    fin.close()
    return len(fields) - self.feat_offset

  def load_data(self):
    train_data = self.read_data(self.train_file)
    valid_data = self.read_data(self.valid_file)
    test_data = self.read_data(self.test_file)
    return train_data, valid_data, test_data

  def read_data(self, file):
    features = []
    ratings = []
    propensities = []
    fin = open(file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      features.append([int(feature) for feature in fields[self.feat_offset:]])
      ratings.append(1.0 * float(fields[0]))
      propensities.append(1.0 * float(fields[1]))
      line = fin.readline()
    fin.close()
    propensities = np.asarray(propensities)
    self.min_value = min(ratings)
    self.max_value = max(ratings)
    min_propensity = propensities.min()
    max_propensity = propensities.max()
    min_weight = self._args.min_weight
    weights = propensities - min_propensity
    weights *= (max_propensity - min_weight)
    weights /= (max_propensity - min_propensity)
    weights = 1.0 / (weights + min_weight)
    # weights = np.ones_like(weights)
    min_weight = weights.min()
    max_weight = weights.max()
    # print('min_weight=%f max_weight=%f' % (min_weight, max_weight))
    data = {fkey: features,
            rkey: ratings,
            pkey: propensities,
            wkey: weights}
    return data

  def load_feature(self, file):
    features = []
    fin = open(file)
    line = fin.readline()
    while line:
      features.append([int(feature) for feature in line.strip().split()])
      line = fin.readline()
    return features

def trailing_zero(f):
  s = '%f' % (f)
  s = s.rstrip('0')
  if s.endswith('.'):
    s = s[:-1]
  return s

def parse_args(description):
  parser = argparse.ArgumentParser(description=description)
  parser.add_argument('--base_dir', type=str, default='../data/coat/coat')
  parser.add_argument('--out_dir', type=str, default='./data')

  parser.add_argument('--pretrain_epochs', type=int, default=100)
  parser.add_argument('--interact_epochs', type=int, default=10)
  parser.add_argument('--num_pred_epochs', type=int, default=10)
  parser.add_argument('--num_impt_epochs', type=int, default=20)
  parser.add_argument('--pred_learning_rate', type=float, default=0.005)
  parser.add_argument('--impt_learning_rate', type=float, default=0.01)
  parser.add_argument('--pred_model_name', default='fm', help='nfm|fm')
  parser.add_argument('--impt_model_name', default='fm', help='nfm|fm')

  parser.add_argument('--verbose', type=int, default=10, help='0|1')
  parser.add_argument('--all_reg_coeff', type=float, default=0.001)
  parser.add_argument('--batch_norm', type=int, default=0, help='0|1')
  parser.add_argument('--batch_size', type=int, default=32)
  parser.add_argument('--num_factors', type=int, default=128)
  parser.add_argument('--keep_probs', type=str, default='[0.2,0.5]')
  parser.add_argument('--layer_sizes', type=str, default='[64]')
  parser.add_argument('--activation_func', default='relu',
                 help='identity|relu|sigmoid|tanh')
  parser.add_argument('--optimizer_type', default='adagrad',
                 help='adagrad|adam|sgd|rmsprop')

  # naive error imputation
  parser.add_argument('--impt_rating', type=float, default=0.0)
  parser.add_argument('--impt_weight', type=float, default=0.0)

  # inverse propensity scoring
  parser.add_argument('--min_weight', type=float, default=0.1)
  parser.add_argument('--max_weight', type=float, default=0.0)

  return parser.parse_args()

