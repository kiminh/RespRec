from utils import *

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.dates import date2num
import datetime

x = [datetime.datetime(2011, 1, 4, 0, 0),
     datetime.datetime(2011, 1, 5, 0, 0),
     datetime.datetime(2011, 1, 6, 0, 0)]
x = date2num(x)
x = np.asarray([1.0, 2.0, 3.0])
x = np.arange(3)

y = [4, 9, 2]
z = [1, 2, 3]
k = [11, 12, 13]

ax = plt.subplot(111)
ax.bar(x - 0.2, y, width=0.2, color='b', align='center')
ax.bar(x, z, width=0.2, color='g', align='center')
ax.bar(x + 0.2, k, width=0.2, color='r', align='center')
# ax.xaxis_date()

# plt.show()

eps_file = path.join(out_dir, 'plot_demo.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')
