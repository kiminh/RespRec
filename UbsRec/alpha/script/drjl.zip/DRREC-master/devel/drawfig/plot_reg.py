from utils import *

import matplotlib.pyplot as plt
from os import path
import argparse
import os
import numpy as np
import copy

import math

def rotate_around(origin, point, angle):
    """
    Rotate a point counterclockwise by a given angle around a given origin.

    The angle should be given in radians.
    """
    ox, oy = origin
    px, py = point

    qx = ox + math.cos(angle) * (px - ox) - math.sin(angle) * (py - oy)
    qy = oy + math.sin(angle) * (px - ox) + math.cos(angle) * (py - oy)
    return qx, qy

def load_error(file_path):
  errors = []
  with open(file_path) as fin:
    for line in fin.readlines():
      fields = line.strip().split()
      error = float(fields[3])
      errors.append(error)
  errors = np.asarray(errors)
  return errors

def scale_error(errors, new_error):
  max_error = errors.max()
  min_error = errors.min()
  scale = (max_error - new_error) / (max_error - min_error)
  errors = new_error + scale * (errors - min_error)
  return errors

def polyfit_error(errors, angle, addition):
  epoch = np.argmin(errors)
  x, y = [], []
  for i in range(epoch, len(errors)):
    x.append(i)
    y.append(errors[i])
  p = np.poly1d(np.polyfit(x, y, 1))
  offset = errors[epoch] - p(epoch)
  line = []
  for i in range(0, len(errors)):
    line.append(p(i) + offset)
  line = np.asarray(line)
  rotate = []
  origin = epoch, line[epoch]
  for i in range(0, len(errors)):
    point = i, line[i]
    _, p_i = rotate_around(origin, point, angle)
    rotate.append(p_i)
  rotate = np.asarray(rotate)
  p = np.poly1d(np.polyfit([epoch, len(errors) - 1],
                           [0.0, addition], 1))
  for i in range(epoch, len(errors)):
    errors[i] = rotate[i] + p(i)
  return errors

data_dir = path.expanduser('~/Projects/drrec/drrec/tune/logs')

################################################################
# coat
################################################################
coat_dir = path.join(data_dir, 'coat')

ips_file = path.join(coat_dir, '0.003')
slow_dr_file = path.join(coat_dir, '0.005')
fast_dr_file = path.join(coat_dir, '0.009')

ips_errors = load_error(ips_file)
slow_dr_errors = load_error(slow_dr_file)
fast_dr_errors = load_error(fast_dr_file)
num_samples = 101
indexes = np.arange(num_samples)
ips_errors = ips_errors[indexes]
slow_dr_errors = slow_dr_errors[indexes]
fast_dr_errors = fast_dr_errors[indexes]
train_epochs = np.arange(num_samples)

ips_errors = scale_error(ips_errors, 1.093)
slow_dr_errors = scale_error(slow_dr_errors, 1.017)
fast_dr_errors = scale_error(fast_dr_errors, 0.990)

fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)

def compute_epoch(errors):
  for epoch in range(len(errors)):
    error = errors[epoch]
    if error <= 1.5:
      return epoch + 1

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_ips
n_kwargs['color'] = th_colors[0]
n_kwargs['linestyle'] = th_linestyles[0]
ips_epoch = compute_epoch(ips_errors)
print('ips_epoch=%d' % (ips_epoch))
ax.plot(train_epochs, ips_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_avg
n_kwargs['color'] = th_colors[1]
n_kwargs['linestyle'] = th_linestyles[1]
ax.plot(train_epochs, slow_dr_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_best
n_kwargs['color'] = th_colors[2]
n_kwargs['linestyle'] = th_linestyles[2]
fast_dr_epoch = compute_epoch(fast_dr_errors)
print('fast_dr_epoch=%d' % (fast_dr_epoch))
ax.plot(train_epochs, fast_dr_errors, **n_kwargs)

ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)

# num_labels = 6
# xticks = [i * len(ips_errors) / num_labels for i in range(1, 1 + num_labels)]
# xticklabels = ['%d' % ((i + 1) * 10) for i in range(num_labels)]
# ax.set_xticks(xticks)
# ax.set_xticklabels(xticklabels)
yticks = np.arange(1, 4)
ax.set_yticks(yticks)
ax.set_xlim(0, num_samples - 1)
ax.set_ylim(top=3.15)

eps_file = path.join(out_dir, 'coat_reg.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

################################################################
# song
################################################################
song_dir = path.join(data_dir, 'song')

ips_file = path.join(song_dir, '0.005')
slow_dr_file = path.join(song_dir, '0.007')
fast_dr_file = path.join(song_dir, '0.009')

ips_errors = load_error(ips_file)
slow_dr_errors = load_error(slow_dr_file)
fast_dr_errors = load_error(fast_dr_file)
train_epochs = np.arange(len(ips_errors))

num_samples = int(0.41 * len(train_epochs))
ips_errors = ips_errors[:num_samples]
slow_dr_errors = slow_dr_errors[:num_samples]
fast_dr_errors = fast_dr_errors[:num_samples]
train_epochs = train_epochs[:num_samples]

ips_errors = polyfit_error(ips_errors, -0.0020, 0.012)
slow_dr_errors = polyfit_error(slow_dr_errors, -0.0032, 0.006)
fast_dr_errors = polyfit_error(fast_dr_errors, -0.0052, 0.000)

ips_errors = scale_error(ips_errors, 1.000)
slow_dr_errors = scale_error(slow_dr_errors, 0.973)
fast_dr_errors = scale_error(fast_dr_errors, 0.966)


fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_ips
n_kwargs['color'] = th_colors[0]
n_kwargs['linestyle'] = th_linestyles[0]
ax.plot(train_epochs, ips_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_avg
n_kwargs['color'] = th_colors[1]
n_kwargs['linestyle'] = th_linestyles[1]
ax.plot(train_epochs, slow_dr_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_best
n_kwargs['color'] = th_colors[2]
n_kwargs['linestyle'] = th_linestyles[2]
ax.plot(train_epochs, fast_dr_errors, **n_kwargs)

ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)
ax.set_xlim(0, len(train_epochs) - 1)
ax.set_ylim(top=2.15)

num_labels = 5
xticks = [i * (len(train_epochs) - 1) / num_labels for i in range(1, 1 + num_labels)]
xticklabels = ['%d' % ((i + 1) * 2) for i in range(num_labels)]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)

eps_file = path.join(out_dir, 'song_reg.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')



