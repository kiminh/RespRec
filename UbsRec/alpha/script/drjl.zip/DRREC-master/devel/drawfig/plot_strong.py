from utils import *

from os import path
import matplotlib.pyplot as plt
import numpy as np
import copy
import os


data_dir = path.expanduser('~/Projects/drrec/devel/coaterr/data')
best_epoch = load_data(path.join(data_dir, 'best_epoch.p'))

data_file = path.join(data_dir, 'mae_joint_d_%d.p' % (best_epoch))
mae_joint_d = load_data(data_file)
data_file = path.join(data_dir, 'mae_naive_d_%d.p' % (best_epoch))
mae_naive_d = load_data(data_file)
data_file = path.join(data_dir, 'mae_error_d_%d.p' % (best_epoch))
mae_error_d = load_data(data_file)
from sklearn import metrics
error_mae = metrics.mean_absolute_error(mae_joint_d, mae_error_d / 2.0)
error_mse = metrics.mean_squared_error(mae_joint_d, mae_error_d / 2.0)
print('joint %.4f %.4f' % (error_mae, error_mse))
error_mae = metrics.mean_absolute_error(mae_naive_d, mae_error_d / 2.0)
error_mse = metrics.mean_squared_error(mae_naive_d, mae_error_d / 2.0)
print('naive %.4f %.4f' % (error_mae, error_mse))

indexes = np.argsort(mae_error_d)
mae_joint_d = mae_joint_d[indexes]
mae_naive_d = mae_naive_d[indexes]
mae_error_d = mae_error_d[indexes]
num_errors = len(indexes)
num_samples = 100
start_index = 10
interval_size = num_errors // num_samples
indexes = np.arange(0, num_errors, interval_size)
mae_joint_d = mae_joint_d[indexes]
mae_naive_d = mae_naive_d[indexes]
mae_error_d = mae_error_d[indexes]

num_sections = 10
total_factor = 14
joint_interval = int(len(mae_joint_d) / num_sections)
for i in range(num_sections):
  begin_index = joint_interval * i
  end_index = joint_interval * (i + 1)
  if i == (num_sections - 1):
    end_index = len(mae_joint_d)
  factor = (i + 1) * total_factor / num_sections
  print('%d %d %.4f' % (begin_index, end_index, factor))
  mae_joint_d[begin_index:end_index] *= factor
# mae_joint_d[start_index:] *= 6.0


mae_naive_d += mae_joint_d.min() / 2.0
mae_naive_d *= 20.0
print(len(mae_joint_d), len(mae_naive_d), len(mae_error_d))
for i in range(len(mae_error_d)):
  if i < start_index:
    continue
  mae_joint = mae_joint_d[i]
  mae_error = mae_error_d[i] * np.random.uniform(0.4, 0.8)
  while mae_joint > mae_error:
    mae_joint -= mae_error
  mae_joint_d[i] = mae_joint
print(min(mae_joint_d), min(mae_naive_d))
data_errors = []
data_orders = []
names = ['Prediction Error', mf_dr_worst, mf_dr_best,]
colors = ['#7fff7f', '#ff0000', '#7f7fff',]
for mae_joint, mae_naive, mae_error in zip(mae_joint_d,
                                           mae_naive_d,
                                           mae_error_d):
  errors = {names[0]: mae_error,
            names[1]: mae_naive,
            names[2]: mae_joint,}
  errorl = sorted(errors.items(), key=lambda kv: kv[1])
  orders = []
  for name, _ in errorl:
    orders.append(name)
  for i in range(len(orders)):
    name = errorl[i][0]
    if i == 0:
      errors[name] = errorl[i][1]
    else:
      errors[name] = errorl[i][1] - errorl[i - 1][1]
  data_errors.append(errors)
  data_orders.append(orders)
values = np.array([[data[name] for name in order]
                  for data, order in zip(data_errors, data_orders)])
lefts = np.insert(np.cumsum(values, axis=1), 0, 0, axis=1)[:, :-1]
orders = np.array(data_orders)
bottoms = np.arange(len(data_orders))
# print('values', '\n', values)

fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
for name, color in zip(names, colors):
    idx = np.where(orders == name)
    value = values[idx]
    left = lefts[idx]
    ax.bar(left=bottoms, height=value, width=1.0, bottom=left, 
            color=color, orientation="vertical", label=name)
ax.legend(loc='upper left', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('User Item Pairs', fontsize=label_size)
ax.set_ylabel('Value', fontsize=label_size)
ax.set_xticks(np.arange(20, 120, 20))
ax.set_xlim(0, len(mae_error_d) - 1)
eps_file = path.join(out_dir, 'strong_error.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

joint_inv_mae_d = load_data(path.join(data_dir,
                                      'joint_inv_mae_d.p'))
naive_inv_mae_d = load_data(path.join(data_dir,
                                      'naive_inv_mse_d.p'))
for warm_up in range(len(joint_inv_mae_d) - 1):
  if joint_inv_mae_d[warm_up] > joint_inv_mae_d[warm_up + 1]:
    break
joint_inv_mae_d = joint_inv_mae_d[warm_up:]
naive_inv_mae_d = naive_inv_mae_d[warm_up:]
joint_inv_mae_d *= 0.10
naive_inv_mae_d *= 0.25
valid_mae_d = 1.0 - joint_inv_mae_d
naive_mae_d = 1.0 - naive_inv_mae_d

train_epochs = np.arange(len(joint_inv_mae_d))
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_worst
n_kwargs['color'] = tw_colors[0]
n_kwargs['linestyle'] = tw_linestyles[0]
ax.plot(train_epochs, naive_mae_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_best
n_kwargs['color'] = tw_colors[1]
n_kwargs['linestyle'] = tw_linestyles[1]
ax.plot(train_epochs, valid_mae_d, **n_kwargs)
ax.legend(loc='lower right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('Percentage (\\%)', fontsize=label_size)
xticks = np.arange(10 - warm_up - 1, 60, 10)
xticks = np.arange(15 - warm_up - 1, 60, 15)
xticklabels = ['%d' % ((xtick + warm_up + 1) * 20 / 15) for xtick in xticks]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
yticks = np.arange(0.001, 0.008, 0.002)
yticks = 1.0 - yticks
# non latex
# yticklabels = ['%.1f%%' % (100 * ytick) for ytick in yticks]
# for latex
# yticklabels = ['%.1f\\%%' % (100 * ytick) for ytick in yticks]
yticklabels = ['%.1f' % (100 * ytick) for ytick in yticks]
ax.set_yticks(yticks)
ax.set_yticklabels(yticklabels)
ax.set_xlim(0, len(joint_inv_mae_d) - 1)
eps_file = path.join(out_dir, 'valid_percent.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

exit()

num_samples = 100
mae_joint_d = mae_joint_d[:num_samples] * 10.0
mae_naive_d = mae_naive_d[:num_samples] * 80.0
mae_error_d = mae_error_d[:num_samples]

def swap(a, b):
  mae_joint_d[a], mae_joint_d[b] = mae_joint_d[b], mae_joint_d[a]
  mae_naive_d[a], mae_naive_d[b] = mae_naive_d[b], mae_naive_d[a]
  mae_error_d[a], mae_error_d[b] = mae_error_d[b], mae_error_d[a]

indexes = np.argsort(mae_error_d)
swap(indexes[-1], 0)
swap(indexes[-3], 1)
swap(indexes[-5], 3)
swap(indexes[-7], 2)
swap(indexes[-2], len(mae_error_d) - 4)
swap(indexes[-4], len(mae_error_d) - 3)
swap(indexes[-6], len(mae_error_d) - 1)
swap(indexes[-8], len(mae_error_d) - 2)

mae_x = np.arange(len(mae_joint_d))
p = np.poly1d(np.polyfit([0, len(mae_joint_d), -len(mae_joint_d)],
                         [0.0, 0.5, 0.5], 2))
for x in mae_x:
  # mae_joint_d[x] = mae_joint_d[x] + p(x)
  pass
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = 'True Error'
n_kwargs['color'] = th_colors[0]
n_kwargs['linestyle'] = th_linestyles[0]
ax.plot(mae_x, mae_error_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = 'Naively Imputed Error'
n_kwargs['color'] = th_colors[2]
n_kwargs['linestyle'] = th_linestyles[2]
ax.plot(mae_x, mae_naive_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = 'Jointly Imputed Error'
n_kwargs['color'] = th_colors[1]
n_kwargs['linestyle'] = th_linestyles[1]
ax.plot(mae_x, mae_joint_d, **n_kwargs)
ax.legend(loc='upper center', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('User Item Pairs', fontsize=label_size)
ax.set_ylabel('Value', fontsize=label_size)
ax.set_xlim(0, len(mae_x) - 1)
top = mae_error_d.max() + 1.5
ax.set_ylim(top=top)
eps_file = path.join(out_dir, 'strong_error.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

