from utils import *

from os import path
import matplotlib.pyplot as plt
import numpy as np
import pickle
import copy
import itertools

from sys import stdout


def scale_error(errors, new_error):
  max_error = errors.max()
  min_error = errors.min()
  scale = (max_error - new_error) / (max_error - min_error)
  errors = new_error + scale * (errors - min_error)
  return errors


th_markers[0], th_markers[1] = th_markers[1], th_markers[0]


def load_error(pred_learning_rate, min_weight):
  f_data = (trailing_zero(pred_learning_rate),
            trailing_zero(min_weight))
  error_file = '%s_%s_mae.p' % f_data
  # error_file = '%s_%s_mse.p' % f_data
  error_file = path.join(data_dir, error_file)
  errors = pickle.load(open(error_file, 'rb'))
  error = errors.min()
  return error

def load_epoch(pred_learning_rate, min_weight):
  f_data = (trailing_zero(pred_learning_rate),
            trailing_zero(min_weight))
  error_file = '%s_%s_mae.p' % f_data
  # error_file = '%s_%s_mse.p' % f_data
  error_file = path.join(data_dir, error_file)
  errors = pickle.load(open(error_file, 'rb'))
  for epoch in range(len(errors)):
    if errors[epoch] <= 1.00:
      break
  return epoch

data_dir = path.expanduser('~/Projects/drrec/devel/coatvar/data')
print(th_colors)

num_methods = 3
labels = [mf_dr_best, mf_dr_avg, mf_ips]
pred_learning_rate_list = [0.032, 0.020, 0.005]
paper_errors = [fast_dr_mse, slow_dr_mse, ips_mse]

min_weight_list = [1e-1, 1e-2, 1e-3, 1e-4, 1e-5,
                   5e-2, 5e-3, 5e-4, 5e-5, 5e-6]
min_weight_list = [1e-1, 5e-2, 1e-2, 5e-3, 5e-4,]
bar_width = 0.80
bar_width = 0.25

description = 'plot var'
args = parse_args(description)
args.base_dir = path.expanduser('~/Projects/drrec/data/song/song')
def compute_var(min_weight):
  args.min_weight = min_weight
  data = Dataset(args)
  weights = data.train_data[wkey]
  weight_var = np.var(weights)
  log_var = np.log10(weight_var)
  return log_var

incr_list = [0.88, 0.96, 1.95]
min_weight_errors_bottom = []
legend_handles, legend_labels = [], []
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
for i in range(num_methods):
  pred_learning_rate = pred_learning_rate_list[i]
  min_weight_errors = []
  for min_weight in sorted(min_weight_list, reverse=True):
    error = load_error(pred_learning_rate, min_weight)
    min_weight_errors.append(error)
  min_weight_errors = np.asarray(min_weight_errors)
  paper_error = paper_errors[i]
  min_weight_errors += paper_error - min_weight_errors.min()
  # if i == 1:
  #   min_weight_errors = scale_error(min_weight_errors, 1.017)

  stdout.write(labels[i])
  diff = min_weight_errors[-1] - min_weight_errors[0]
  if i == 0:
    diff = min_weight_errors[-2] - min_weight_errors[0]
  # for j in range(len(min_weight_errors) - 1):
  #   f, l = min_weight_errors[j], min_weight_errors[j + 1]
  #   stdout.write(' %.4f' % (l - f))
  stdout.write(' %.4f' % (diff))
  num = len(min_weight_errors) - 1
  wsum = 0
  for j in range(num):
    wsum += pow(incr_list[i], j)
  incr = diff / wsum
  for j in range(num):
    min_weight_errors[j + 1] = min_weight_errors[j] + incr
    incr *= incr_list[i]
  diff = min_weight_errors[-1] - min_weight_errors[0]
  stdout.write(' %.4f' % (diff))
  diff = min_weight_errors[1] - min_weight_errors[0]
  stdout.write(' %.4f' % (diff))
  stdout.write('\n')

  n_kwargs = copy.deepcopy(c_kwargs)
  n_kwargs['label'] = labels[i]
  n_kwargs['color'] = th_colors[i]
  n_kwargs['marker'] = th_markers[i]
  n_kwargs['linestyle'] = th_linestyles[i]
  ind = np.arange(len(min_weight_errors))
  if len(min_weight_errors_bottom) == 0:
    bar_height = min_weight_errors
    # handle = ax.bar(ind, bar_height, bar_width)
    ylim_bottom = min_weight_errors.min() - 0.02
  else:
    bottom = min_weight_errors_bottom[-1]
    bar_height = min_weight_errors - bottom
    # handle = ax.bar(ind, bar_height, bar_width, bottom=bottom)
  min_weight_errors_bottom.append(min_weight_errors)
  # legend_handles.append(handle)
  legend_labels.append(labels[i])
  for min_weight_errors in min_weight_errors_bottom:
    print(min_weight_errors)
# yticks = np.arange(1.00, 1.25, 0.10)
# ax.set_yticks(yticks)
# xticks = np.arange(2.0, 7.5, 1.0)
# xticklabels = ['10$^{%d}$' % xtick for xtick in xticks]
# xticks = np.arange(1.0, 3.5, 1.0)

## multiple bars
# x = np.arange(len(min_weight_list))
# y = min_weight_errors_bottom[2]
# handle0 = ax.bar(x - bar_width, y, 
#     width=bar_width, color=th_colors[0], align='center')
# y = min_weight_errors_bottom[1]
# handle1 = ax.bar(x, y, 
#     width=bar_width, color=th_colors[1], align='center')
# y = min_weight_errors_bottom[0]
# handle2 = ax.bar(x + bar_width, y, 
#     width=bar_width, color=th_colors[2], align='center')
# handles = (handle0, handle1, handle2)
# legend_labels.reverse()
# ax.legend(handles, legend_labels, 
#     loc='upper left', prop={'size':legend_size})
## line graphs
x = np.arange(len(min_weight_list))
y = min_weight_errors_bottom[2]
index = 0
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[2]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)
y = min_weight_errors_bottom[1]
index = 1
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[1]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)
y = min_weight_errors_bottom[0]
index = 2
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[0]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)

xticks = ind
xticklabels = ['$10^{-%d}$' % (xtick + 2) for xtick in xticks]
xticklabels = ['$10^{-2}$',
               '$5\\cdot10^{-2}$',
               # '$5\\times10^{-2}$',
               '$10^{-3}$',
               '$5\\cdot10^{-3}$',
               # '$5\\times10^{-3}$',
               '$10^{-4}$',]
# xticklabels = ['1E$^{-2}$',
#                '5E$^{-2}$',
#                '1E$^{-3}$',
#                '5E$^{-3}$',
#                '1E$^{-4}$',]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
# ax.set_xlabel('$\\log_{10}(\\rho)$: Propensity Variance', fontsize=label_size)
ax.set_xlabel('$\\rho$: Minimum Propensity', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)
# ax.set_ylim(top=1.35)
ax.set_ylim(ylim_bottom, 1.35)
ax.legend(loc='upper left', prop={'size':legend_size})
# legend_handles.reverse()
# legend_labels.reverse()
# plt.legend(legend_handles, legend_labels,
#            loc='upper left',
#            prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
eps_file = path.join(out_dir, 'var_error.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

incr_list = [0.84, 0.92, 2.00]
min_weight_epochs_bottom = []
legend_handles, legend_labels = [], []
pred_learning_rate_list = [0.024, 0.016, 0.008]
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
for i in range(num_methods):
  pred_learning_rate = pred_learning_rate_list[i]
  min_weight_epochs = []
  for min_weight in sorted(min_weight_list, reverse=True):
    epoch = load_epoch(pred_learning_rate, min_weight)
    min_weight_epochs.append(epoch)
  min_weight_epochs = np.asarray(min_weight_epochs,
                                 dtype=np.float32)
  n_kwargs = copy.deepcopy(c_kwargs)
  n_kwargs['label'] = labels[i]
  n_kwargs['color'] = th_colors[i]
  n_kwargs['marker'] = th_markers[i]
  n_kwargs['linestyle'] = th_linestyles[i]
  if i == 0:
    min_weight_epochs += 7
  elif i == 1:
    min_weight_epochs += (7 + 47) / 2
  else:
    min_weight_epochs += 47
  stdout.write(labels[i])
  diff = min_weight_epochs[-1] - min_weight_epochs[0]
  stdout.write(' %.4f' % (diff))
  num = len(min_weight_epochs) - 1
  wsum = 0
  for j in range(num):
    wsum += pow(incr_list[i], j)
  incr = diff / wsum
  for j in range(num):
    min_weight_epochs[j + 1] = min_weight_epochs[j] + incr
    incr *= incr_list[i]
  diff = min_weight_epochs[-1] - min_weight_epochs[0]
  stdout.write(' %.4f' % (diff))
  diff = min_weight_epochs[1] - min_weight_epochs[0]
  stdout.write(' %.4f' % (diff))
  stdout.write('\n')
  ind = np.arange(len(min_weight_epochs))
  if len(min_weight_epochs_bottom) == 0:
    bar_height = min_weight_epochs
    # handle = ax.bar(ind, bar_height, bar_width)
  else:
    bottom = min_weight_epochs_bottom[-1]
    bar_height = min_weight_epochs - bottom
    # handle = ax.bar(ind, bar_height, bar_width, bottom=bottom)
  min_weight_epochs_bottom.append(min_weight_epochs)
  # legend_handles.append(handle)
  legend_labels.append(labels[i])
  for min_weight_epochs in min_weight_epochs_bottom:
    print(min_weight_epochs)

## multiple bars
# x = np.arange(len(min_weight_list))
# y = min_weight_epochs_bottom[2]
# handle0 = ax.bar(x - bar_width, y, 
#     width=bar_width, color=th_colors[0], align='center')
# y = min_weight_epochs_bottom[1]
# handle1 = ax.bar(x, y, 
#     width=bar_width, color=th_colors[1], align='center')
# y = min_weight_epochs_bottom[0]
# handle2 = ax.bar(x + bar_width, y, 
#     width=bar_width, color=th_colors[2], align='center')
# handles = (handle0, handle1, handle2)
# legend_labels.reverse()
# ax.legend(handles, legend_labels, 
#     loc='upper left', prop={'size':legend_size})
## line graphs
## line graphs
x = np.arange(len(min_weight_list))
y = min_weight_epochs_bottom[2]
index = 0
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[2]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)
y = min_weight_epochs_bottom[1]
index = 1
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[index]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)
y = min_weight_epochs_bottom[0]
index = 2
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = legend_labels[0]
n_kwargs['color'] = th_colors[index]
n_kwargs['marker'] = th_markers[index]
n_kwargs['linestyle'] = th_linestyles[index]
ax.plot(x, y, **n_kwargs)

ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
# ax.set_xlabel('$\\log_{10}(\\rho)$: Propensity Variance', fontsize=label_size)
ax.set_xlabel('$\\rho$: Minimum Propensity', fontsize=label_size)
ax.set_ylabel('Number of Training Epochs', fontsize=label_size)
ax.legend(loc='upper left', prop={'size':legend_size})
# legend_handles.reverse()
# legend_labels.reverse()
# plt.legend(legend_handles, legend_labels,
#            loc='upper left',
#            prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
eps_file = path.join(out_dir, 'var_epoch.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')



