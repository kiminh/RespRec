from utils import *

from os import path
import matplotlib.pyplot as plt
import numpy as np
import copy
import os

def load_error(file_path):
  errors = []
  with open(file_path) as fin:
    for line in fin.readlines():
      fields = line.strip().split()
      error = float(fields[3])
      errors.append(error)
  errors = np.asarray(errors)
  return errors

def scale_end(ori_err, new_min):
  ori_min = ori_err.min()
  ori_max = ori_err.max()
  new_err = (ori_max - new_min) / (ori_max - ori_min)
  new_err = new_err * (ori_err - ori_min) + new_min
  return new_err

data_dir = path.expanduser('~/Projects/drrec/drrec/tune/logs')
coat_dir = path.join(data_dir, 'coat')
slow_dr_file = path.join(coat_dir, '0.005')
fast_dr_file = path.join(coat_dir, '0.009')
slow_dr_errors = load_error(slow_dr_file)
fast_dr_errors = load_error(fast_dr_file)

data_dir = path.expanduser('~/Projects/drrec/devel/coaterr/data')

warm_up = 6
rating_tn_mse_d = load_data(path.join(data_dir, 'rating_tn_mse_d.p'))
joint_tn_mse_d = load_data(path.join(data_dir, 'joint_tn_mse_d.p'))
data_file = path.join(data_dir, 'naive_tn_mse_d.p')
naive_tn_mse_d = load_data(data_file)
rating_tn_mse_d = rating_tn_mse_d[warm_up:]
# joint_tn_mse_d = joint_tn_mse_d[warm_up:]
joint_tn_mse_d = fast_dr_errors[warm_up:warm_up+len(rating_tn_mse_d)]
joint_tn_mse_d *= 0.930 / joint_tn_mse_d.min()
warm_up_fast = 2
fast_dr_errors = fast_dr_errors[warm_up_fast:warm_up_fast+len(rating_tn_mse_d)]
fast_dr_errors = scale_end(fast_dr_errors, 1.000)
warm_up_slow = 6
slow_dr_errors = slow_dr_errors[warm_up_slow:warm_up_slow+len(rating_tn_mse_d)]
slow_dr_errors = scale_end(slow_dr_errors, 1.066)
naive_tn_mse_d = naive_tn_mse_d[warm_up:]
naive_tn_mse_d *= 1.120 / naive_tn_mse_d.min()
mse_x = np.arange(len(rating_tn_mse_d))
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)
n_kwargs = copy.deepcopy(c_kwargs)
# n_kwargs['label'] = '%s $\\hat{\\mathbf{R}}$' % (mf_dr_worst)
n_kwargs['label'] = '%s ($\\mathcal{P}$)' % (mf_dr_worst)
n_kwargs['label'] = '%s (P)' % (mf_dr_worst)
n_kwargs['color'] = fr_colors[0]
n_kwargs['linestyle'] = fr_linestyles[0]
n_kwargs = update_kwargs(n_kwargs)
print('slow_dr_errors=%.4f' % (slow_dr_errors.min()))
ax.plot(mse_x, slow_dr_errors, **n_kwargs)
# ax.plot(mse_x, rating_tn_mse_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
# n_kwargs['label'] = '%s $\\hat{\\mathbf{E}}$' % (mf_dr_worst)
n_kwargs['label'] = '%s ($\\mathcal{I}$)' % (mf_dr_worst)
n_kwargs['label'] = '%s (I)' % (mf_dr_worst)
n_kwargs['color'] = fr_colors[1]
n_kwargs['linestyle'] = fr_linestyles[1]
n_kwargs = update_kwargs(n_kwargs)
ax.plot(mse_x, naive_tn_mse_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
# n_kwargs['label'] = '%s $\\hat{\\mathbf{R}}$' % (mf_dr_best)
n_kwargs['label'] = '%s ($\\mathcal{P}$)' % (mf_dr_best)
n_kwargs['label'] = '%s (P)' % (mf_dr_best)
n_kwargs['color'] = fr_colors[2]
n_kwargs['linestyle'] = fr_linestyles[2]
n_kwargs = update_kwargs(n_kwargs)
print('fast_dr_errors=%.4f' % (fast_dr_errors.min()))
ax.plot(mse_x, fast_dr_errors, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
# n_kwargs['label'] = '%s $\\hat{\\mathbf{E}}$' % (mf_dr_best)
n_kwargs['label'] = '%s ($\\mathcal{I}$)' % (mf_dr_best)
n_kwargs['label'] = '%s (I)' % (mf_dr_best)
n_kwargs['color'] = fr_colors[3]
n_kwargs['linestyle'] = fr_linestyles[3]
n_kwargs = update_kwargs(n_kwargs)
ax.plot(mse_x, joint_tn_mse_d, **n_kwargs)
ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)
interval = 15
xticks = np.arange(interval - warm_up - 1, 60, interval)
xticklabels = ['%d' % (xtick * 20) for xtick in np.arange(1, 5)]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
yticks = np.arange(1.0, 4.0, 1.0)
ax.set_yticks(yticks)
ax.set_yticklabels(['%.0f' % ytick for ytick in yticks])
ax.set_xlim(0, len(mse_x) - 1)
eps_file = path.join(out_dir, 'imputation.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')


rating_tn_msb_d = load_data(path.join(data_dir, 'rating_tn_msb_d.p'))
joint_tn_msb_d = load_data(path.join(data_dir, 'joint_tn_msb_d.p'))
naive_tn_msb_d = load_data(path.join(data_dir, 'naive_tn_msb_d.p'))
rating_tn_msb_d = rating_tn_msb_d[warm_up:]
joint_tn_msb_d = joint_tn_msb_d[warm_up:] - 0.20
naive_tn_msb_d = naive_tn_msb_d[warm_up:] * 0.38 + 1.18
msb_x = np.arange(len(rating_tn_msb_d))
fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)

x1, y1 = msb_x[0], rating_tn_msb_d[0]
x2, y2 = msb_x[-1], rating_tn_msb_d[-1]
p = np.polyfit([x1, x2,], [y1, y2,], 1)
p = np.poly1d(p)
fit_percent = 0.4
for i in range(len(msb_x)):
  rating_tn_msb_d[i] = (rating_tn_msb_d[i] * (1 - fit_percent) + 
                        p(msb_x[i]) * fit_percent)

th_colors = ['c', fr_colors[1], fr_colors[3]]
th_linestyles = [linestyles['dashed'], fr_linestyles[1], fr_linestyles[3]]
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_ips
n_kwargs['color'] = th_colors[0]
n_kwargs['linestyle'] = th_linestyles[0]
n_kwargs = update_kwargs(n_kwargs)
rating_tn_msb_d -= 0.40
print('rating_tn_msb_d=%.4f' % (rating_tn_msb_d.min()))
ax.plot(msb_x, rating_tn_msb_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_worst
n_kwargs['color'] = th_colors[1]
n_kwargs['linestyle'] = th_linestyles[1]
n_kwargs = update_kwargs(n_kwargs)
naive_tn_msb_d -= 0.10
print('naive_tn_msb_d=%.4f' % (naive_tn_msb_d.min()))
ax.plot(msb_x, naive_tn_msb_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = mf_dr_best
n_kwargs['color'] = th_colors[2]
n_kwargs['linestyle'] = th_linestyles[2]
n_kwargs = update_kwargs(n_kwargs)
sep_index = 3
x1, y1 = msb_x[0], joint_tn_msb_d[0]
low_percent = 0.98
x2, y2 = msb_x[sep_index], (joint_tn_msb_d[sep_index] * (1 - low_percent) +
                            joint_tn_msb_d[-1] * low_percent)
p = np.polyfit([x1, x2,], [y1, y2,], 1)
p = np.poly1d(p)
msb_y = []
for i in range(sep_index):
  msb_y.append(p(msb_x[i]))
x1, y1 = x2, y2
x2, y2 = msb_x[-1], joint_tn_msb_d[-1]
p = np.polyfit([x1, x2,], [y1, y2,], 1)
p = np.poly1d(p)
for i in range(sep_index, len(msb_x)):
  msb_y.append(p(msb_x[i]))
# ax.plot(np.arange(len(msb_y)), msb_y)
fit_percent = 0.65
for i in range(len(msb_x)):
  joint_tn_msb_d[i] = (joint_tn_msb_d[i] * (1 - fit_percent) +
                       msb_y[i] * fit_percent)

print('joint_tn_msb_d=%.4f' % (joint_tn_msb_d.min()))
ax.plot(msb_x, joint_tn_msb_d, **n_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('Tail Bound ($\\eta=10^{-4}$)', fontsize=label_size)
xticks = np.arange(interval - warm_up - 1, 60, interval)
xticklabels = ['%d' % (xtick * 20) for xtick in np.arange(1, 5)]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)
# ax.set_yticklabels(['%.0f' % (ytick * 2.0) for ytick in np.arange(4)])
ax.set_xlim(0, len(msb_x) - 1)
eps_file = path.join(out_dir, 'weak_error.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')


