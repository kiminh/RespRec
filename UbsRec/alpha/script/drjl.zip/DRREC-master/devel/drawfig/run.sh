# python -W ignore plot_prop.py
# python -W ignore plot_impt.py
# python -W ignore plot_var.py
# python -W ignore plot_weak.py
# python -W ignore plot_strong.py

pythonw -W ignore plot_prop.py
pythonw -W ignore plot_impt.py
pythonw -W ignore plot_var.py
pythonw -W ignore plot_weak.py
pythonw -W ignore plot_strong.py


# python -W ignore plot_reg.py
# pythonw -W ignore plot_reg.py
