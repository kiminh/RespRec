from matplotlib import rc
rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)

import matplotlib
matplotlib.rcParams['text.usetex'] = True
matplotlib.rcParams['text.latex.unicode'] = True
# matplotlib.rcParams['text.latex.preamble'] = ['\\usepackage{amsmath}']
matplotlib.rcParams['mathtext.fontset'] = 'custom'



from os import path
import os
out_dir = 'data'
if not path.exists(out_dir):
  os.makedirs(out_dir)

mf_ips = 'MF-IPS'
mf_dr_worst = 'MF-DR-HI'
mf_dr_best = 'MF-DR-JL'
mf_dr_avg = 'MF-DR-UI'
width, height = 6.4, 4.8
legend_size = 25
label_size = 25
line_width = 3.5
dotted_width = 4.0
marker_edge_width = 1.5
marker_size = 12
tick_size = 23
pad_inches = 0.10
c_kwargs = {
  'linewidth': line_width,
  'markersize': marker_size,
  'fillstyle': 'none',
  'markeredgewidth': marker_edge_width,
}
th_markers = ['x', 2, 3]
th_colors = ['r', 'g', 'b']
th_linestyles = [':', '-', '-.']
tw_colors = ['r', 'b']
tw_linestyles = ['--', '-',]
fr_colors = ['g', 'r', 'b', 'm']
fr_linestyles = [':', '-', '-.', '--']
from collections import OrderedDict
linestyles = OrderedDict(
    [('solid',               (0, ())),
     ('loosely dotted',      (0, (1, 10))),
     ('dotted',              (0, (1, 5))),
     ('densely dotted',      (0, (1, 1))),

     ('loosely dashed',      (0, (5, 10))),
     ('dashed',              (0, (5, 5))),
     ('densely dashed',      (0, (5, 1))),

     ('loosely dashdotted',  (0, (3, 10, 1, 10))),
     ('dashdotted',          (0, (3, 5, 1, 5))),
     ('densely dashdotted',  (0, (3, 1, 1, 1))),

     ('loosely dashdotdotted', (0, (3, 10, 1, 10, 1, 10))),
     ('dashdotdotted',         (0, (3, 5, 1, 5, 1, 5))),
     ('densely dashdotdotted', (0, (3, 1, 1, 1, 1, 1)))])
th_linestyles = [linestyles['dashed'],
                 linestyles['solid'],
                 linestyles['dotted'],]
tw_linestyles = [linestyles['dashed'],
                 linestyles['solid'],]
fr_linestyles = [linestyles['dashed'],
                 linestyles['dotted'],
                 linestyles['dashdotted'],
                 linestyles['solid'],]
fr_colors = ['m', 'r', 'b', 'g']

ips_mse = 1.093
slow_dr_mse = 1.027
fast_dr_mse = 0.990

# estimator
import numpy as np
estimator_dir = path.expanduser('~/Projects/drrec/devel/estimator/data')
error_dir = path.join(estimator_dir, 'error')
alpha_dir = path.join(estimator_dir, 'alpha')
beta_dir = path.join(estimator_dir, 'beta')
f_alpha = 0.50
mae_offset, mse_offset = 0.0008, 0.0020
v_beta = np.arange(0.00, 1.05, 0.10)

import pickle
def load_data(file_path):
  data = pickle.load(open(file_path, 'rb'))
  return data

import os
from os import path
from sklearn import metrics
from tensorflow.contrib.layers.python.layers import batch_norm
import argparse
import numpy as np
import tensorflow as tf
import time
import pickle
import math

fkey = 'feature'
rkey = 'rating'
pkey = 'propensity'
wkey = 'weight'
itype = tf.int32
ftype = tf.float32

class Dataset(object):
  def __init__(self, args):
    self._args = args
    base_dir = self._args.base_dir

    self.feat_offset = 2
    self.train_file = base_dir + '.train.libfm'
    self.valid_file = base_dir + '.valid.libfm'
    self.test_file = base_dir + '.test.libfm'
    self.num_features = self.count_num_feature()
    self.nnz_features = self.count_nnz_feature()
    self.train_data, self.valid_data, self.test_data = self.load_data()
    self.train_size = len(self.train_data[fkey])

    user_feat_file = base_dir + '.user_feature.mat'
    self.user_features = self.load_feature(user_feat_file)
    item_feat_file = base_dir + '.item_feature.mat'
    self.item_features = self.load_feature(item_feat_file)

    self.num_users = len(self.user_features)
    self.num_items = len(self.item_features)

  def count_num_feature(self):
    features = set()
    fin = open(self.train_file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      for feature in fields[self.feat_offset:]:
        features.add(feature)
      line = fin.readline()
    fin.close()
    return len(features)

  def count_nnz_feature(self):
    fin = open(self.train_file)
    line = fin.readline()
    fields = line.strip().split()
    fin.close()
    return len(fields) - self.feat_offset

  def load_data(self):
    train_data = self.read_data(self.train_file)
    valid_data = self.read_data(self.valid_file)
    test_data = self.read_data(self.test_file)
    return train_data, valid_data, test_data

  def read_data(self, file):
    features = []
    ratings = []
    propensities = []
    fin = open(file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      features.append([int(feature) for feature in fields[self.feat_offset:]])
      ratings.append(1.0 * float(fields[0]))
      propensities.append(1.0 * float(fields[1]))
      line = fin.readline()
    fin.close()
    propensities = np.asarray(propensities)
    self.min_value = min(ratings)
    self.max_value = max(ratings)
    min_propensity = propensities.min()
    max_propensity = propensities.max()
    min_weight = self._args.min_weight
    weights = propensities - min_propensity
    weights *= (max_propensity - min_weight)
    weights /= (max_propensity - min_propensity)
    weights = 1.0 / (weights + min_weight)
    # weights = np.ones_like(weights)
    min_weight = weights.min()
    max_weight = weights.max()
    # print('min_weight=%f max_weight=%f' % (min_weight, max_weight))
    data = {fkey: features,
            rkey: ratings,
            pkey: propensities,
            wkey: weights}
    return data

  def load_feature(self, file):
    features = []
    fin = open(file)
    line = fin.readline()
    while line:
      features.append([int(feature) for feature in line.strip().split()])
      line = fin.readline()
    return features

def trailing_zero(f):
  s = '%f' % (f)
  s = s.rstrip('0')
  if s.endswith('.'):
    s = s[:-1]
  return s

def update_kwargs(n_kwargs):
  flag = False
  # print(n_kwargs['linestyle'])
  # print(type(n_kwargs['linestyle']))
  if n_kwargs['linestyle'] == (0, (1, 10)):
    flag = True
  if n_kwargs['linestyle'] == (0, (1, 5)):
    flag = True
  if n_kwargs['linestyle'] == (0, (1, 1)):
    flag = True
  if flag:
    n_kwargs['linewidth'] = dotted_width
  print(flag)
  return n_kwargs

def parse_args(description):
  parser = argparse.ArgumentParser(description=description)
  parser.add_argument('--base_dir', type=str, default='../data/coat/coat')
  parser.add_argument('--out_dir', type=str, default='./data')

  parser.add_argument('--pretrain_epochs', type=int, default=100)
  parser.add_argument('--interact_epochs', type=int, default=10)
  parser.add_argument('--num_pred_epochs', type=int, default=10)
  parser.add_argument('--num_impt_epochs', type=int, default=20)
  parser.add_argument('--pred_learning_rate', type=float, default=0.005)
  parser.add_argument('--impt_learning_rate', type=float, default=0.01)
  parser.add_argument('--pred_model_name', default='fm', help='nfm|fm')
  parser.add_argument('--impt_model_name', default='fm', help='nfm|fm')

  parser.add_argument('--verbose', type=int, default=10, help='0|1')
  parser.add_argument('--all_reg_coeff', type=float, default=0.001)
  parser.add_argument('--batch_norm', type=int, default=0, help='0|1')
  parser.add_argument('--batch_size', type=int, default=32)
  parser.add_argument('--num_factors', type=int, default=128)
  parser.add_argument('--keep_probs', type=str, default='[0.2,0.5]')
  parser.add_argument('--layer_sizes', type=str, default='[64]')
  parser.add_argument('--activation_func', default='relu',
                 help='identity|relu|sigmoid|tanh')
  parser.add_argument('--optimizer_type', default='adagrad',
                 help='adagrad|adam|sgd|rmsprop')

  # naive error imputation
  parser.add_argument('--impt_rating', type=float, default=0.0)
  parser.add_argument('--impt_weight', type=float, default=0.0)

  # inverse propensity scoring
  parser.add_argument('--min_weight', type=float, default=0.1)
  parser.add_argument('--max_weight', type=float, default=0.0)

  return parser.parse_args()
