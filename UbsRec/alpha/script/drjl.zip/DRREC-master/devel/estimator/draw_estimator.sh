python draw_alpha.py

python draw_gamma.py
python draw_omega.py

python draw_beta.py
python draw_error.py
