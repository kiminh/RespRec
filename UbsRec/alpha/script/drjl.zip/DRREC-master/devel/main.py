import tensorflow as tf

x_ = tf.placeholder(tf.float32, shape=(2), name='x')
y_ = tf.placeholder(tf.float32, shape=(2), name='y')
z_ = x_ * x_ + y_ * y_
# g_ = tf.gradients(z_, [x_, y_], gate_gradients=False)
# g_ = tf.gradients(z_, [x_, y_], gate_gradients=True)
g_ = tf.gradients(y_, [x_], gate_gradients=True)
x = [1.0, 1.0]
y = [1.0, 1.0]
feed_dict = {x_: x, y_: y}
sess = tf.Session()
g = sess.run(g_, feed_dict=feed_dict)
print(type(g), g)

exit()

from os import path
import numpy as np

def compute_stat(prop_mat):
  prop_min = prop_mat.min()
  prop_max = prop_mat.max()
  prop_std = np.std(prop_mat)
  prop_var = np.var(prop_mat)
  f_data = (prop_min, prop_max, prop_std, prop_var)
  print('min=%.8f max=%.8f std=%.8f var=%.8f' % f_data)

def scale_by_min(prop_mat, new_min):
  prop_min = prop_mat.min()
  prop_max = prop_mat.max()
  scale_ratio = (prop_max - new_min) / (prop_max - prop_min)
  prop_mat = (prop_mat - prop_min) * scale_ratio + new_min
  return prop_mat

def scale_by_max(prop_mat, new_max):
  prop_min = prop_mat.min()
  prop_max = prop_mat.max()
  scale_ratio = (new_max - prop_min) / (prop_max - prop_min)
  prop_mat = (prop_mat - prop_min) * scale_ratio + prop_min
  return prop_mat

def load_coat_rating(in_file):
  ratings = []
  rating_mat = np.loadtxt(in_file, dtype=np.int32)
  users, items = rating_mat.nonzero()
  for user, item in zip(users, items):
    rating = rating_mat[user, item]
    ratings.append((user, item, rating))
  return ratings

def main():
  dnld_dir = path.expanduser('~/Downloads/coat')
  train_in_file = path.join(dnld_dir, 'train.ascii')
  prop_file = path.join(dnld_dir, 'propensities.ascii')

  train_ratings = load_coat_rating(train_in_file)
  prop_mat = np.loadtxt(prop_file)

  obs_propensity = []
  for user, item, _ in train_ratings:
    obs_propensity.append(prop_mat[user, item])
  obs_propensity = np.asarray(obs_propensity)
  obs_propensity = 1.0 / obs_propensity

  compute_stat(obs_propensity)

  # compute_stat(scale_by_min(obs_propensity, 0.001))
  # compute_stat(scale_by_min(obs_propensity, 0.0005))
  # compute_stat(scale_by_min(obs_propensity, 0.0001))
  # compute_stat(scale_by_min(obs_propensity, 0.00005))

  compute_stat(scale_by_max(obs_propensity, 1.0 / 0.002))
  compute_stat(scale_by_max(obs_propensity, 1.0 / 0.001))
  compute_stat(scale_by_max(obs_propensity, 1.0 / 0.0005))
  compute_stat(scale_by_max(obs_propensity, 1.0 / 0.0002))
  compute_stat(scale_by_max(obs_propensity, 1.0 / 0.0001))

import numpy as np

small = 1.12227074
large = 1.12464986
large = 1.13169319
num_methods = 9
interval = (large - small) / (num_methods - 1)
value = []
for i in range(num_methods):
  value.append(small + i * interval)
value = np.asarray(value)
np.random.shuffle(value)
for v in value:
  print('%.6f' % (v))

if __name__ == '__main__':
  main()

