base_dir=~/Projects/drrec/data/coat/coat

batch_norm=0 # better
# batch_norm=1
batch_size=128
num_factors=128
keep_probs='[0.6]'
all_reg_coeff=0.001
pred_learning_rate=0.01
python -W ignore ../fm.py \
    --base_dir ${base_dir} \
    --pred_model_name fm \
    --optimizer_type adagrad \
    --num_pred_epochs 200 \
    --verbose 10 \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs} \
    --pred_learning_rate ${pred_learning_rate} \
# 1.0105 - 1.0420
# best=#060 mae=0.7795 mse=1.0105
# best=#109 mae=0.7876 mse=1.0269
# best=#146 mae=0.7902 mse=1.0298
# best=#046 mae=0.7925 mse=1.0300
# best=#100 mae=0.7927 mse=1.0318
# best=#143 mae=0.7906 mse=1.0368
