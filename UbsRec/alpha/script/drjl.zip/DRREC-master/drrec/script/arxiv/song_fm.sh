base_dir=~/Projects/drrec/data/song/song
num_pred_epochs=10
verbose=1

batch_norm=0
batch_size=128
num_factors=128
keep_probs=[0.6]
all_reg_coeff=0.001
pred_learning_rate=0.005
python -W ignore ../fm.py \
    --base_dir ${base_dir} \
    --pred_model_name fm \
    --optimizer_type adagrad \
    --num_pred_epochs ${num_pred_epochs} \
    --verbose ${verbose} \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs} \
    --pred_learning_rate ${pred_learning_rate}
