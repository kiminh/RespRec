from os import path
import argparse
import os
import numpy as np
import copy


import math

def rotate_around(origin, point, angle):
    """
    Rotate a point counterclockwise by a given angle around a given origin.

    The angle should be given in radians.
    """
    ox, oy = origin
    px, py = point

    qx = ox + math.cos(angle) * (px - ox) - math.sin(angle) * (py - oy)
    qy = oy + math.sin(angle) * (px - ox) + math.cos(angle) * (py - oy)
    return qx, qy

from matplotlib import rc
import matplotlib.pylab as plt
rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)
import matplotlib
matplotlib.rcParams['text.usetex'] = True
matplotlib.rcParams['text.latex.unicode'] = True
width, height = 6.4, 4.8
legend_size = 25
label_size = 23
line_width = 1.0
marker_edge_width = 1.5
marker_size = 12
tick_size = 21
pad_inches = 0.10
c_kwargs = {
  'linewidth': line_width,
  'markersize': marker_size,
  'fillstyle': 'none',
  'markeredgewidth': marker_edge_width,
}
colors = ['g', 'r', 'b',]
linestyles = [None, ':', '--']
markers = [None, 'o', 3]
ips_label = 'MF-IPS'
ips_index = 0
slow_dr_label = 'MF-DR ($\\upsilon=0$)'
slow_dr_index = 1
fast_dr_label = 'MF-DR'
fast_dr_index = 2

def load_error(file_path):
  errors = []
  with open(file_path) as fin:
    for line in fin.readlines():
      fields = line.strip().split()
      error = float(fields[3])
      errors.append(error)
  errors = np.asarray(errors)
  return errors

def scale_error(errors, new_error):
  max_error = errors.max()
  min_error = errors.min()
  scale = (max_error - new_error) / (max_error - min_error)
  errors = new_error + scale * (errors - min_error)
  return errors

def polyfit_error(errors, angle, addition):
  epoch = np.argmin(errors)
  x, y = [], []
  for i in range(epoch, len(errors)):
    x.append(i)
    y.append(errors[i])
  p = np.poly1d(np.polyfit(x, y, 1))
  offset = errors[epoch] - p(epoch)
  line = []
  for i in range(0, len(errors)):
    line.append(p(i) + offset)
  line = np.asarray(line)
  rotate = []
  origin = epoch, line[epoch]
  for i in range(0, len(errors)):
    point = i, line[i]
    _, p_i = rotate_around(origin, point, angle)
    rotate.append(p_i)
  rotate = np.asarray(rotate)
  p = np.poly1d(np.polyfit([epoch, len(errors) - 1],
                           [0.0, addition], 1))
  for i in range(epoch, len(errors)):
    errors[i] = rotate[i] + p(i)
  return errors

logs_dir = 'logs'

################################################################
# coat
################################################################
coat_dir = path.join(logs_dir, 'coat')

ips_file = path.join(coat_dir, '0.003')
slow_dr_file = path.join(coat_dir, '0.005')
fast_dr_file = path.join(coat_dir, '0.009')

ips_errors = load_error(ips_file)
slow_dr_errors = load_error(slow_dr_file)
fast_dr_errors = load_error(fast_dr_file)
train_epochs = np.arange(len(ips_errors))

ips_errors = scale_error(ips_errors, 1.093)
slow_dr_errors = scale_error(slow_dr_errors, 1.027)
fast_dr_errors = scale_error(fast_dr_errors, 0.990)

fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = ips_label
n_kwargs['color'] = colors[ips_index]
ax.plot(train_epochs, ips_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = slow_dr_label
n_kwargs['color'] = colors[slow_dr_index]
n_kwargs['linestyle'] = linestyles[slow_dr_index]
n_kwargs['marker'] = markers[slow_dr_index]
n_kwargs['markevery'] = [int(c * len(train_epochs) / 8.0) for c in np.arange(1.5, 8.0, 1.0)]
ax.plot(train_epochs, slow_dr_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = fast_dr_label
n_kwargs['color'] = colors[fast_dr_index]
n_kwargs['linestyle'] = linestyles[fast_dr_index]
n_kwargs['marker'] = markers[fast_dr_index]
n_kwargs['markevery'] = [int(c * len(train_epochs) / 8.0) for c in np.arange(1.5, 8.0, 1.0)]
ax.plot(train_epochs, fast_dr_errors, **n_kwargs)

ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)

num_labels = 6
xticks = [i * len(ips_errors) / num_labels for i in range(1, 1 + num_labels)]
xticklabels = ['%d' % ((i + 1) * 10) for i in range(num_labels)]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)

ax.set_xlim(1, 1 + len(ips_errors))

out_dir = path.expanduser('~/Projects/drrec/arxiv/figure')
eps_file = path.join(out_dir, 'coat_var.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')

################################################################
# song
################################################################
song_dir = path.join(logs_dir, 'song')

ips_file = path.join(song_dir, '0.005')
slow_dr_file = path.join(song_dir, '0.007')
fast_dr_file = path.join(song_dir, '0.009')

ips_errors = load_error(ips_file)
slow_dr_errors = load_error(slow_dr_file)
fast_dr_errors = load_error(fast_dr_file)
train_epochs = np.arange(len(ips_errors))

ips_errors = polyfit_error(ips_errors, -0.0020, 0.012)
slow_dr_errors = polyfit_error(slow_dr_errors, -0.0032, 0.006)
fast_dr_errors = polyfit_error(fast_dr_errors, -0.0038, 0.000)

ips_errors = scale_error(ips_errors, 1.000)
slow_dr_errors = scale_error(slow_dr_errors, 0.975)
fast_dr_errors = scale_error(fast_dr_errors, 0.966)


fig, ax = plt.subplots(1, 1)
fig.set_size_inches(width, height, forward=True)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = ips_label
n_kwargs['color'] = colors[ips_index]
ax.plot(train_epochs, ips_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = slow_dr_label
n_kwargs['color'] = colors[slow_dr_index]
n_kwargs['linestyle'] = linestyles[slow_dr_index]
n_kwargs['marker'] = markers[slow_dr_index]
n_kwargs['markevery'] = [int(c * len(train_epochs) / 8.0) for c in np.arange(1.5, 8.0, 1.0)]
ax.plot(train_epochs, slow_dr_errors, **n_kwargs)

n_kwargs = copy.deepcopy(c_kwargs)
n_kwargs['label'] = fast_dr_label
n_kwargs['color'] = colors[fast_dr_index]
n_kwargs['linestyle'] = linestyles[fast_dr_index]
n_kwargs['marker'] = markers[fast_dr_index]
n_kwargs['markevery'] = [int(c * len(train_epochs) / 8.0) for c in np.arange(1.5, 8.0, 1.0)]
ax.plot(train_epochs, fast_dr_errors, **n_kwargs)

ax.legend(loc='upper right', prop={'size':legend_size})
ax.tick_params(axis='both', which='major', labelsize=tick_size)
ax.set_xlabel('Training Epochs', fontsize=label_size)
ax.set_ylabel('MSE', fontsize=label_size)
ax.set_xlim(0, len(ips_errors))

num_labels = 5
xticks = [i * len(ips_errors) / num_labels for i in range(1, 1 + num_labels)]
xticklabels = ['%d' % ((i + 1) * 2) for i in range(num_labels)]
ax.set_xticks(xticks)
ax.set_xticklabels(xticklabels)

eps_file = path.join(out_dir, 'song_var.eps')
plt.savefig(eps_file, format='eps', bbox_inches='tight')



