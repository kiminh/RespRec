from os import path
import argparse
import os
import numpy as np

from matplotlib import rc
import matplotlib.pylab as plt

rc('font', **{'family': 'serif', 'serif': ['Times']})
rc('text', usetex=True)
import matplotlib
matplotlib.rcParams['text.usetex'] = True
matplotlib.rcParams['text.latex.unicode'] = True

parser = argparse.ArgumentParser()
parser.add_argument('dataset', type=str)
args = parser.parse_args()

dataset = args.dataset
logs_dir = path.join('logs', dataset)
fig, ax = plt.subplots(1, 1)
for file_name in os.listdir(logs_dir):
  if dataset == 'coat':
    if file_name not in ['0.003', '0.005', '0.009']:
      continue
  file_path = path.join(logs_dir, file_name)
  mse_list = []
  with open(file_path) as fin:
    for line in fin.readlines():
      fields = line.strip().split()
      mse = float(fields[3])
      mse_list.append(mse)
  epochs = np.arange(len(mse_list))
  ax.plot(epochs, mse_list, label=file_name)
  print(file_name, min(mse_list))
ax.legend(bbox_to_anchor=(0., 1.02, 1., .102),
          loc=4, ncol=5, mode='expand')
eps_file = path.join('logs', '%s_all.eps' % (dataset))
plt.savefig(eps_file, format='eps', bbox_inches='tight')


