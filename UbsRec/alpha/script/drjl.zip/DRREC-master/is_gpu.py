import argparse
import os
import sys
import tensorflow as tf

# disable all debugging logs
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
# os.environ['CUDA_VISIBLE_DEVICES']= '0'

def is_gpu():
  a = tf.constant([1.0, 2.0, 3.0, 4.0, 5.0, 6.0], shape=[2, 3], name='a')
  b = tf.constant([1.0, 2.0, 3.0, 4.0, 5.0, 6.0], shape=[3, 2], name='b')
  c = tf.matmul(a, b)
  sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))
  print(sess.run(c))

def demo():
  a = tf.constant([[[111, 112, 113], [121, 122, 123]],
                   [[211, 212, 213], [221, 222, 223]],
                   [[311, 312, 313], [321, 322, 323]],
                   [[411, 412, 413], [421, 422, 423]],],
                  dtype=tf.int32)
  b = tf.reshape(a, (a.get_shape().as_list()[0], -1))
  sess = tf.Session()
  print(sess.run(tf.reduce_prod(a, axis=1)))
  print(sess.run(b))
  c = tf.placeholder(tf.int32, (None, 2, 3))
  print(c.shape)
  d = tf.reshape(c, (tf.shape(c)[0], -1))
  print(d.shape)
  feed_dict = {c:sess.run(a)}
  print(sess.run(d, feed_dict=feed_dict))

parser = argparse.ArgumentParser()
parser.add_argument('--task', type=str, default='is_gpu')
args = parser.parse_args()

module = sys.modules[__name__]
getattr(module, args.task)()

