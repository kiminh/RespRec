batch_norm=0
batch_size=128
hidden_factor=128
keep_prob=0.6
lamda=0.001
lr=0.01
python -W ignore fm.py \
    --path ../data/ \
    --dataset coat \
    --loss_type square_loss \
    --pretrain 0 \
    --optimizer AdagradOptimizer \
    --epoch 200 \
    --verbose 1 \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --hidden_factor ${hidden_factor} \
    --lamda ${lamda} \
    --keep_prob ${keep_prob} \
    --lr ${lr} \
