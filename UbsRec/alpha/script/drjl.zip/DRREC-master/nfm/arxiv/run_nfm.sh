batch_norm=0
batch_size=64
hidden_factor=128
keep_prob='[0.2,0.5]'
lamda=0.01
lr=0.05
layers='[64]'
python -W ignore nfm.py \
    --path ../data/ \
    --dataset coat \
    --loss_type square_loss \
    --pretrain 0 \
    --optimizer AdagradOptimizer \
    --epoch 200 \
    --verbose 10 \
    --early_stop 0 \
    --activation relu \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --hidden_factor ${hidden_factor} \
    --keep_prob ${keep_prob} \
    --lamda ${lamda} \
    --lr ${lr} \
    --layers ${layers}

