from utils import fkey, rkey
import utils

import os
import numpy as np
import tensorflow as tf
from sklearn import metrics
from time import time
import argparse
from tensorflow.contrib.layers.python.layers import batch_norm as batch_norm


class FmRec():
  def __init__(self, args, data):
    self._args = args
    self._data = data
    self._args.keep_probs = eval(self._args.keep_probs)
    self._args.no_dropout = np.ones_like(self._args.keep_probs)
    
    random_seed = 2016
    tf.set_random_seed(random_seed)

    self.features = tf.placeholder(tf.int32, shape=(None, None))
    self.ratings = tf.placeholder(tf.float32, shape=(None,))
    self.keep_probs = tf.placeholder(tf.float32, shape=(None,))
    self.is_train = tf.placeholder(tf.bool)

    self._init_graph()

  def _init_graph(self):
    pretrain = self._args.pretrain
    num_factors = self._args.num_factors
    num_features = self._data.num_features
    parameters = dict()
    if pretrain > 0:
      # todo
      weight_saver = tf.train.import_meta_graph(self.save_file + '.meta')
      pretrain_graph = tf.get_default_graph()
      feature_embedding = pretrain_graph.get_tensor_by_name('feature_embedding:0')
      feature_bias = pretrain_graph.get_tensor_by_name('feature_bias:0')
      global_bias = pretrain_graph.get_tensor_by_name('global_bias:0')
      with tf.Session() as sess:
        weight_saver.restore(sess, self.save_file)
        fe, fb, b = sess.run([feature_embedding, feature_bias, global_bias])
      parameters['feature_embedding'] = tf.Variable(fe, dtype=tf.float32)
      parameters['feature_bias'] = tf.Variable(fb, dtype=tf.float32)
      parameters['global_bias'] = tf.Variable(b, dtype=tf.float32)
    else:
      parameters['feature_embedding'] = tf.Variable(
          tf.random_normal((num_features, num_factors), 0.0, 0.01),
          name='feature_embedding')  # num_features * K
      parameters['feature_bias'] = tf.Variable(
          tf.random_uniform((num_features,), 0.0, 0.0), name='feature_bias')  # num_features * 1
      parameters['global_bias'] = tf.Variable(tf.constant(0.0), name='global_bias')  # 1 * 1

    nz_embedding = tf.nn.embedding_lookup(parameters['feature_embedding'],
                                          self.features)
    sum_embedding = tf.reduce_sum(nz_embedding, axis=1)
    # batch_size, num_factors
    sqr_sum_embedding = tf.square(sum_embedding)
    sqr_embedding = tf.square(nz_embedding)
    # batch_size, num_factors
    sum_sqr_embedding = tf.reduce_sum(sqr_embedding, axis=1)

    batch_norm = self._args.batch_norm
    # batch_size, num_factors
    pred_ratings = 0.5 * (sqr_sum_embedding - sum_sqr_embedding)
    if batch_norm:
      pred_ratings = self._batch_norm(pred_ratings,
                                     is_train=self.is_train,
                                     scope_bn='bn_fm')
    pred_ratings = tf.nn.dropout(pred_ratings, self.keep_probs[-1])

    # batch_size,
    pred_ratings = tf.reduce_sum(pred_ratings, axis=1)
    feature_bias = tf.nn.embedding_lookup(parameters['feature_bias'],
                                          self.features)
    # batch_size,
    feature_bias = tf.reduce_sum(feature_bias, axis=1)
    global_bias = parameters['global_bias'] * tf.ones_like(feature_bias)
    pred_ratings = tf.add_n([pred_ratings, feature_bias, global_bias])
    self.pred_ratings = pred_ratings

    all_reg_coeff = self._args.all_reg_coeff
    obs_loss = tf.nn.l2_loss(tf.subtract(self.ratings, pred_ratings))
    if all_reg_coeff > 0:
      l2_regularizer = tf.contrib.layers.l2_regularizer(all_reg_coeff)
      obs_loss += l2_regularizer(parameters['feature_embedding'])
    self.obs_loss = obs_loss

    pred_learning_rate = self._args.pred_learning_rate
    optimizer = self._get_optimizer(pred_learning_rate)
    self.obs_update = optimizer.minimize(self.obs_loss)

    verbose = self._args.verbose
    if verbose > 0:
      num_parameters = 0
      for variable in parameters.values():
        shape = variable.get_shape()
        var_parameters = 1
        for dim in shape:
          var_parameters *= dim.value
        num_parameters += var_parameters
      print('#parameters=%d' % (num_parameters)) 

    self.saver = tf.train.Saver()
    init = tf.global_variables_initializer()
    self.sess = tf.Session()
    self.sess.run(init)

  def _batch_norm(self, in_tensor, is_train, scope_bn):
    bn_train = batch_norm(in_tensor,
                          decay=0.9,
                          center=True,
                          scale=True,
                          updates_collections=None,
                          is_training=True,
                          reuse=None,
                          trainable=True,
                          scope=scope_bn)
    bn_test = batch_norm(in_tensor,
                         decay=0.9,
                         center=True,
                         scale=True,
                         updates_collections=None,
                         is_training=False,
                         reuse=True,
                         trainable=True,
                         scope=scope_bn)
    out_tensor = tf.cond(is_train, lambda: bn_train, lambda: bn_test)
    return out_tensor

  def _get_optimizer(self, learning_rate):
    optimizer_type = self._args.optimizer_type
    if optimizer_type == 'adam':
      optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate, beta1=0.9, beta2=0.999, epsilon=1e-8)
    elif optimizer_type == 'adagrad':
      optimizer = tf.train.AdagradOptimizer(learning_rate=learning_rate, initial_accumulator_value=1e-8)
    elif optimizer_type == 'sgd':
      optimizer = tf.train.GradientDescentOptimizer(learning_rate=learning_rate)
    elif optimizer_type == 'rmsprop':
      optimizer = tf.train.RMSPropOptimizer(learning_rate=learning_rate)
    else:
      raise Exception('unknown optimizer %s' % (optimizer_type))
    return optimizer

  def _shuffle_in_unison(self, features, ratings):
    rng_state = np.random.get_state()
    np.random.shuffle(features)
    np.random.set_state(rng_state)
    np.random.shuffle(ratings)

  def _get_obs_data(self, batch_size):
    train_data = self._data.train_data
    start_index = np.random.randint(0, len(train_data[rkey]) - batch_size)
    obs_features = []
    obs_ratings = []
    # forward to get sample
    i = start_index
    while len(obs_features) < batch_size and i < len(train_data[fkey]):
      if len(train_data[fkey][i]) == len(train_data[fkey][start_index]):
        obs_features.append(train_data[fkey][i])
        obs_ratings.append(train_data[rkey][i])
        i = i + 1
      else:
        break
    # backward to get sample
    i = start_index
    while len(obs_features) < batch_size and i >= 0:
      if len(train_data[fkey][i]) == len(train_data[fkey][start_index]):
        obs_features.append(train_data[fkey][i])
        obs_ratings.append(train_data[rkey][i])
        i = i - 1
      else:
        break
    obs_data = {fkey: obs_features, rkey: obs_ratings}
    return obs_data

  def _fit_obs_data(self, obs_data):
    keep_probs = self._args.keep_probs
    feed_dict = {self.features: obs_data[fkey], 
                 self.ratings: obs_data[rkey], 
                 self.keep_probs: keep_probs, 
                 self.is_train: True}
    fetches = (self.obs_loss, self.obs_update)
    obs_loss, _ = self.sess.run(fetches, feed_dict=feed_dict)
    return obs_loss

  def _eval_pred_model(self, eval_data):
    no_dropout = self._args.no_dropout
    min_value = self._data.min_value
    max_value = self._data.max_value
    eval_size = len(eval_data[rkey])
    feed_dict = {self.features: eval_data[fkey],
                 self.ratings: eval_data[rkey],
                 self.keep_probs: no_dropout,
                 self.is_train: False}
    pred_ratings = self.sess.run(self.pred_ratings, feed_dict=feed_dict)
    pred_ratings = np.maximum(pred_ratings, min_value)
    pred_ratings = np.minimum(pred_ratings, max_value)
    ratings = eval_data[rkey]
    mae = metrics.mean_absolute_error(ratings, pred_ratings)
    mse = metrics.mean_squared_error(ratings, pred_ratings)
    return mae, mse

  def _check_overfit(self, valid):
    if len(valid) > 5:
      if valid[-1] > valid[-2] and valid[-2] > valid[-3] and valid[-3] > valid[-4] and valid[-4] > valid[-5]:
        return True
    return False

  def train(self):
    train_mae, valid_mae, test_mae = [], [], []
    train_mse, valid_mse, test_mse = [], [], []

    verbose = self._args.verbose
    train_data = self._data.train_data
    valid_data = self._data.valid_data
    test_data = self._data.test_data

    if verbose > 0:
      train_res = self._eval_pred_model(train_data)
      valid_res = self._eval_pred_model(valid_data)
      test_res = self._eval_pred_model(test_data)
      p_data = (train_res[1], valid_res[1], test_res[1])
      print('init train=%.4f valid=%.4f test=%.4f' % p_data)

    start = time()
    pretrain_epochs = self._args.pretrain_epochs
    batch_size = self._args.batch_size
    for epoch in range(pretrain_epochs):
      self._shuffle_in_unison(train_data[fkey], train_data[rkey])
      total_batch = int(len(train_data[rkey]) / batch_size)
      for i in range(total_batch):
        batch_xs = self._get_obs_data(batch_size)
        self._fit_obs_data(batch_xs)

      train_res = self._eval_pred_model(train_data)
      valid_res = self._eval_pred_model(valid_data)
      test_res = self._eval_pred_model(test_data)

      train_mae.append(train_res[0])
      valid_mae.append(valid_res[0])
      test_mae.append(test_res[0])
      train_mse.append(train_res[1])
      valid_mse.append(valid_res[1])
      test_mse.append(test_res[1])
      if verbose > 0 and (epoch + 1) % verbose == 0:
        stop = time()
        p_data = (epoch + 1, train_res[1], valid_res[1], stop - start)
        print('#%d train=%.4f valid=%.4f time=%.1fs' % p_data)

    pretrain = self._args.pretrain
    if pretrain < 0:
      print('save model to file as pretrain')
      self.saver.save(self.sess, self.save_file)

    best_valid_score = min(valid_mse)
    best_epoch = valid_mse.index(best_valid_score)
    p_data = (best_epoch + 1, valid_mse[best_epoch], test_mse[best_epoch])
    # print ('best=%d valid=%.4f test=%.4f' % p_data)
    args = self._args
    p_data = (best_epoch + 1, valid_mae[best_epoch], valid_mse[best_epoch], args)
    print('%d\t%.4f\t%.4f\t%s' % p_data)


if __name__ == '__main__':
  description = 'Run a factorization machine model'
  args = utils.parse_args(description)

  data = utils.Dataset(args.base_dir)

  model = FmRec(args, data)
  model.train()
