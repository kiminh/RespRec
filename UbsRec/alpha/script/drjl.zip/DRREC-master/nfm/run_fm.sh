base_dir=~/Projects/drrec/data/song/song

batch_norm=0
batch_size=128
num_factors=128
keep_probs=[0.6]
all_reg_coeff=0.001
pred_learning_rate=0.005
python -W ignore fm.py \
    --base_dir ${base_dir} \
    --pretrain 0 \
    --verbose 1 \
    --optimizer_type adagrad \
    --pretrain_epochs 10 \
    --batch_norm ${batch_norm} \
    --batch_size ${batch_size} \
    --num_factors ${num_factors} \
    --all_reg_coeff ${all_reg_coeff} \
    --keep_probs ${keep_probs} \
    --pred_learning_rate ${pred_learning_rate}
exit

for all_reg_coeff in 0.0005 0.001 0.005
do
  for batch_size in 64 128 256
  do
    for keep_probs in '[0.4]' '[0.6]' '[0.8]'
    do
      for num_factors in 64 128 256
      do
        for pred_learning_rate in 0.001 0.005 0.01
        do

python -W ignore fm.py \
    --base_dir ${base_dir} \
    --pretrain 0 \
    --verbose 0 \
    --optimizer_type adagrad \
    --pretrain_epochs 40 \
    --batch_norm 0 \
    --all_reg_coeff ${all_reg_coeff} \
    --batch_size ${batch_size} \
    --keep_probs ${keep_probs} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}

        done
      done
    done
  done
done
exit

