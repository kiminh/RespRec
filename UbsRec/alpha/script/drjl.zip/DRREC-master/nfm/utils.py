import argparse
import numpy as np
import os

fkey = 'feature'
rkey = 'rating'

class Dataset(object):
  def __init__(self, base_dir):
    self.train_file = base_dir + '.train.libfm'
    self.valid_file = base_dir + '.valid.libfm'
    self.test_file = base_dir + '.test.libfm'
    self.num_features = self.count_num_feature()
    self.nnz_features = self.count_nnz_feature()
    self.train_data, self.valid_data, self.test_data = self.load_data()
    self.train_size = len(self.train_data[fkey])

    user_feat_file = base_dir + '.user_feature.mat'
    self.user_features = self.load_feature(user_feat_file)
    item_feat_file = base_dir + '.item_feature.mat'
    self.item_features = self.load_feature(item_feat_file)

    self.num_users = len(self.user_features)
    self.num_items = len(self.item_features)

  def count_num_feature(self):
    features = set()
    fin = open(self.train_file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      for feature in fields[1:]:
        features.add(feature)
      line = fin.readline()
    fin.close()
    return len(features)

  def count_nnz_feature(self):
    fin = open(self.train_file)
    line = fin.readline()
    fields = line.strip().split()
    fin.close()
    return len(fields) - 1

  def load_data(self):
    train_data = self.read_data(self.train_file)
    valid_data = self.read_data(self.valid_file)
    test_data = self.read_data(self.test_file)
    return train_data, valid_data, test_data

  def read_data(self, file):
    features = []
    ratings = []
    fin = open(file)
    line = fin.readline()
    while line:
      fields = line.strip().split()
      features.append([int(feature) for feature in fields[1:]])
      ratings.append(1.0 * float(fields[0]))
      line = fin.readline()
    fin.close()
    self.min_value = min(ratings)
    self.max_value = max(ratings)
    data = {fkey: features, rkey: ratings}
    return data

  def load_feature(self, file):
    features = []
    fin = open(file)
    line = fin.readline()
    while line:
      features.append([int(feature) for feature in line.strip().split()])
      line = fin.readline()
    return features



def parse_args(description):
  parser = argparse.ArgumentParser(description=description)
  parser.add_argument('--base_dir', type=str, default='../data/coat/coat')

  parser.add_argument('--pretrain_epochs', type=int, default=100)
  parser.add_argument('--interact_epochs', type=int, default=10)
  parser.add_argument('--num_pred_epochs', type=int, default=10)
  parser.add_argument('--num_impt_epochs', type=int, default=20)
  parser.add_argument('--pred_learning_rate', type=float, default=0.005)
  parser.add_argument('--impt_learning_rate', type=float, default=0.01)
  parser.add_argument('--pred_model_name', default='fm', help='nfm|fm')
  parser.add_argument('--impt_model_name', default='fm', help='nfm|fm')

  parser.add_argument('--pretrain', type=int, default=0, help='0|1')
  parser.add_argument('--verbose', type=int, default=1, help='0,1,2,...')
  parser.add_argument('--all_reg_coeff', type=float, default=0.001)
  parser.add_argument('--batch_norm', type=int, default=0, help='0|1')
  parser.add_argument('--batch_size', type=int, default=32)
  parser.add_argument('--num_factors', type=int, default=128)
  parser.add_argument('--keep_probs', type=str, default='[0.2,0.5]')
  parser.add_argument('--layer_sizes', type=str, default='[64]')
  parser.add_argument('--activation_func', default='relu',
                 help='identity|relu|sigmoid|tanh')
  parser.add_argument('--optimizer_type', default='adagrad',
                 help='adagrad|adam|sgd|rmsprop')
  return parser.parse_args()
