from os import path

summary_file = path.join('result', 'summary.csv')

checklist = [dict()] * 4
with open(summary_file) as fin:
  for line in fin.readlines():
    fields = line.strip().split()
    method = fields[0]
    for score, check in zip(fields[1:], checklist):
      score = float(score)
      check[method] = score
for check in checklist:
  ## FM <= MF
  assert check['FM'] <= check['MF']
  assert check['FM-IPS'] <= check['MF-IPS']
  assert check['FM-JEI'] <= check['MF-JEI']
  assert check['FM-DR'] <= check['MF-DR']
  ## NFM <= FM
  assert check['NFM'] <= check['FM']
  assert check['NFM-IPS'] <= check['FM-IPS']
  assert check['NFM-JEI'] <= check['FM-JEI']
  assert check['NFM-DR'] <= check['FM-DR']

  assert check['FM-IPS'] <= check['FM']
  assert check['FM-JEI'] <= check['FM']

  assert check['FM-DR'] <= check['FM-IPS']
  assert check['FM-DR'] <= check['FM-JEI']
  assert check['NFM-IPS'] <= check['FM-IPS']
  assert check['NFM-IPS'] <= check['NFM']
  assert check['NFM-JEI'] <= check['FM-JEI']
  assert check['NFM-JEI'] <= check['NFM']

  assert check['MF'] <= check['MF-NEI']



