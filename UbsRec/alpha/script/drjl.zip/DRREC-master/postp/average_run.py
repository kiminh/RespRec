from utils import *
import utils

from os import path
import argparse
import matplotlib.pyplot as plt
import numpy as np

def to_string(parameters):
  string = '_'.join([str(parameter) for parameter in parameters])
  return string

parser = argparse.ArgumentParser()
parser.add_argument('csv_file', type=str)
parser.add_argument('param_names', type=str)
args = parser.parse_args()

csv_file = args.csv_file
param_names = args.param_names.split(',')
mse_args_list = utils.load_mse_args(csv_file)
parameters_mse = dict()
for mse, args in mse_args_list:
  parameters = [getattr(args, param_name) for param_name in param_names]
  parameters = to_string(parameters)
  if parameters not in parameters_mse:
    parameters_mse[parameters] = []
  parameters_mse[parameters].append(mse)
# for parameters, mse_list in parameters_mse.items():
#   print(parameters, len(mse_list))
parameters_list = []
for parameters in parameters_mse.keys():
  parameters = parameters.split('_')
  parameters = [float(parameter) for parameter in parameters]
  parameters_list.append(parameters)
# parameters_list = sorted(parameters_list, key=lambda e: (e[0], e[1]))
parameters_list = sorted(parameters_list, key=lambda e: e[:len(param_names)])

mse_list = []
label_list = []
for parameters in parameters_list:
  parameters = to_string(parameters)
  mse = np.asarray(parameters_mse[parameters]).mean()
  mse_list.append(mse)
  label_list.append(parameters)
  print(parameters, mse)
fig, ax = plt.subplots()
ax.plot(np.arange(len(mse_list)), mse_list)
# ax.set_xticklabels(label_list)
# ax.set_yticks(ax.get_yticks()[1:])
out_file =path.basename(csv_file).replace('.csv', '.eps')
out_file = path.join(figure_dir, out_file)
# plt.show()
plt.savefig(out_file, format='eps')


