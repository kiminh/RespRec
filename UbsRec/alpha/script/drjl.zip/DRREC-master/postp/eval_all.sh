./eval_mar.sh coat > result/coat.librec
./eval_mar.sh song > result/song.librec

./eval_mnar.sh amason > result/amason.librec
./eval_mnar.sh amazon > result/amazon.librec
./eval_mnar.sh mcoat > result/mcoat.librec
./eval_mnar.sh movie > result/movie.librec
