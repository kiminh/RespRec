if [ "$#" -ne 1 ]
then
  echo "usage: $0 coat|song" >&2
  exit 1
fi

dataset=$1
python -W ignore eval_mar.py \
  ~/Projects/librec/runs/${dataset}/ \
  ~/Projects/librec/data/${dataset}/test/ratings_0.txt
