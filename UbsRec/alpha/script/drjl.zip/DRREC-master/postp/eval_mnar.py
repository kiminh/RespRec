from os import path
from sklearn import metrics
import argparse
import os
import pickle
import time

def load_rating(rating_file, delimiter=None):
  ratings = []
  with open(rating_file) as fin:
    for line in fin.readlines():
      if delimiter == None:
        fields = line.strip().split()
      else:
        fields = line.strip().split(delimiter)
      user = int(fields[0])
      item = int(fields[1])
      rating = float(fields[2])
      ratings.append((user, item, rating))
  ratings = sorted(ratings, key=lambda r: (r[0], r[1]))
  return ratings

def eval_run(run_file, test_file, propensity_file):
  run_ratings = load_rating(run_file, delimiter=',')
  test_ratings = load_rating(test_file)
  for run_rating, test_rating in zip(run_ratings, test_ratings):
    assert run_rating[0] == test_rating[0]
    assert run_rating[1] == test_rating[1]
  run_ratings = [run_rating[-1] for run_rating in run_ratings]
  test_ratings = [test_rating[-1] for test_rating in test_ratings]
  
  mae = metrics.mean_absolute_error(test_ratings, run_ratings)
  mse = metrics.mean_squared_error(test_ratings, run_ratings)
    
  propensity_eval = pickle.load(open(propensity_file, 'rb'))
  num_users = propensity_eval['num_users']
  num_items = propensity_eval['num_items']
  mae_sum = 0.0
  mse_sum = 0.0
  denominator = 0.0
  for run_rating, test_rating in zip(run_ratings, test_ratings):
    propensity = propensity_eval[int(test_rating)]
    mae_sum += abs(run_rating - test_rating) / propensity
    mse_sum += pow(run_rating - test_rating, 2.0) / propensity
    denominator += 1.0 / propensity
  ### snips
  mae_snips = mae_sum / denominator
  mse_snips = mse_sum / denominator
  ### ips
  mae_ips = mae_sum / (num_users * num_items)
  mse_ips = mse_sum / (num_users * num_items)
  f_data = (path.basename(run_file), mae, mse)
  f_data += (mae_snips, mse_snips, mae_ips, mse_ips)
  print('%s\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f\t%.4f' % f_data)

def main():
  parser = argparse.ArgumentParser()
  parser.add_argument('runs_dir', type=str)
  parser.add_argument('test_file', type=str)
  parser.add_argument('propensity_file', type=str)
  args = parser.parse_args()
  runs_dir = args.runs_dir
  test_file = args.test_file
  propensity_file = args.propensity_file
  for run_file in os.listdir(runs_dir):
    run_file = path.join(runs_dir, run_file)
    eval_run(run_file, test_file, propensity_file)
    # time.sleep(1)
    # break

if __name__ == '__main__':
  main()