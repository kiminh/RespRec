if [ "$#" -ne 1 ]
then
  echo "usage: $0 amazon|movie|song|amason" >&2
  exit 1
fi

dataset=$1
python -W ignore eval_mnar.py \
  ~/Projects/librec/runs/${dataset}/ \
  ~/Projects/librec/data/${dataset}/test/ratings_0.txt \
  propensity/${dataset}.propensity.eval

