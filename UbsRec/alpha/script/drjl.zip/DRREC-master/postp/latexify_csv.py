from sys import stdout

import argparse

parser = argparse.ArgumentParser()
parser.add_argument('csv_file', type=str)
args = parser.parse_args()

csv_file = args.csv_file
with open(csv_file) as fin:
  for line in fin.readlines():
    fields = line.strip().split()

    stdout.write('%s' % (fields[0]))
    for field in fields[1:]:
      stdout.write(' & %s' % (field))
    stdout.write(' \\\\\n')