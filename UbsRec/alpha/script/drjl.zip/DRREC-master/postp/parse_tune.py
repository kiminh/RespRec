from argparse import Namespace
import argparse
import matplotlib.pyplot as plt
import numpy as np

parser = argparse.ArgumentParser()
parser.add_argument('tune_file', type=str)
parser.add_argument('param_name', type=str)
args = parser.parse_args()

# all_reg_coeff=1.00
# num_batches=10
# num_factors=100
# pred_learning_rate=1e-4

tune_file = args.tune_file
param_name = args.param_name
mse_params = []
with open(tune_file) as fin:
  for line in fin.readlines():
    fields = line.strip().split('\t')
    args = eval(fields[-1])
    mse = float(fields[2])
    mse_params.append((mse, getattr(args, param_name)))
mse_params = sorted(mse_params, key=lambda kv: kv[0])
for mse, param in mse_params:
  print('%s\t%s' % (mse, param))
exit()

## worse ips
max_weight_mse = dict()
max_weight_set = set()
with open(tune_file) as fin:
  for line in fin.readlines():
    fields = line.strip().split('\t')
    args = eval(fields[-1])
    max_weight = args.max_weight
    mse = float(fields[2])
    if max_weight not in max_weight_mse:
      max_weight_mse[max_weight] = []
    max_weight_mse[max_weight].append(mse)
    max_weight_set.add(max_weight)
max_weight_list = sorted(max_weight_set)
mse_list = []
for max_weight in max_weight_list:
  mse = max_weight_mse[max_weight]
  assert len(mse) == 10
  mse = np.asarray(mse).mean()
  mse_list.append(mse)
plt.plot(max_weight_list, mse_list)
plt.show()