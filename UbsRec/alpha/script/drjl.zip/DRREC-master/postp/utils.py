from argparse import Namespace
from os import path
import os

figure_dir = 'figure'
if not path.exists(figure_dir):
    os.makedirs(figure_dir)

def load_mse_args(csv_file):
  mse_args_list = []
  with open(csv_file) as fin:
    for line in fin.readlines():
      fields = line.strip().split('\t')
      args = eval(fields[-1])
      # mse = float(fields[2])
      mse = float(fields[1])
      mse_args_list.append((mse, args))
  return mse_args_list