from utils import *

from os import path
from sys import stdout
import argparse
import numpy as np
import os
import pprint
import sys

def load_feature(feature_file, feat_name_file):
  feature_mat = np.loadtxt(feature_file, dtype=np.int32)
  num_objects, num_features = feature_mat.shape
  feature_list = []
  feature_names = {}
  with open(feat_name_file) as fin:
    for line in fin.readlines():
      arr = line.strip().split(':')
      assert len(arr) == 2
      feature_names[arr[0]] = feature_names.get(arr[0], []) + [arr[1]]
      if len(feature_list) == 0 or arr[0] != feature_list[-1]:
        feature_list.append(arr[0])
  feature_indexes = []
  start = 0
  for feature in feature_list:
    stop = start + len(feature_names[feature])
    feature_indexes.append((start, stop))
    start = stop
  assert stop == num_features
  for i in range(num_objects):
    for start, stop in feature_indexes:
      one_hot = feature_mat[i, start:stop]
      assert np.sum(one_hot) == 1
  return feature_mat

def load_entry(in_file, input_feature, entry_ids):
  user_ids, user_feat_ids, item_ids, item_feat_ids = entry_ids
  obs_entries = []
  rating_mat = np.loadtxt(in_file, dtype=np.int32)
  users, items = rating_mat.nonzero()
  for user, item in zip(users, items):
    rating = rating_mat[user, item]
    propensity = propensity_mat[user, item]
    user_feat_vec = user_feat_mat[user,:]
    item_feat_vec = item_feat_mat[item,:]
    user_features, = user_feat_vec.nonzero()
    item_features, = item_feat_vec.nonzero()
    assert len(user_features) == 4
    assert len(item_features) == 4
    entry = [rating, propensity]
    entry += [user_ids[user]]
    if input_feature == fm_input:
      for user_feature in user_features:
        entry += [user_feat_ids[user_feature]]
    entry += [item_ids[item]]
    if input_feature == fm_input:
      for item_feature in item_features:
        entry += [item_feat_ids[item_feature]]
    obs_entries.append(entry)
  return obs_entries

def split_entry(user_irp_list, heldout_size):
  train_entries = []
  test_entries = []
  for user, irp_list in user_irp_list:
    np.random.shuffle(irp_list)
    for irp_tuple in irp_list[heldout_size:]:
      train_entries.append((user,) + irp_tuple)
    for irp_tuple in irp_list[:heldout_size]:
      test_entries.append((user,) + irp_tuple)
  return train_entries, test_entries

dataset = 'coat'
dnld_dir = path.expanduser('~/Downloads/coat')
feat_dir = path.join(dnld_dir, 'user_item_features')
train_in_file = path.join(dnld_dir, 'train.ascii')
test_in_file = path.join(dnld_dir, 'test.ascii')
data_dir = path.expanduser('~/Projects/drrec/data')
data_dir = path.join(data_dir, dataset)
if not path.exists(data_dir):
  os.makedirs(data_dir)

dnld_url = 'https://www.cs.cornell.edu/~schnabts/mnar/coat.zip'
download_zip(dnld_dir, dnld_url)

user_feat_file = path.join(feat_dir, 'user_features.ascii')
user_feat_name_file = path.join(feat_dir, 'user_features_map.txt')
user_feat_mat = load_feature(user_feat_file, user_feat_name_file)
item_feat_file = path.join(feat_dir, 'item_features.ascii')
item_feat_name_file = path.join(feat_dir, 'item_features_map.txt')
item_feat_mat = load_feature(item_feat_file, item_feat_name_file)
num_users, num_user_features = user_feat_mat.shape
print('num_users=%d num_user_features=%d' % (num_users, num_user_features))
num_items, num_item_features = item_feat_mat.shape
print('num_items=%d num_item_features=%d' % (num_items, num_item_features))

propensity_file = path.join(dnld_dir, 'propensities.ascii')
propensity_mat = np.loadtxt(propensity_file)
assert (num_users, num_items) == propensity_mat.shape

def preprocess_mar(input_feature):
  shrd_id = 0
  user_ids = dict()
  for user in range(num_users):
    user_ids[user] = shrd_id
    shrd_id += 1
  user_feat_ids = dict()
  if input_feature == fm_input:
    for user_feature in range(num_user_features):
      user_feat_ids[user_feature] = shrd_id
      shrd_id += 1
  item_ids = dict()
  for item in range(num_items):
    item_ids[item] = shrd_id
    shrd_id += 1
  item_feat_ids = dict()
  if input_feature == fm_input:
    for item_feature in range(num_item_features):
      item_feat_ids[item_feature] = shrd_id
      shrd_id += 1
  entry_ids = user_ids, user_feat_ids, item_ids, item_feat_ids

  prefix = '%s.mar.%s' % (dataset, input_feature)
  train_entries = load_entry(train_in_file, input_feature, entry_ids)
  train_out_file = path.join(data_dir, prefix + '.train')
  save_space_sep(train_entries, train_out_file)
  test_entries = load_entry(test_in_file, input_feature, entry_ids)
  valid_out_file = path.join(data_dir, prefix + '.valid')
  save_space_sep(test_entries, valid_out_file)
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(test_entries, test_out_file)


  user_entries = []
  for user in range(num_users):
    user_entry = [user_ids[user]]
    if input_feature == fm_input:
      user_feat_vec = user_feat_mat[user,:]
      user_features, = user_feat_vec.nonzero()
      for user_feature in user_features:
        user_entry += [user_feat_ids[user_feature]]
    user_entries.append(user_entry)
  user_feat_file = path.join(data_dir, prefix + '.user')
  save_space_sep(user_entries, user_feat_file)

  item_entries = []
  for item in range(num_items):
    item_entry = [item_ids[item]]
    if input_feature == fm_input:
      item_feat_vec = item_feat_mat[item,:]
      item_features, = item_feat_vec.nonzero()
      for item_feature in item_features:
        item_entry += [item_feat_ids[item_feature]]
    item_entries.append(item_entry)
  item_feat_file = path.join(data_dir, prefix + '.item')
  save_space_sep(item_entries, item_feat_file)

def preprocess_mnar(input_feature):
  if input_feature == fm_input:
    raise Exception('todo')

  heldout_size = 2
  random_seed = 10
  np.random.seed(random_seed)

  rating_mat = np.loadtxt(train_in_file, dtype=np.int32)
  users, items = rating_mat.nonzero()
  entries = []
  for user, item in zip(users, items):
    rating = rating_mat[user, item]
    propensity = propensity_mat[user, item]
    entries.append((user, item, rating, propensity))
  num_entries = len(entries)
  print('num_entries=%d' % (num_entries))
  
  np.random.shuffle(entries)

  user_irp_list = dict()
  for user, item, rating, propensity in entries:
    irp_list = []
    if user in user_irp_list:
      irp_list = user_irp_list[user]
    irp_list.append((item, rating, propensity))
    user_irp_list[user] = irp_list
  user_irp_list = sorted(user_irp_list.items(), key=lambda kv: kv[0])
  for user, irp_list in user_irp_list:
    assert len(irp_list) == 24
  np.random.shuffle(user_irp_list)
  # print(user_irp_list[0])

  train_entries, test_entries = split_entry(user_irp_list, heldout_size)
  train_size = len(train_entries)
  test_size = len(test_entries)
  assert (train_size + test_size) == num_entries
  print('train_size=%d test_size=%d' % (train_size, test_size))

  prefix = '%s.mnar.%s' % (dataset, input_feature)
  train_out_file = path.join(data_dir, prefix + '.train')
  save_space_sep(train_entries, train_out_file)
  valid_out_file = path.join(data_dir, prefix + '.valid')
  save_space_sep(test_entries, valid_out_file)
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(test_entries, test_out_file)

def main():
  parser = argparse.ArgumentParser(description='preprocess coat data')
  parser.add_argument('test_dataset', type=str, help='mar|mnar')
  parser.add_argument('input_feature', type=str, help='fm|mf')
  args = parser.parse_args()

  module = sys.modules[__name__]
  test_dataset = args.test_dataset
  input_feature = args.input_feature
  prep_func = 'preprocess_%s' % (test_dataset)
  if not hasattr(module, prep_func):
    raise Exception('unknown test dataset %s' % (test_dataset))
  getattr(module, prep_func)(input_feature)

if __name__ == '__main__':
  main()
