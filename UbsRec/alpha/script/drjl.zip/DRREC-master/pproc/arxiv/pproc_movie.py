from utils import *

from os import path
import os
import pprint

def load_rating(rating_file):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      fields = line.strip().split('::')
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

def main():
  dataset = 'movie'
  num_cores = 20
  dnld_dir = path.expanduser('~/Downloads/ml-1m')
  dnld_url = 'http://files.grouplens.org/datasets/movielens/ml-1m.zip'
  download_zip(dnld_dir, dnld_url)

  rating_file = path.join(dnld_dir, 'ratings.dat')
  ratings = load_rating(rating_file)
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))
  while True:
    user_count, item_count = get_count(ratings)
    num_users = len(user_count.keys())
    num_items = len(item_count.keys())
    print('intotal num_users=%d num_items=%d' % (num_users, num_items))
    inv_users, inv_items = get_invalid(user_count, item_count, num_cores)
    f_data = (len(inv_users), len(inv_items))
    print('invalid num_users=%d num_items=%d' % f_data)
    if len(inv_users) == 0 and len(inv_items) == 0:
      break
    ratings = remove_invalid(ratings, inv_users, inv_items)
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))

  user_ids, item_ids = assign_shrd_id(ratings)
  # pp = pprint.PrettyPrinter(indent=2)
  # pp.pprint(user_ids)
  # pp.pprint(item_ids)

  train_ratings, test_ratings = random_split(ratings)
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  print('train_size=%d test_size=%d' % (train_size, test_size))

  data_dir = path.expanduser('~/Projects/drrec/data')
  data_dir = path.join(data_dir, dataset)
  if not path.exists(data_dir):
    os.makedirs(data_dir)
  train_file = path.join(data_dir, '%s.train.libfm' % (dataset))
  save_as_libfm(train_ratings, train_file, user_ids, item_ids)
  test_file = path.join(data_dir, '%s.test.libfm' % (dataset))
  save_as_libfm(test_ratings, test_file, user_ids, item_ids)
  valid_file = path.join(data_dir, '%s.valid.libfm' % (dataset))
  save_as_libfm(test_ratings, valid_file, user_ids, item_ids)
  user_feat_file = path.join(data_dir, '%s.user_feature.mat' % (dataset))
  save_feature(user_ids, user_feat_file)
  item_feat_file = path.join(data_dir, '%s.item_feature.mat' % (dataset))
  save_feature(item_ids, item_feat_file)

  user_ids = assign_user_id(ratings)
  item_ids = assign_item_id(ratings)
  train_file = path.join(data_dir, '%s.train.csv' % (dataset))
  save_as_csv(train_ratings, train_file, user_ids, item_ids)
  test_file = path.join(data_dir, '%s.test.csv' % (dataset))
  save_as_csv(test_ratings, test_file, user_ids, item_ids)
  valid_file = path.join(data_dir, '%s.valid.csv' % (dataset))
  save_as_csv(test_ratings, valid_file, user_ids, item_ids)

  data_dir = path.expanduser('~/Projects/librec/data/movielens/ml-1m')
  train_file = path.join(data_dir, 'train/ratings_1.txt')
  save_as_librec(train_ratings, train_file, user_ids, item_ids)
  test_file = path.join(data_dir, 'test/ratings_0.txt')
  save_as_librec(test_ratings, test_file, user_ids, item_ids)

if __name__ == '__main__':
  main()

