from os import path
import os
import pprint

def convert(in_file, out_file):
  with open(in_file) as fin, open(out_file, 'w') as fout:
    for line in fin.readlines():
      fields = line.strip().split()
      user = user_ids[int(fields[0])]
      item = item_ids[int(fields[1])]
      rating = int(fields[2])
      fout.write('%d %d %d\n' % (rating, user, item))

dataset = 'song'
dnld_dir = path.expanduser('~/Downloads/Webscope_R3')
data_dir = path.join('../data', dataset)
if not path.exists(data_dir):
  os.makedirs(data_dir)

in_train_file = 'ydata-ymusic-rating-study-v1_0-train.txt'
in_train_file = path.join(dnld_dir, in_train_file)
in_test_file = 'ydata-ymusic-rating-study-v1_0-test.txt'
in_test_file = path.join(dnld_dir, in_test_file)

users = set()
items = set()
with open(in_train_file) as fin:
  for line in fin.readlines():
    fields = line.strip().split()
    users.add(int(fields[0]))
    items.add(int(fields[1]))
num_users = len(users)
num_items = len(items)
print('#users=%d #items=%d' % (num_users, num_items))

global_id = 0
user_ids = dict()
for user in sorted(users):
  user_ids[user] = global_id
  global_id += 1
item_ids = dict()
for item in sorted(items):
  item_ids[item] = global_id
  global_id += 1

assert global_id == (num_users + num_items)
for user in sorted(users):
  assert user_ids[user] == (user - 1)
for item in sorted(items):
  assert item_ids[item] == (item - 1 + num_users)

train_file = path.join(data_dir, '%s.train.libfm' % (dataset))
convert(in_train_file, train_file)

valid_file = path.join(data_dir, '%s.valid.libfm' % (dataset))
test_file = path.join(data_dir, '%s.test.libfm' % (dataset))
convert(in_test_file, valid_file)
convert(in_test_file, test_file)


user_feat_file = path.join(data_dir, '%s.user_feature.mat' % (dataset))
with open(user_feat_file, 'w') as fout:
  for user in sorted(users):
    fout.write('%d\n' % (user_ids[user]))

item_feat_file = path.join(data_dir, '%s.item_feature.mat' % (dataset))
with open(item_feat_file, 'w') as fout:
  for item in sorted(items):
    fout.write('%d\n' % (item_ids[item]))

pp = pprint.PrettyPrinter(indent=2)



