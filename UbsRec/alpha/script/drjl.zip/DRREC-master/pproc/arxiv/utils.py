from os import path
import numpy as np
import os

num_folds = 10
fm_input = 'fm'
mf_input = 'mf'

def download_zip(dnld_dir, dnld_url):
  if not path.exists(dnld_dir):
    dnld_dir = path.dirname(dnld_dir)
    dnld_zip = path.join(dnld_dir, 'data.zip')
    print('download data from %s' % (dnld_url))
    os.system('wget %s -O %s' % (dnld_url, dnld_zip))
    print('uncompress data to %s' % (dnld_dir))
    os.system('unzip %s -d %s' % (dnld_zip, dnld_dir))

def get_count(ratings):
  user_count = dict()
  item_count = dict()
  for user, item, _ in ratings:
    user_count[user] = user_count.get(user, 0) + 1
    item_count[item] = item_count.get(item, 0) + 1
  return user_count, item_count

def get_invalid(user_count, item_count, num_cores):
  inv_users = set([u for u, c in user_count.items() if c < num_cores])
  inv_items = set([i for i, c in item_count.items() if c < num_cores])
  return inv_users, inv_items

def remove_invalid(ratings, inv_users, inv_items):
  valid_ratings = []
  for user, item, rating in ratings:
    if user in inv_users:
      continue
    if item in inv_items:
      continue
    valid_ratings.append((user, item, rating))
  return valid_ratings

def assign_shrd_id(ratings):
  users = set()
  items = set()
  for user, item, _ in ratings:
    users.add(user)
    items.add(item)
  users = sorted(users)
  items = sorted(items)
  shrd_id = 0
  user_ids = dict()
  item_ids = dict()
  for user in users:
    user_ids[user] = shrd_id
    shrd_id += 1
  for item in items:
    item_ids[item] = shrd_id
    shrd_id += 1
  return user_ids, item_ids

def assign_user_id(ratings):
  users = set()
  for user, *_ in ratings:
    users.add(user)
  users = sorted(users)
  user_id = 0
  user_ids = dict()
  for user in users:
    user_ids[user] = user_id
    user_id += 1
  return user_ids

def assign_item_id(ratings):
  items = set()
  for _, item, *_ in ratings:
    items.add(item)
  items = sorted(items)
  item_id = 0
  item_ids = dict()
  for item in items:
    item_ids[item] = item_id
    item_id += 1
  return item_ids

def random_split(ratings):
  np.random.seed(0)
  np.random.shuffle(ratings)
  num_ratings = len(ratings)
  test_size = num_ratings // 10
  train_ratings = []
  test_ratings = []
  for i in range(num_ratings):
    if i < test_size:
      test_ratings.append(ratings[i])
    else:
      train_ratings.append(ratings[i])
  return train_ratings, test_ratings

def save_space_sep(entries, out_file):
  num_entries = len(entries)
  with open(out_file, 'w') as fout:
    for entry in entries:
      entry = [str(f) for f in entry]
      fout.write('%s\n' % (' '.join(entry)))
  print('save %d entries to %s' % (num_entries, out_file))

def save_as_libfm(ratings, out_file, user_ids, item_ids):
  with open(out_file, 'w') as fout:
    for user, item, rating in ratings:
      f_data = (rating, user_ids[user], item_ids[item])
      fout.write('%d %d %d\n' % f_data)
  num_ratings = len(ratings)
  print('save %d ratings to %s' % (num_ratings, out_file))

def save_feature(feature_ids, out_file):
  with open(out_file, 'w') as fout:
    for feature in sorted(feature_ids.keys()):
      fout.write('%d\n' % (feature_ids[feature]))
  print('save %d features to %s' % (len(feature_ids), out_file))

def save_as_librec(ratings, out_file, user_ids, item_ids):
  out_dir = path.dirname(out_file)
  if not path.exists(out_dir):
    os.makedirs(out_dir)
  with open(out_file, 'w') as fout:
    for user, item, rating in ratings:
      f_data = (user_ids[user], item_ids[item], rating)
      fout.write('%d %d %d\n' % f_data)
  num_ratings = len(ratings)
  print('save %d ratings to %s' % (num_ratings, out_file))

def save_as_csv(tuples, out_file, user_ids, item_ids):
  out_dir = path.dirname(out_file)
  if not path.exists(out_dir):
    os.makedirs(out_dir)
  with open(out_file, 'w') as fout:
    for i in range(len(tuples)):
      user = str(user_ids[tuples[i][0]])
      item = str(item_ids[tuples[i][1]])
      f_data = (' '.join([user, item] + [str(t) for t in tuples[i][2:]]))
      fout.write('%s\n' % f_data)
  num_tuples = len(tuples)
  print('save %d tuples to %s' % (num_tuples, out_file))



