from utils import *

from os import path
import argparse
import numpy as np
import os
import pickle
import time

def load_rating(rating_file):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      fields = line.strip().split()
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

def main():
  # datasets = ['amazon', 'movie', 'amason', 'mcoat']
  datasets = ['mcoat']
  for dataset in datasets:
    data_dir = path.expanduser('~/Projects/librec/data')
    data_dir = path.join(data_dir, dataset)
    train_file = path.join(data_dir, 'train/ratings_1.txt')
    test_file = path.join(data_dir, 'test/ratings_0.txt')
    train_ratings = load_rating(train_file)
    test_ratings = load_rating(test_file)

    # random_seed = np.random.randint(0, 2**32 - 1)
    # print(random_seed)
    # random_seed = 1692793519
    # np.random.seed(random_seed)
    # np.random.shuffle(test_ratings)


    propensity_eval = est_propensity(train_ratings, test_ratings)

    data_dir = path.expanduser('~/Projects/drrec/postp/propensity')
    if not path.exists(data_dir):
      os.makedirs(data_dir)
    propensity_file = '%s.propensity.eval' % (dataset)
    propensity_file = path.join(data_dir, propensity_file)
    pickle.dump(propensity_eval, open(propensity_file, 'wb'))

if __name__ == '__main__':
  main()

