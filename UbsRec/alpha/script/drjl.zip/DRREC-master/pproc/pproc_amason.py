from utils import *

from os import path
import argparse
import os
import pprint
import sys

def load_song_rating(rating_file):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      fields = line.strip().split()
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

parser = argparse.ArgumentParser(description='preprocess amason data')
args = parser.parse_args()

dataset = 'amason'
prefix = '%s' % (dataset)

dnld_dir = path.expanduser('~/Downloads/Webscope_R3')
if not path.exists(dnld_dir):
  raise Exception('%s dataset not in %s' % (dataset, dnld_dir))

train_in_file = 'ydata-ymusic-rating-study-v1_0-train.txt'
train_in_file = path.join(dnld_dir, train_in_file)
test_in_file = 'ydata-ymusic-rating-study-v1_0-test.txt'
test_in_file = path.join(dnld_dir, test_in_file)

ratings = load_song_rating(train_in_file)
users = set([rating[0] for rating in ratings])
items = set([rating[1] for rating in ratings])
num_users = len(users)
num_items = len(items)
# print('num_users=%d num_items=%d' % (num_users, num_items))

def main():
  data_dir = path.join('../data', dataset)
  if not path.exists(data_dir):
    os.makedirs(data_dir)

  train_ratings, test_ratings = split_randomly(ratings)

  train_users = set([rating[0] for rating in train_ratings])
  train_items = set([rating[1] for rating in train_ratings])
  assert len(train_users) == num_users
  assert len(train_items) == num_items

  train_size = len(train_ratings)
  test_size = len(test_ratings)
  # print('train_size=%d test_size=%d' % (train_size, test_size))

  user_ids = assign_id(users, 0)
  item_ids = assign_id(items, 0)
  for user in users:
    assert user == user_ids[user] + 1
  for item in items:
    assert item == item_ids[item] + 1

  ids = user_ids, item_ids
  propensity_eval = est_propensity(train_ratings, test_ratings)
  train_entries = load_song_entry(train_ratings, ids, propensity_eval)
  test_entries = load_song_entry(test_ratings, ids, propensity_eval)

  train_out_file = path.join(data_dir, prefix + '.train')
  valid_out_file = path.join(data_dir, prefix + '.valid')
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(train_entries, train_out_file)
  save_space_sep(test_entries, valid_out_file)
  save_space_sep(test_entries, test_out_file)
  propensity_file = '%s.propensity.eval' % (dataset)
  propensity_file = path.join(data_dir, propensity_file)
  pickle.dump(propensity_eval, open(propensity_file, 'wb'))

  ## librec
  data_dir = path.expanduser('~/Projects/librec/data/amason')
  train_file = path.join(data_dir, 'train/ratings_1.txt')
  test_file = path.join(data_dir, 'test/ratings_0.txt')
  # train_ratings = [(r[0] - 1, r[1] - 1, r[2]) for r in train_ratings]
  # test_ratings = [(r[0] - 1, r[1] - 1, r[2]) for r in test_ratings]
  min_user = min([rating[0] for rating in train_ratings])
  max_user = max([rating[0] for rating in train_ratings])
  min_item = min([rating[1] for rating in train_ratings])
  max_item = max([rating[1] for rating in train_ratings])
  print('min_user=%d max_user=%d' % (min_user, max_user))
  print('min_item=%d max_item=%d' % (min_item, max_item))
  train_ratings = sorted(train_ratings, key=lambda e: (e[0], e[1]))
  test_ratings = sorted(test_ratings, key=lambda e: (e[0], e[1]))
  save_space_sep(train_ratings, train_file)
  save_space_sep(test_ratings, test_file)

if __name__ == '__main__':
  main()



