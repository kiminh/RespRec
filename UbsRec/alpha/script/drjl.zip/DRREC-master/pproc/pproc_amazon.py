from utils import *

from os import path
import os
import pickle
import pprint
import time

def download_csv(dnld_dir, dnld_url):
  rating_file = path.join(dnld_dir, path.basename(dnld_url))
  if not path.exists(rating_file):
    print('download data from %s' % (dnld_url))
    os.system('wget %s -O %s' % (dnld_url, rating_file))
  return rating_file

def load_rating(rating_file):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      fields = line.strip().split(',')
      user = fields[0]
      item = fields[1]
      rating = float(fields[2])
      assert rating - int(rating) == 0.0
      rating = int(rating)
      ratings.append((user, item, rating))
  return ratings

def main():
  dataset = 'amazon'
  num_cores = 10
  dnld_dir = path.expanduser('~/Downloads')
  file_url = 'http://snap.stanford.edu/data/amazon/productGraph/categoryFiles'
  dnld_url = path.join(file_url, 'ratings_Movies_and_TV.csv')
  rating_file = download_csv(dnld_dir, dnld_url)
  ratings = load_rating(rating_file)
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))
  while True:
    user_count, item_count = count_user_item(ratings)
    num_users = len(user_count.keys())
    num_items = len(item_count.keys())
    print('intotal num_users=%d num_items=%d' % (num_users, num_items))
    inv_users, inv_items = get_invalid(user_count, item_count, num_cores)
    f_data = (len(inv_users), len(inv_items))
    print('invalid num_users=%d num_items=%d' % f_data)
    if len(inv_users) == 0 and len(inv_items) == 0:
      break
    ratings = remove_invalid(ratings, inv_users, inv_items)
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))

  train_ratings, test_ratings = split_randomly(ratings)
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  print('train_size=%d test_size=%d' % (train_size, test_size))

  data_dir = path.expanduser('~/Projects/drrec/data')
  data_dir = path.join(data_dir, dataset)
  if not path.exists(data_dir):
    os.makedirs(data_dir)

  users = set()
  for user, *_ in ratings:
    users.add(user)
  items = set()
  for _, item, *_ in ratings:
    items.add(item)
  num_users = len(users)
  num_items = len(items)
  print('num_users=%d num_items=%d' % (num_users, num_items))

  ## autorec
  user_ids = assign_id(users, 1)
  item_ids = assign_id(items, 1)
  prefix = '%s.autorec' % (dataset)
  rating_file = path.join(data_dir, prefix + '.rating')
  ratings = train_ratings + test_ratings
  entries = number_user_item(ratings, user_ids, item_ids)
  timestamp = int(round(time.time()))
  entries = [entry + (timestamp,) for entry in entries]
  save_space_sep(entries, rating_file, delimiter='::')
  meta_data = num_users, num_items, train_size, test_size
  meta_data_file = path.join(data_dir, prefix + '.meta.data')
  save_meta_data(meta_data, meta_data_file)

  ## librec
  user_ids = assign_id(users, 0)
  item_ids = assign_id(items, 0)
  data_dir = path.expanduser('~/Projects/librec/data/%s' % (dataset))
  train_file = path.join(data_dir, 'train/ratings_1.txt')
  test_file = path.join(data_dir, 'test/ratings_0.txt')
  train_entries = number_user_item(train_ratings, user_ids, item_ids)
  save_space_sep(train_entries, train_file)
  test_entries = number_user_item(test_ratings, user_ids, item_ids)
  save_space_sep(test_entries, test_file)


if __name__ == '__main__':
  main()

