from utils import *

from os import path
from sys import stdout
import argparse
import numpy as np
import os
import pickle
import pprint
import sys
import time

parser = argparse.ArgumentParser(description='preprocess coat data')
parser.add_argument('input_feature', type=str, help='fml|fmm|mf')
args = parser.parse_args()

dataset = 'coat'
input_feature = args.input_feature
if input_feature not in [fml_input, fmm_input, mf_input]:
  raise Exception('unknown input feature %s' % (input_feature))
prefix = '%s.%s' % (dataset, input_feature)

dnld_dir = path.expanduser('~/Downloads/coat')
feat_dir = path.join(dnld_dir, 'user_item_features')
train_in_file = path.join(dnld_dir, 'train.ascii')
test_in_file = path.join(dnld_dir, 'test.ascii')

dnld_url = 'https://www.cs.cornell.edu/~schnabts/mnar/coat.zip'
download_zip(dnld_dir, dnld_url)

user_feat_file = path.join(feat_dir, 'user_features.ascii')
user_feat_name_file = path.join(feat_dir, 'user_features_map.txt')
user_feat_mat = load_coat_feature(user_feat_file, user_feat_name_file)
item_feat_file = path.join(feat_dir, 'item_features.ascii')
item_feat_name_file = path.join(feat_dir, 'item_features_map.txt')
item_feat_mat = load_coat_feature(item_feat_file, item_feat_name_file)
num_users, num_user_features = user_feat_mat.shape
print('num_users=%d num_user_features=%d' % (num_users, num_user_features))
num_items, num_item_features = item_feat_mat.shape
print('num_items=%d num_item_features=%d' % (num_items, num_item_features))

propensity_file = path.join(dnld_dir, 'propensities.ascii')
propensity_mat = np.loadtxt(propensity_file)
assert (num_users, num_items) == propensity_mat.shape

data_dir = path.expanduser('~/Projects/drrec/data')
data_dir = path.join(data_dir, dataset)
if not path.exists(data_dir):
  os.makedirs(data_dir)

def save_id(ids):
  user_ids, item_ids, *_ = ids
  ## save user features
  user_entries = []
  for user in range(num_users):
    user_entry = [user_ids[user]]
    if input_feature == fmm_input:
      user_feat_ids = ids[2]
      user_feat_vec = user_feat_mat[user,:]
      user_features, = user_feat_vec.nonzero()
      for user_feature in user_features:
        user_entry += [user_feat_ids[user_feature]]
    user_entries.append(user_entry)
  user_feat_file = path.join(data_dir, prefix + '.user')
  save_space_sep(user_entries, user_feat_file)
  ## save item features
  item_entries = []
  for item in range(num_items):
    item_entry = [item_ids[item]]
    if input_feature == fmm_input:
      item_feat_ids = ids[3]
      item_feat_vec = item_feat_mat[item,:]
      item_features, = item_feat_vec.nonzero()
      for item_feature in item_features:
        item_entry += [item_feat_ids[item_feature]]
    item_entries.append(item_entry)
  item_feat_file = path.join(data_dir, prefix + '.item')
  save_space_sep(item_entries, item_feat_file)

def load_entry(ratings, ids):
  user_ids, item_ids, *_ = ids
  entries = []
  for user, item, rating in ratings:
    propensity = propensity_mat[user, item]
    user_feat_vec = user_feat_mat[user,:]
    item_feat_vec = item_feat_mat[item,:]
    user_features, = user_feat_vec.nonzero()
    item_features, = item_feat_vec.nonzero()
    assert len(user_features) == 4
    assert len(item_features) == 4
    entry = [rating, propensity]
    entry += [user_ids[user]]
    entry += [item_ids[item]]
    if input_feature == fmm_input:
      *_, user_feat_ids, item_feat_ids = ids
      for user_feature in user_features:
        entry += [user_feat_ids[user_feature]]
      for item_feature in item_features:
        entry += [item_feat_ids[item_feature]]
    entries.append(entry)
  return entries

def main():
  train_ratings = load_coat_rating(train_in_file)
  test_ratings = load_coat_rating(test_in_file)

  ## devel
  with open(path.join(data_dir, 'train.rating'), 'w') as fout:
    for user, item, rating in train_ratings:
      fout.write('%d %d %d\n' % (user, item, rating))
  with open(path.join(data_dir, 'test.rating'), 'w') as fout:
    for user, item, rating in test_ratings:
      fout.write('%d %d %d\n' % (user, item, rating))

  train_size = len(train_ratings)
  test_size = len(test_ratings)
  print('train_size=%d test_size=%d' % (train_size, test_size))

  users = list(range(num_users))
  items = list(range(num_items))
  user_features = []
  item_features = []
  if input_feature == fmm_input:
    user_features = list(range(num_user_features))
    item_features = list(range(num_item_features))
  start_id = 0
  user_ids = assign_id(users, start_id)
  if input_feature == mf_input:
    start_id = 0
    item_ids = assign_id(items, start_id)
  else:
    start_id = num_users
    item_ids = assign_id(items, start_id)
  start_id = num_users + num_items
  user_feat_ids = assign_id(user_features, start_id)
  start_id = num_users + num_items + num_user_features
  item_feat_ids = assign_id(item_features, start_id)
  ids = user_ids, item_ids, user_feat_ids, item_feat_ids
  save_id(ids)

  train_entries = load_entry(train_ratings, ids)
  test_entries = load_entry(test_ratings, ids)
  train_out_file = path.join(data_dir, prefix + '.train')
  valid_out_file = path.join(data_dir, prefix + '.valid')
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(train_entries, train_out_file)
  save_space_sep(test_entries, valid_out_file)
  save_space_sep(test_entries, test_out_file)

  ## ids start from one, separated by ::
  print('preprocess %s for running autorec' % (dataset))
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  max_user = max([rating[0] for rating in train_ratings])
  min_user = min([rating[0] for rating in train_ratings])
  print('max_user=%d min_user=%d' % (max_user, min_user))
  rating_file = path.join(data_dir, 'coat.autorec.rating')
  with open(rating_file, 'w') as fout:
    for user, item, rating, *_ in train_ratings + test_ratings:
      user = user + 1
      item = item + 1
      timestamp = int(round(time.time()))
      fout.write('%d::%d::%d::%d\n' % (user, item, rating, timestamp))
  meta_data_file = path.join(data_dir, 'coat.autorec.meta.data')
  meta_data = {'num_users': num_users,
               'num_items': num_items,
               'train_size': train_size,
               'test_size': test_size}
  pickle.dump(meta_data, open(meta_data_file, 'wb'))

if __name__ == '__main__':
  main()
