from utils import *

from os import path
from sys import stdout
import argparse
import numpy as np
import os
import pickle
import pprint
import sys
import time

parser = argparse.ArgumentParser(description='preprocess mcoat data')
args = parser.parse_args()

dataset = 'mcoat'
prefix = '%s' % (dataset)

dnld_dir = path.expanduser('~/Downloads/coat')
feat_dir = path.join(dnld_dir, 'user_item_features')
train_in_file = path.join(dnld_dir, 'train.ascii')
test_in_file = path.join(dnld_dir, 'test.ascii')

dnld_url = 'https://www.cs.cornell.edu/~schnabts/mnar/coat.zip'
download_zip(dnld_dir, dnld_url)

user_feat_file = path.join(feat_dir, 'user_features.ascii')
user_feat_name_file = path.join(feat_dir, 'user_features_map.txt')
user_feat_mat = load_coat_feature(user_feat_file, user_feat_name_file)
item_feat_file = path.join(feat_dir, 'item_features.ascii')
item_feat_name_file = path.join(feat_dir, 'item_features_map.txt')
item_feat_mat = load_coat_feature(item_feat_file, item_feat_name_file)
num_users, num_user_features = user_feat_mat.shape
print('num_users=%d num_user_features=%d' % (num_users, num_user_features))
num_items, num_item_features = item_feat_mat.shape
print('num_items=%d num_item_features=%d' % (num_items, num_item_features))

propensity_file = path.join(dnld_dir, 'propensities.ascii')
propensity_mat = np.loadtxt(propensity_file)
assert (num_users, num_items) == propensity_mat.shape

def load_entry(ratings, user_ids, item_ids):
  entries = []
  for user, item, rating in ratings:
    user = user_ids[user]
    item = item_ids[item]
    propensity = propensity_mat[user, item]
    entry = (rating, propensity, user, item)
    entries.append(entry)
  return entries

def main():
  data_dir = path.expanduser('~/Projects/drrec/data')
  data_dir = path.join(data_dir, dataset)
  if not path.exists(data_dir):
    os.makedirs(data_dir)

  random_seed = np.random.random_integers(0, 1000000)
  random_seed = 676728
  np.random.seed(random_seed)
  ratings = load_coat_rating(train_in_file)
  np.random.shuffle(ratings)
  num_ratings = len(ratings)
  test_size = num_ratings // 10
  train_ratings = ratings[test_size:]
  test_ratings = ratings[:test_size]

  users = set([r[0] for r in train_ratings])
  items = set([r[1] for r in train_ratings])
  user_ids = assign_id(users, 0)
  item_ids = assign_id(items, 0)

  propensity_eval = est_propensity(train_ratings, test_ratings)
  train_entries = load_entry(train_ratings, user_ids, item_ids)
  test_entries = load_entry(test_ratings, user_ids, item_ids)
  train_out_file = path.join(data_dir, prefix + '.train')
  valid_out_file = path.join(data_dir, prefix + '.valid')
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(train_entries, train_out_file)
  save_space_sep(test_entries, valid_out_file)
  save_space_sep(test_entries, test_out_file)
  propensity_file = '%s.propensity.eval' % (dataset)
  propensity_file = path.join(data_dir, propensity_file)
  pickle.dump(propensity_eval, open(propensity_file, 'wb'))

  ## librec
  data_dir = path.expanduser('~/Projects/librec/data/%s' % (dataset))
  train_out_file = path.join(data_dir, 'train/ratings_1.txt')
  test_out_file = path.join(data_dir, 'test/ratings_0.txt')
  train_ratings = sorted(train_ratings, key=lambda r: (r[0], r[1]))
  test_ratings = sorted(test_ratings, key=lambda r: (r[0], r[1]))
  save_space_sep(train_ratings, train_out_file)
  save_space_sep(test_ratings, test_out_file)

if __name__ == '__main__':
  main()

