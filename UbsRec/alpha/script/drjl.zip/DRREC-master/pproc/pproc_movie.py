from utils import *

from os import path
import os
import pprint
import time

def load_rating(rating_file, delimiter=None):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      if delimiter == None:
        fields = line.strip().split()
      else:
        fields = line.strip().split(delimiter)
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

def main():
  dataset = 'movie'
  num_cores = 20
  dnld_dir = path.expanduser('~/Downloads/ml-1m')
  dnld_url = 'http://files.grouplens.org/datasets/movielens/ml-1m.zip'
  download_zip(dnld_dir, dnld_url)

  rating_file = path.join(dnld_dir, 'ratings.dat')
  ratings = load_rating(rating_file, delimiter='::')
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))
  while True:
    user_count, item_count = count_user_item(ratings)
    num_users = len(user_count.keys())
    num_items = len(item_count.keys())
    print('intotal num_users=%d num_items=%d' % (num_users, num_items))
    inv_users, inv_items = get_invalid(user_count, item_count, num_cores)
    f_data = (len(inv_users), len(inv_items))
    print('invalid num_users=%d num_items=%d' % f_data)
    if len(inv_users) == 0 and len(inv_items) == 0:
      break
    ratings = remove_invalid(ratings, inv_users, inv_items)
  num_ratings = len(ratings)
  print('num_ratings=%d' % (num_ratings))

  train_ratings, test_ratings = split_randomly(ratings)
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  print('train_size=%d test_size=%d' % (train_size, test_size))

  data_dir = path.expanduser('~/Projects/drrec/data')
  data_dir = path.join(data_dir, dataset)
  if not path.exists(data_dir):
    os.makedirs(data_dir)

  users = set()
  for user, *_ in ratings:
    users.add(user)
  items = set()
  for _, item, *_ in ratings:
    items.add(item)
  num_users = len(users)
  num_items = len(items)
  print('num_users=%d num_items=%d' % (num_users, num_items))

  ## autorec
  user_ids = assign_id(users, 1)
  item_ids = assign_id(items, 1)
  prefix = '%s.autorec' % (dataset)
  rating_file = path.join(data_dir, prefix + '.rating')
  ratings = train_ratings + test_ratings
  entries = number_user_item(ratings, user_ids, item_ids)
  timestamp = int(round(time.time()))
  entries = [entry + (timestamp,) for entry in entries]
  save_space_sep(entries, rating_file, delimiter='::')
  meta_data = num_users, num_items, train_size, test_size
  meta_data_file = path.join(data_dir, prefix + '.meta.data')
  save_meta_data(meta_data, meta_data_file)

  ## librec
  data_dir = path.expanduser('~/Projects/librec/data/movie')
  train_file = path.join(data_dir, 'train/ratings_1.txt')
  test_file = path.join(data_dir, 'test/ratings_0.txt')

  ratings = load_rating(rating_file, delimiter='::')
  train_ratings = load_rating(train_file)
  test_ratings = load_rating(test_file)
  for autorec, librec in zip(ratings, train_ratings + test_ratings):
    assert autorec[0] - 1 == librec[0]
    assert autorec[1] - 1 == librec[1]
    assert autorec[2] == librec[2]

if __name__ == '__main__':
  main()

