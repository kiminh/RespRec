from utils import *

from os import path
import argparse
import os
import pprint
import sys

parser = argparse.ArgumentParser(description='preprocess coat data')
parser.add_argument('input_feature', type=str, help='fml|mf')
args = parser.parse_args()

dataset = 'song'
input_feature = args.input_feature
if input_feature not in [fml_input, mf_input]:
  raise Exception('unknown input feature %s' % (input_feature))
prefix = '%s.%s' % (dataset, input_feature)

dnld_dir = path.expanduser('~/Downloads/Webscope_R3')
if not path.exists(dnld_dir):
  raise Exception('%s dataset not in %s' % (dataset, dnld_dir))
data_dir = path.expanduser('~/Projects/drrec/data')
data_dir = path.join(data_dir, dataset)
if not path.exists(data_dir):
  os.makedirs(data_dir)

train_in_file = 'ydata-ymusic-rating-study-v1_0-train.txt'
train_in_file = path.join(dnld_dir, train_in_file)
test_in_file = 'ydata-ymusic-rating-study-v1_0-test.txt'
test_in_file = path.join(dnld_dir, test_in_file)

train_ratings = load_song_rating(train_in_file)
test_ratings = load_song_rating(test_in_file)
users = set([rating[0] for rating in train_ratings])
items = set([rating[1] for rating in train_ratings])
num_users = len(users)
num_items = len(items)
# print('num_users=%d num_items=%d' % (num_users, num_items))

def main():
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  # print('train_size=%d test_size=%d' % (train_size, test_size))

  if input_feature == fml_input:
    user_ids = assign_id(users, 0)
    item_ids = assign_id(items, num_users)
    for user in users:
      assert user == user_ids[user] + 1
    for item in items:
      assert item == item_ids[item] + 1 - num_users
  elif input_feature == mf_input:
    user_ids = assign_id(users, 0)
    item_ids = assign_id(items, 0)
    for user in users:
      assert user == user_ids[user] + 1
    for item in items:
      assert item == item_ids[item] + 1
  else:
    raise Exception('unknown input feature %s' % (input_feature))

  ids = user_ids, item_ids
  propensity_eval = est_propensity(train_ratings, test_ratings)
  train_entries = load_song_entry(train_ratings, ids, propensity_eval)
  test_entries = load_song_entry(test_ratings, ids, propensity_eval)

  train_out_file = path.join(data_dir, prefix + '.train')
  valid_out_file = path.join(data_dir, prefix + '.valid')
  test_out_file = path.join(data_dir, prefix + '.test')
  save_space_sep(train_entries, train_out_file)
  save_space_sep(test_entries, valid_out_file)
  save_space_sep(test_entries, test_out_file)

  user_entries = []
  for user in sorted(users):
    user_entries.append([user_ids[user]])
  item_entries = []
  for item in sorted(items):
    item_entries.append([item_ids[item]])
  user_feat_file = path.join(data_dir, prefix + '.user')
  save_space_sep(user_entries, user_feat_file)
  item_feat_file = path.join(data_dir, prefix + '.item')
  save_space_sep(item_entries, item_feat_file)

if __name__ == '__main__':
  main()


