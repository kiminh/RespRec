from os import path
from sys import stdout
import argparse

latex_names = {'amazon': 'Amazon'}

def load_rating(rating_file, delimiter=None):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      if delimiter == None:
        fields = line.strip().split()
      else:
        fields = line.strip().split(delimiter)
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

def count_entity(ratings):
  users = set([rating[0] for rating in ratings])
  items = set([rating[1] for rating in ratings])
  num_users = len(users)
  num_items = len(items)
  return num_users, num_items

def thousand_sep(f_data):
  f_list = []
  for data in f_data:
    if type(data) == int:
      f_list.append('{:,}'.format(data))
    else:
      f_list.append(data)
  return tuple(f_list)

def print_stats(dataset_name):
  data_dir = path.expanduser('~/Projects/librec/data')
  data_dir = path.join(data_dir, dataset_name)
  train_file = path.join(data_dir, 'train/ratings_1.txt')
  test_file = path.join(data_dir, 'test/ratings_0.txt')
  train_ratings = load_rating(train_file)
  test_ratings = load_rating(test_file)
  train_size = len(train_ratings)
  test_size = len(test_ratings)
  # print('train_size=%d test_size=%d' % (train_size, test_size))

  num_users, num_items = count_entity(train_ratings)
  # print('num_users=%d num_items=%d' % (num_users, num_items))

  f_data = (latex_names[dataset_name],)
  f_data += (num_users, num_items, train_size, test_size)
  f_data = thousand_sep(f_data)
  print('%s & %s & %s & %s & %s \\\\' % f_data)

def main():
  ## movielens
  rating_file = path.expanduser('~/Downloads/ml-1m/ratings.dat')
  ratings = load_rating(rating_file, delimiter='::')
  num_users, num_items = count_entity(ratings)
  num_ratings = len(ratings)
  test_size = num_ratings // 10
  train_size = num_ratings - test_size
  f_data = ('ML-1M',)
  f_data += (num_users, num_items, train_size, test_size)
  f_data = thousand_sep(f_data)
  print('%s & %s & %s & %s & %s \\\\' % f_data)

  dataset_names = ['amazon']
  for dataset_name in dataset_names:
    print_stats(dataset_name)

if __name__ == '__main__':
  main()

