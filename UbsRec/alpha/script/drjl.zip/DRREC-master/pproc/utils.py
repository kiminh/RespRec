from os import path
from sys import stdout
import numpy as np
import os
import pickle

num_folds = 10
fmm_input = 'fmm' # fm more input features
fml_input = 'fml' # fm less input features
mf_input = 'mf'

def download_zip(dnld_dir, dnld_url):
  if not path.exists(dnld_dir):
    dnld_dir = path.dirname(dnld_dir)
    dnld_zip = path.join(dnld_dir, 'data.zip')
    print('download data from %s' % (dnld_url))
    os.system('wget %s -O %s' % (dnld_url, dnld_zip))
    print('uncompress data to %s' % (dnld_dir))
    os.system('unzip %s -d %s' % (dnld_zip, dnld_dir))

def save_space_sep(entries, out_file, delimiter=None):
  out_dir = path.dirname(out_file)
  if not path.exists(out_dir):
    os.makedirs(out_dir)
  num_entries = len(entries)
  with open(out_file, 'w') as fout:
    for entry in entries:
      entry = [str(f) for f in entry]
      if delimiter == None:
        fout.write('%s\n' % (' '.join(entry)))
      else:
        fout.write('%s\n' % (delimiter.join(entry)))
  print('save %d entries to %s' % (num_entries, out_file))

def save_meta_data(meta_data, out_file):
  assert len(meta_data) == 4
  num_users, num_items, train_size, test_size = meta_data
  meta_data = {'num_users': num_users,
               'num_items': num_items,
               'train_size': train_size,
               'test_size': test_size}
  pickle.dump(meta_data, open(out_file, 'wb'))
  print('save meta_data to %s' % (out_file))

def count_user_item(entries):
  user_count = dict()
  item_count = dict()
  for user, item, *_ in entries:
    user_count[user] = user_count.get(user, 0) + 1
    item_count[item] = item_count.get(item, 0) + 1
  return user_count, item_count

def get_invalid(user_count, item_count, num_cores):
  inv_users = set([u for u, c in user_count.items() if c < num_cores])
  inv_items = set([i for i, c in item_count.items() if c < num_cores])
  return inv_users, inv_items

def remove_invalid(ratings, inv_users, inv_items):
  valid_ratings = []
  for user, item, rating in ratings:
    if user in inv_users:
      continue
    if item in inv_items:
      continue
    valid_ratings.append((user, item, rating))
  return valid_ratings

def split_randomly(ratings, random_seed=0):
  np.random.seed(random_seed)
  np.random.shuffle(ratings)
  num_ratings = len(ratings)
  test_size = num_ratings // 10
  train_ratings = []
  test_ratings = []
  for i in range(num_ratings):
    if i < test_size:
      test_ratings.append(ratings[i])
    else:
      train_ratings.append(ratings[i])
  return train_ratings, test_ratings

def assign_id(entities, start_id):
  entity_ids = dict()
  entities = sorted(entities)
  entity_id = start_id
  for entity in entities:
    entity_ids[entity] = entity_id
    entity_id += 1
  return entity_ids

def number_user_item(ratings, user_ids, item_ids):
  entries = []
  for user, item, rating in ratings:
    user = user_ids[user]
    item = item_ids[item]
    entries.append((user, item, rating))
  return entries

def est_propensity(train_ratings, test_ratings):
  def count_rating(ratings):
    rating_count = dict()
    for *_, rating in ratings:
      rating_count[rating] = rating_count.get(rating, 0) + 1
    return rating_count

  train_ratings = sorted(train_ratings, key=lambda e: (e[0], e[1]))
  test_ratings = sorted(test_ratings, key=lambda e: (e[0], e[1]))

  train_size = len(train_ratings)
  test_size = len(test_ratings)
  propensity_size = test_size // 20 + 1

  users = set([rating[0] for rating in train_ratings])
  items = set([rating[1] for rating in train_ratings])
  num_users = len(users)
  num_items = len(items)

  p_o = train_size / (num_users * num_items)
  train_count = count_rating(train_ratings)
  assert sum(train_count.values()) == train_size
  p_r_o = {k: v / train_size for k, v in train_count.items()}
  
  # test_count = count_rating(test_ratings)
  # assert sum(test_count.values()) == test_size
  # p_r = {k: v / test_size for k, v in test_count.items()}
  np.random.seed(0)
  np.random.shuffle(test_ratings)
  test_count = count_rating(test_ratings[:propensity_size])
  p_r = {k: v / propensity_size for k, v in test_count.items()}

  p_o_r = {k: p_r_o[k] * p_o / p_r[k] for k, v in p_r_o.items()}

  print('train_size=%d test_size=%d' % (train_size, test_size))
  print('num_users=%d num_items=%d' % (num_users, num_items))
  print('p_o %.8f' % (p_o))
  stdout.write('p_r_o')
  for k, v in p_r_o.items():
    stdout.write(' %d:%.4f' % (k, v))
  stdout.write('\n')
  stdout.write('p_r')
  for k, v in p_r.items():
    stdout.write(' %d:%.4f' % (k, v))
  stdout.write('\n')
  stdout.write('p_o_r')
  for k, v in p_o_r.items():
    stdout.write(' %d:%.4f' % (k, v))
  stdout.write('\n')
  max_diff = 0.0
  stdout.write('|p_o_r-p_o|')
  for k, v in p_o_r.items():
    stdout.write(' %d:%.4f' % (k, abs(v - p_o)))
    max_diff = max(max_diff, abs(v - p_o))
  stdout.write('\n')
  print(max_diff)

  propensity_eval = p_o_r
  propensity_eval['num_users'] = num_users
  propensity_eval['num_items'] = num_items
  return propensity_eval

def load_coat_rating(in_file):
  ratings = []
  rating_mat = np.loadtxt(in_file, dtype=np.int32)
  users, items = rating_mat.nonzero()
  for user, item in zip(users, items):
    rating = rating_mat[user, item]
    ratings.append((user, item, rating))
  return ratings

def load_coat_feature(feature_file, feat_name_file):
  feature_mat = np.loadtxt(feature_file, dtype=np.int32)
  num_objects, num_features = feature_mat.shape
  feature_list = []
  feature_names = {}
  with open(feat_name_file) as fin:
    for line in fin.readlines():
      arr = line.strip().split(':')
      assert len(arr) == 2
      feature_names[arr[0]] = feature_names.get(arr[0], []) + [arr[1]]
      if len(feature_list) == 0 or arr[0] != feature_list[-1]:
        feature_list.append(arr[0])
  feature_indexes = []
  start = 0
  for feature in feature_list:
    stop = start + len(feature_names[feature])
    feature_indexes.append((start, stop))
    start = stop
  assert stop == num_features
  for i in range(num_objects):
    for start, stop in feature_indexes:
      one_hot = feature_mat[i, start:stop]
      assert np.sum(one_hot) == 1
  return feature_mat

def load_song_rating(rating_file):
  ratings = []
  with open(rating_file) as fin:
    while True:
      line = fin.readline()
      if not line:
        break
      fields = line.strip().split()
      user = int(fields[0])
      item = int(fields[1])
      rating = int(fields[2])
      ratings.append((user, item, rating))
  return ratings

def load_song_entry(ratings, ids, propensity_eval):
  user_ids, item_ids = ids
  entries = []
  for user, item, rating in ratings:
    propensity = propensity_eval[rating]
    entry = [rating, propensity, user_ids[user], item_ids[item]]
    entries.append(entry)
  return entries