from utils import _ukey, _ikey, _rkey, _wkey
import utils

from os import path
from scipy import sparse
from sklearn import metrics
import math
import numpy as np
import os
import pprint
import random
import tensorflow as tf
import time

import logging
logging.basicConfig(level=logging.INFO, format=utils.log_format)

class DrRec(object):
  def __init__(self, args, data):
    self._args = args
    self._data = data

    users = tf.placeholder(tf.int32, (None,), name='users')
    items = tf.placeholder(tf.int32, (None,), name='items')
    ratings = tf.placeholder(tf.float32, (None,), name='ratings')
    weights = tf.placeholder(tf.float32, (None,), name='weights')
    self.users = users
    self.items = items
    self.ratings = ratings
    self.weights = weights

    pred_scope = 'pred_model'
    pred_include_bias = self._args.pred_include_bias
    with tf.variable_scope(pred_scope):
      pred_params, pred_ratings = self._init_graph(pred_include_bias)
    pred_var_list = [var for var in pred_params.values()]
    self.pred_ratings = pred_ratings

    all_reg_coeff = self._args.all_reg_coeff
    obs_errors = tf.subtract(ratings, pred_ratings)
    self.obs_errors = obs_errors
    # obs_error = tf.reduce_sum(tf.square(obs_errors))
    # mean is a bad idea
    # obs_error = tf.reduce_mean(tf.square(obs_errors))
    obs_error = tf.reduce_sum(tf.square(obs_errors) * weights)
    obs_regularizers = [tf.reduce_sum(tf.square(var)) for var in pred_var_list]
    obs_regularizer = tf.add_n(obs_regularizers)
    obs_loss = tf.add(obs_error, all_reg_coeff * obs_regularizer)
    self.obs_loss = obs_loss
    pred_learning_rate = self._args.pred_learning_rate
    pred_optimizer = tf.train.GradientDescentOptimizer(pred_learning_rate)
    obs_update = pred_optimizer.minimize(obs_loss, var_list=pred_var_list)
    self.obs_update = obs_update

    impt_scope = 'impt_model'
    impt_include_bias = self._args.impt_include_bias
    with tf.variable_scope(impt_scope):
      impt_params, pred_errors = self._init_graph(impt_include_bias)
    impt_var_list = [var for var in impt_params.values()]
    self.pred_errors = pred_errors

    impt_errors = tf.subtract(obs_errors, pred_errors)
    impt_error = tf.reduce_sum(tf.square(impt_errors))
    impt_regularizers = [tf.reduce_sum(tf.square(var)) for var in impt_var_list]
    impt_regularizer = tf.add_n(impt_regularizers)
    impt_loss = tf.add(impt_error, all_reg_coeff * impt_regularizer)
    self.impt_loss = impt_loss
    impt_learning_rate = self._args.impt_learning_rate
    impt_optimizer = tf.train.GradientDescentOptimizer(impt_learning_rate)
    impt_update = impt_optimizer.minimize(impt_loss, var_list=impt_var_list)
    self.impt_update = impt_update


    min_rating = self._data.min_rating
    max_rating = self._data.max_rating
    ratings = tf.stop_gradient(pred_ratings) + pred_errors
    ratings = tf.clip_by_value(ratings, min_rating, max_rating)
    mis_loss = tf.reduce_sum(tf.square(ratings - self.pred_ratings))
    self.mis_loss = mis_loss
    mis_optimizer = tf.train.GradientDescentOptimizer(pred_learning_rate)
    mis_update = mis_optimizer.minimize(mis_loss, var_list=pred_var_list)
    self.mis_update = mis_update

    # [print(var.name) for var in impt_var_list]
    impt_init = tf.variables_initializer(impt_var_list)
    self.impt_init = impt_init
    pred_init = tf.variables_initializer(pred_var_list)
    self.pred_init = pred_init

  def _init_graph(self, include_bias):
    num_factors = self._args.num_factors
    num_users = self._data.num_users
    num_items = self._data.num_items

    user_embedding = tf.Variable(
        tf.random_normal((num_users, num_factors)) / np.sqrt(num_users),
        name='user_embedding')
    item_embedding = tf.Variable(
        tf.random_normal((num_items, num_factors)) / np.sqrt(num_items),
        name='item_embedding')
    parameters = {'user_embedding': user_embedding,
                  'item_embedding': item_embedding}
    user_embedding_lookup = tf.nn.embedding_lookup(user_embedding, self.users)
    item_embedding_lookup = tf.nn.embedding_lookup(item_embedding, self.items)
    predictions = tf.reduce_sum(
        tf.multiply(user_embedding_lookup, item_embedding_lookup),
        axis=1)

    if include_bias > 0:
      user_bias = tf.Variable(tf.zeros((num_users,)), name='user_bias')
      item_bias = tf.Variable(tf.zeros((num_items,)), name='item_bias')
      parameters.update({'user_bias': user_bias,
                         'item_bias': item_bias})
      user_bias_lookup = tf.nn.embedding_lookup(user_bias, self.users)
      item_bias_lookup = tf.nn.embedding_lookup(item_bias, self.items)
      predictions += (user_bias_lookup + item_bias_lookup)

    return parameters, predictions

  def _is_overfit(self, valid_res):
    max_early_stop = self._args.max_early_stop
    if len(valid_res) > max_early_stop:
      is_overfit = True
      for i in range(-1, -max_early_stop - 1, -1):
        if valid_res[i] < valid_res[i - 1]:
          is_overfit = False
          break
    else:
      is_overfit = False
    return is_overfit

  def _eval_pred_model(self, eval_data):
    min_rating = self._data.min_rating
    max_rating = self._data.max_rating
    eval_size, _ = eval_data.shape
    num_batches = 10
    batch_size = eval_size // num_batches
    pred_list = []
    for batch in range(num_batches):
      start = batch * batch_size
      stop = (batch + 1) * batch_size
      if (batch + 1) == num_batches:
        stop = eval_size
      feed_dict = {self.users: eval_data[_ukey][start:stop], 
                   self.items: eval_data[_ikey][start:stop]}
      fetch = self.pred_ratings
      pred_ratings = self.sess.run(fetch, feed_dict=feed_dict)
      pred_ratings = np.maximum(pred_ratings, min_rating)
      pred_ratings = np.minimum(pred_ratings, max_rating)
      pred_list.append(pred_ratings)
    pred_ratings = np.concatenate(pred_list)
    ratings = eval_data[_rkey]
    mae = metrics.mean_absolute_error(ratings, pred_ratings)
    mse = metrics.mean_squared_error(ratings, pred_ratings)
    return mae, mse

  def _eval_impt_model(self, eval_data):
    feed_dict = {self.users: eval_data[_ukey], 
                 self.items: eval_data[_ikey],
                 self.ratings: eval_data[_rkey]}
    fetches = (self.obs_errors, self.pred_errors)
    results = self.sess.run(fetches, feed_dict=feed_dict)
    obs_errors = results[0]
    pred_errors = results[1]
    mae = metrics.mean_absolute_error(obs_errors, pred_errors)
    mse = metrics.mean_squared_error(obs_errors, pred_errors)
    return mae, mse

  def train(self):
    early_stop = self._args.early_stop
    pretrain_epochs = self._args.pretrain_epochs
    interact_epochs = self._args.interact_epochs
    num_impt_epochs = self._args.num_impt_epochs
    num_mis_epochs = self._args.num_mis_epochs
    num_obs_epochs = self._args.num_obs_epochs
    num_batches = self._args.num_batches
    verbose = self._args.verbose
    num_users = self._data.num_users
    num_items = self._data.num_items
    train_data = self._data.train_data
    valid_data = self._data.valid_data
    test_data = self._data.test_data
    train_size = self._data.train_size
    batch_size = train_size // num_batches

    epoch_str = []
    pred_valid_mae = []
    pred_valid_mse = []
    pred_test_mae = []
    pred_test_mse = []
    with tf.Session() as sess:
      self.sess = sess
      sess.run(tf.global_variables_initializer())
      start_time = time.time()
      for epoch in range(pretrain_epochs):
        # sess.run(self.pred_init)
        for batch in range(num_batches):
          start = batch * batch_size
          stop = (batch + 1) * batch_size
          if (batch + 1) == num_batches:
              stop = train_size
          feed_dict = {self.users: train_data[_ukey][start:stop],
                       self.items: train_data[_ikey][start:stop],
                       self.ratings: train_data[_rkey][start:stop],
                       self.weights: train_data[_wkey][start:stop]}
          sess.run(self.obs_update, feed_dict=feed_dict)

        pred_valid_res = self._eval_pred_model(valid_data)
        pred_test_res = self._eval_pred_model(test_data)
        pred_valid_mae.append(pred_valid_res[0])
        pred_valid_mse.append(pred_valid_res[1])
        pred_test_mae.append(pred_test_res[0])
        pred_test_mse.append(pred_test_res[1])
        epoch_str.append('pre#%d' % (epoch + 1))
        if verbose > 0 and (epoch + 1) % verbose == 0:
          stop_time = time.time()
          elapse = stop_time - start_time
          f_data = (epoch, pred_valid_res[1], pred_test_res[1], elapse)
          print('pre#%d valid=%.4f test=%.4f time=%.0fs' % f_data)
        if early_stop and self._is_overfit(pred_valid_mse):
          break
      best = pred_valid_mse.index(min(pred_valid_mse))
      stop_time = time.time()
      elapse = stop_time - start_time
      f_data = (epoch_str[best], pred_test_mae[best], pred_test_mse[best], elapse)
      print('%s\t%.4f\t%.4f\t%.0fs' % f_data)
      for epoch in range(interact_epochs):
        impt_valid_mse = []
        for i_epoch in range(num_impt_epochs):
          sess.run(self.impt_init)
          for batch in range(num_batches):
            start = batch * batch_size
            stop = (batch + 1) * batch_size
            if (batch + 1) == num_batches:
                stop = train_size
            feed_dict = {self.users: train_data[_ukey][start:stop],
                         self.items: train_data[_ikey][start:stop],
                         self.ratings: train_data[_rkey][start:stop],
                         self.weights: train_data[_wkey][start:stop]}
            sess.run(self.impt_update, feed_dict=feed_dict)
          impt_train_res = self._eval_impt_model(train_data)
          impt_valid_res = self._eval_impt_model(valid_data)
          impt_valid_mse.append(impt_valid_res[1])
          if verbose > 0 and (i_epoch + 1) % verbose == 0:
            f_data = ('\timp#%d#%d' % (epoch + 1, i_epoch + 1),
                      impt_train_res[1], impt_valid_res[1])
            print('%s train=%.4f valid=%.4f' % f_data)
          if early_stop and self._is_overfit(impt_valid_mse):
            break

        for m_epoch in range(num_mis_epochs):
          for batch in range(num_batches):
            mis_users = np.random.choice(num_users, batch_size)
            mis_items = np.random.choice(num_items, batch_size)
            feed_dict = {self.users: mis_users,
                         self.items: mis_items}
            sess.run(self.mis_update, feed_dict=feed_dict)
          pred_valid_res = self._eval_pred_model(valid_data)
          pred_test_res = self._eval_pred_model(test_data)
          pred_valid_mae.append(pred_valid_res[0])
          pred_valid_mse.append(pred_valid_res[1])
          pred_test_mae.append(pred_test_res[0])
          pred_test_mse.append(pred_test_res[1])
          m_epoch_str = 'mis#%d#%d' % (epoch + 1, m_epoch + 1)
          epoch_str.append(m_epoch_str)
          if verbose > 0 and (m_epoch + 1) % verbose == 0:
            stop_time = time.time()
            elapse = stop_time - start_time
            f_data = (m_epoch_str, pred_valid_res[1], pred_test_res[1], elapse)
            print('%s valid=%.4f test=%.4f time=%.0fs' % f_data)

        for o_epoch in range(num_obs_epochs):
          for batch in range(num_batches):
            start = batch * batch_size
            stop = (batch + 1) * batch_size
            if (batch + 1) == num_batches:
                stop = train_size
            feed_dict = {self.users: train_data[_ukey][start:stop],
                         self.items: train_data[_ikey][start:stop],
                         self.ratings: train_data[_rkey][start:stop],
                         self.weights: train_data[_wkey][start:stop]}
            sess.run(self.obs_update, feed_dict=feed_dict)
          pred_valid_res = self._eval_pred_model(valid_data)
          pred_test_res = self._eval_pred_model(test_data)
          pred_valid_mae.append(pred_valid_res[0])
          pred_valid_mse.append(pred_valid_res[1])
          pred_test_mae.append(pred_test_res[0])
          pred_test_mse.append(pred_test_res[1])
          o_epoch_str = 'obs#%d#%d' % (epoch + 1, o_epoch + 1)
          epoch_str.append(o_epoch_str)
          if verbose > 0 and (o_epoch + 1) % verbose == 0:
            stop_time = time.time()
            elapse = stop_time - start_time
            f_data = (o_epoch_str, pred_valid_res[1], pred_test_res[1], elapse)
            print('%s valid=%.4f test=%.4f time=%.0fs' % f_data)
    args = self._args
    best = pred_valid_mse.index(min(pred_valid_mse))
    stop_time = time.time()
    elapse = stop_time - start_time
    f_data = (epoch_str[best], pred_test_mae[best], pred_test_mse[best], elapse, args)
    print('%s\t%.4f\t%.4f\t%.0fs\t%s' % f_data)

if __name__ == '__main__':
  description = 'Run a double robust model.'
  args = utils.parse_args(description)
  data = utils.Dataset(args)

  model = DrRec(args, data)
  [logging.info('%s' % (var.name)) for var in tf.trainable_variables()]
  try:
    model.train()
  except ValueError as e:
    f_data = ('NaN', 'NaN', 'NaN', 'NaN', args)
    print('%s\t%s\t%s\t%s\t\t%s' % f_data)

