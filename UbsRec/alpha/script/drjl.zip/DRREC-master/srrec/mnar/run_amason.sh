base_dir=~/Projects/drrec/data/amason/amason
pretrain_epochs=200
max_early_stop=10
verbose=1

all_reg_coeff=0.03 # 0.05
num_batches=50 # 10
num_factors=320
pred_include_bias=0
pred_learning_rate=1e-3
min_weight=1.0
max_weight=1000.0
python -W ignore ../drrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --max_early_stop ${max_early_stop} \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --pred_include_bias ${pred_include_bias} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate} \
    --min_weight ${min_weight} \
    --max_weight ${max_weight}
