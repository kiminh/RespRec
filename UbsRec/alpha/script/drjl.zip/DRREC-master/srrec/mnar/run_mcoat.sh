base_dir=~/Projects/drrec/data/mcoat/mcoat
pretrain_epochs=100
interact_epochs=10
num_impt_epochs=100
num_mis_epochs=80
num_obs_epochs=20
max_early_stop=10
verbose=10

all_reg_coeff=0.05
num_batches=10
num_factors=80
pred_include_bias=1
impt_include_bias=1
pred_learning_rate=1e-3
impt_learning_rate=5e-4
min_weight=1.0
max_weight=0.0 # 100.0
python -W ignore ../drrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --max_early_stop ${max_early_stop} \
    --pretrain_epochs ${pretrain_epochs} \
    --interact_epochs ${interact_epochs} \
    --num_impt_epochs ${num_impt_epochs} \
    --num_mis_epochs ${num_mis_epochs} \
    --num_obs_epochs ${num_obs_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_include_bias ${pred_include_bias} \
    --impt_include_bias ${impt_include_bias} \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_learning_rate ${impt_learning_rate} \
    --min_weight ${min_weight} \
    --max_weight ${max_weight}
