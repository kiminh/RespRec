base_dir=~/Projects/drrec/data/amazon/amazon
pretrain_epochs=1000
verbose=1

all_reg_coeff=0.05
num_batches=10
num_factors=400
pred_learning_rate=1e-3
python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}
