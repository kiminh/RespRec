base_dir=~/Projects/drrec/data/amazon/amazon
pretrain_epochs=1000
verbose=0

all_reg_coeff=0.05
num_batches=10
num_factors=400
pred_learning_rate=1e-3

for all_reg_coeff in 1e-3 5e-3 # 1e-2 5e-2 1e-1
do
  for num_batches in 10 20 # 100
  do
    for num_factors in 320 # 160 80
    do
      for pred_learning_rate in 5e-4 1e-3
      do

python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}

      done
    done
  done
done

