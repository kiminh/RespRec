base_dir=~/Projects/drrec/data/coat/coat.mf
max_early_stop=10
pretrain_epochs=1000
verbose=1

all_reg_coeff=5e-4
num_batches=64
num_factors=32
impt_weight=0.00
impt_rating=0.00

pred_learning_rate=5e-4
max_weight=100.0

pred_learning_rate=1e-4
max_weight=500.0
max_weight=1000.

pred_learning_rate=1e-5
max_weight=5000.
max_weight=10000

# for _ in $(seq 0 1 99)
for _ in $(seq 0 1 0)
do
python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --max_early_stop ${max_early_stop} \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --max_weight ${max_weight} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_weight ${impt_weight} \
    --impt_rating ${impt_rating} \
    --pred_include_bias 1
done
exit


for max_weight in 0.0 40. # 10. 20. 40. 80.
do
  for _ in $(seq 0 1 0)
  do
python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --max_early_stop ${max_early_stop} \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --max_weight ${max_weight} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}
  done
done
exit


impt_weight=0.01
for impt_rating in -2.0 -1.0 0.0 1.0 2.0
do
  for _ in $(seq 0 1 99)
  do
python -W ignore ../devel.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --max_early_stop ${max_early_stop} \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate} \
    --impt_weight ${impt_weight} \
    --impt_rating ${impt_rating}
  done
done
exit



