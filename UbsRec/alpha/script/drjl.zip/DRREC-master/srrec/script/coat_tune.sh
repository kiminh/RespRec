base_dir=~/Projects/drrec/data/coat/coat.mnar
pretrain_epochs=1000
verbose=0

for all_reg_coeff in 5e-3 1e-2 5e-2
do
  for num_batches in 64 128 226
  do
    for num_factors in 20 40 80
    do
      for pred_learning_rate in 5e-3 1e-2
      do

python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}

      done
    done
  done
done

