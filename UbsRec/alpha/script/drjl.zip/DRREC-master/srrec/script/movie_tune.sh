base_dir=~/Projects/drrec/data/movie/movie
pretrain_epochs=2000
verbose=0

all_reg_coeff=1.00
num_batches=10
num_factors=100
pred_learning_rate=1e-4

for all_reg_coeff in 0.5 1.0 5.0 10.
do
  for num_batches in 10 20 40 80
  do
    for num_factors in 100 200 400 800
    do
      for pred_learning_rate in 5e-5 1e-4 5e-4 1e-3
      do

python -W ignore ../srrec.py \
    --base_dir ${base_dir} \
    --optimizer_type adagrad \
    --pretrain_epochs ${pretrain_epochs} \
    --verbose ${verbose} \
    --all_reg_coeff ${all_reg_coeff} \
    --num_batches ${num_batches} \
    --num_factors ${num_factors} \
    --pred_learning_rate ${pred_learning_rate}

      done
    done
  done
done

