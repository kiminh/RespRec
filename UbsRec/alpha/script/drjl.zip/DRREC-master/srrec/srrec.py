import utils

from os import path
from scipy import sparse
from sklearn import metrics
import math
import numpy as np
import os
import pandas as pd
import pprint
import random
import tensorflow as tf
import time


_rkey = 'rating'
_wkey = 'weight'
_ukey = 'user'
_ikey = 'item'
_delimiter = ' '
class Dataset(object):
  def __init__(self, args):
    base_dir = args.base_dir
    train_file = base_dir + '.train'
    valid_file = base_dir + '.valid'
    test_file = base_dir + '.test'

    params = {'header': None,
              'delimiter': _delimiter,
              'names': [_rkey, _wkey, _ukey, _ikey,],
              'dtype': {_rkey: np.int32,
                        _wkey: np.float32,
                        _ukey: np.int32,
                        _ikey: np.int32}}

    train_data = pd.read_csv(train_file, **params)
    valid_data = pd.read_csv(valid_file, **params)
    test_data = pd.read_csv(test_file, **params)

    num_users = train_data[_ukey].max() + 1
    num_items = train_data[_ikey].max() + 1
    train_size = train_data[_rkey].size
    test_size = test_data[_rkey].size
    min_rating = train_data[_rkey].min()
    max_rating = train_data[_rkey].max()

    train_data[_wkey] = 1.0 / train_data[_wkey]
    min_weight = train_data[_wkey].min()
    old_weight = train_data[_wkey].max()
    max_weight = args.max_weight
    scale_ratio = (max_weight - min_weight) / (old_weight - min_weight)
    train_data[_wkey] = (train_data[_wkey] - min_weight) * scale_ratio + min_weight
    max_weight = train_data[_wkey].max()

    verbose = args.verbose
    if verbose > 0:
      print('num_users=%d' % (num_users))
      print('num_items=%d' % (num_items))
      print('train_size=%d' % (train_size))
      print('test_size=%d' % (test_size))
      print('min_rating=%d' % (min_rating))
      print('max_rating=%d' % (max_rating))
      print('min_weight=%.4f' % (min_weight))
      print('max_weight=%.4f' % (max_weight))

    self.train_data = train_data
    self.valid_data = valid_data
    self.test_data = test_data
    self.num_users = num_users
    self.num_items = num_items
    self.train_size = train_size
    self.test_size = test_size
    self.min_rating = min_rating
    self.max_rating = max_rating

class IpsRec(object):
  def __init__(self, args, data):
    self._args = args
    self._data = data

    all_reg_coeff = args.all_reg_coeff
    num_factors = args.num_factors
    num_users = data.num_users
    num_items = data.num_items

    users = tf.placeholder(tf.int32, (None,), name='users')
    items = tf.placeholder(tf.int32, (None,), name='items')
    ratings = tf.placeholder(tf.float32, (None,), name='ratings')
    weights = tf.placeholder(tf.float32, (None,), name='weights')
    self.users = users
    self.items = items
    self.ratings = ratings
    self.weights = weights

    user_embedding = tf.Variable(
        tf.random_normal((num_users, num_factors)) / np.sqrt(num_users),
        name='user_embedding')
    item_embedding = tf.Variable(
        tf.random_normal((num_items, num_factors)) / np.sqrt(num_items),
        name='item_embedding')
    user_embedding_lookup = tf.nn.embedding_lookup(user_embedding, users)
    item_embedding_lookup = tf.nn.embedding_lookup(item_embedding, items)

    user_bias = tf.Variable(tf.zeros((num_users,)), name='user_bias')
    item_bias = tf.Variable(tf.zeros((num_items,)), name='item_bias')
    user_bias_lookup = tf.nn.embedding_lookup(user_bias, users)
    item_bias_lookup = tf.nn.embedding_lookup(item_bias, items)

    pred_ratings = tf.reduce_sum(
        tf.multiply(user_embedding_lookup, item_embedding_lookup),
        axis=1)
    pred_ratings += (user_bias_lookup + item_bias_lookup)

    errors = tf.subtract(ratings, pred_ratings)
    # reconstruct_loss = tf.reduce_sum(tf.square(errors))
    reconstruct_loss = tf.reduce_sum(tf.square(errors) * weights)
    regularizer_losses = []
    for variable in tf.trainable_variables():
      # print('%s=%s' % (variable.name, variable.shape))
      regularizer_losses.append(tf.reduce_sum(tf.square(variable)))
    regularizer_loss = tf.add_n(regularizer_losses)
    loss = tf.add(reconstruct_loss, all_reg_coeff * regularizer_loss)

    pred_learning_rate = self._args.pred_learning_rate
    optimizer = tf.train.GradientDescentOptimizer(pred_learning_rate)
    # , var_list=[user_bias, item_bias, user_embedding, item_embedding]
    train_op = optimizer.minimize(loss)

    self.train_op = train_op
    self.pred_ratings = pred_ratings
    self.loss = loss

  def _is_overfit(self, valid_res):
    max_early_stop = self._args.max_early_stop
    if len(valid_res) > max_early_stop:
      is_overfit = True
      for i in range(-1, -max_early_stop - 1, -1):
        if valid_res[i] < valid_res[i - 1]:
          is_overfit = False
          break
    else:
      is_overfit = False
    return is_overfit

  def _eval_pred_model(self, eval_data):
    min_rating = self._data.min_rating
    max_rating = self._data.max_rating
    eval_size, _ = eval_data.shape
    num_batches = 10
    batch_size = eval_size // num_batches
    pred_list = []
    for batch in range(num_batches):
      start = batch * batch_size
      stop = (batch + 1) * batch_size
      if (batch + 1) == num_batches:
        stop = eval_size
      feed_dict = {self.users: eval_data[_ukey][start:stop], 
                   self.items: eval_data[_ikey][start:stop]}
      fetch = self.pred_ratings
      pred_ratings = self.sess.run(fetch, feed_dict=feed_dict)
      pred_ratings = np.maximum(pred_ratings, min_rating)
      pred_ratings = np.minimum(pred_ratings, max_rating)
      pred_list.append(pred_ratings)
    pred_ratings = np.concatenate(pred_list)
    ratings = eval_data[_rkey]
    mae = metrics.mean_absolute_error(ratings, pred_ratings)
    mse = metrics.mean_squared_error(ratings, pred_ratings)
    return mae, mse

  def train(self):
    early_stop = self._args.early_stop
    pretrain_epochs = self._args.pretrain_epochs
    num_batches = self._args.num_batches
    verbose = self._args.verbose
    train_data = self._data.train_data
    valid_data = self._data.valid_data
    test_data = self._data.test_data
    train_size = self._data.train_size

    self.epoch_str = []
    self.valid_mae = []
    self.valid_mse = []
    self.test_mae = []
    self.test_mse = []
    with tf.Session() as sess:
      self.sess = sess
      sess.run(tf.global_variables_initializer())
      start_time = time.time()
      self.start_time = start_time
      for epoch in range(pretrain_epochs):
        batch_size = train_size // num_batches
        for batch in range(num_batches):
          start = batch * batch_size
          stop = (batch + 1) * batch_size
          if (batch + 1) == num_batches:
              stop = train_size
          feed_dict = {self.users: train_data[_ukey][start:stop],
                       self.items: train_data[_ikey][start:stop],
                       self.ratings: train_data[_rkey][start:stop],
                       self.weights: train_data[_wkey][start:stop]}
          sess.run(self.train_op, feed_dict=feed_dict)

        valid_res = self._eval_pred_model(valid_data)
        test_res = self._eval_pred_model(test_data)
        self.valid_mae.append(valid_res[0])
        self.valid_mse.append(valid_res[1])
        self.test_mae.append(test_res[0])
        self.test_mse.append(test_res[1])
        self.epoch_str.append('#%d' % (epoch + 1))
        if verbose > 0 and (epoch + 1) % verbose == 0:
          stop_time = time.time()
          elapse = stop_time - start_time
          f_data = (epoch, valid_res[1], test_res[1], elapse)
          print('#%d valid=%.4f test=%.4f time=%.0fs' % f_data)
        if early_stop and self._is_overfit(self.valid_mse):
          break
      # print('training takes %.2fs' % (elapse))
    args = self._args
    best = self.valid_mse.index(min(self.valid_mse))
    stop_time = time.time()
    elapse = stop_time - start_time
    f_data = (self.epoch_str[best],)
    f_data += (self.test_mae[best], self.test_mse[best],)
    f_data += (elapse, args,)
    print('%s\t%.4f\t%.4f\t%.0fs\t%s' % f_data)

if __name__ == '__main__':
  description = 'Run a single robust model.'
  args = utils.parse_args(description)
  data = Dataset(args)

  model = IpsRec(args, data)
  try:
    model.train()
  except ValueError as e:
    f_data = ('NaN', 'NaN', 'NaN', 'NaN', args)
    best = model.valid_mse.index(min(model.valid_mse))
    stop_time = time.time()
    elapse = stop_time - model.start_time
    f_data = ('crash' + model.epoch_str[best],)
    f_data += (model.test_mae[best], model.test_mse[best],)
    f_data += (elapse, args,)
    print('%s\t%.4f\t%.4f\t%.0fs\t%s' % f_data)

