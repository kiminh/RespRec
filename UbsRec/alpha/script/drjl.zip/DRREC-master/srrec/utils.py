import argparse
import numpy as np
import pandas as pd

log_format = '%(pathname)-16s%(message)s'

_ukey = 'user'
_ikey = 'item'
_rkey = 'rating'
_wkey = 'weight'
_delimiter = ' '
class Dataset(object):
  def __init__(self, args):
    base_dir = args.base_dir
    train_file = base_dir + '.train'
    valid_file = base_dir + '.valid'
    test_file = base_dir + '.test'

    params = {'header': None,
              'delimiter': _delimiter,
              'names': [_rkey, _wkey, _ukey, _ikey,],
              'dtype': {_rkey: np.int32,
                        _wkey: np.float32,
                        _ukey: np.int32,
                        _ikey: np.int32}}

    train_data = pd.read_csv(train_file, **params)
    valid_data = pd.read_csv(valid_file, **params)
    test_data = pd.read_csv(test_file, **params)

    # propensity to weight
    min_weight = args.min_weight
    max_weight = args.max_weight
    train_data[_wkey] = 1.0 / train_data[_wkey]
    train_data[_wkey] = train_data[_wkey].clip(min_weight, max_weight)
    train_data[_wkey] = train_data[_wkey] / train_data[_wkey].min()

    num_users = train_data[_ukey].unique().size
    num_items = train_data[_ikey].unique().size
    train_size = train_data[_rkey].size
    min_rating = train_data[_rkey].min()
    max_rating = train_data[_rkey].max()

    verbose = args.verbose
    if verbose > 0:
      print('num_users=%d' % (num_users))
      print('num_items=%d' % (num_items))
      print('train_size=%d' % (train_size))
      print('min_rating=%d' % (min_rating))
      print('max_rating=%d' % (max_rating))
      print('min_weight=%.4f' % (train_data[_wkey].min()))
      print('max_weight=%.4f' % (train_data[_wkey].max()))

    self.train_data = train_data
    self.valid_data = valid_data
    self.test_data = test_data
    self.num_users = num_users
    self.num_items = num_items
    self.train_size = train_size
    self.min_rating = min_rating
    self.max_rating = max_rating

def parse_args(description):
  parser = argparse.ArgumentParser(description=description)
  parser.add_argument('--base_dir', type=str, default='data/coat/coat')

  parser.add_argument('--pretrain_epochs', type=int, default=100)
  parser.add_argument('--interact_epochs', type=int, default=10)
  parser.add_argument('--num_impt_epochs', type=int, default=20)
  parser.add_argument('--num_mis_epochs', type=int, default=10)
  parser.add_argument('--num_obs_epochs', type=int, default=10)
  parser.add_argument('--pred_learning_rate', type=float, default=0.005)
  parser.add_argument('--impt_learning_rate', type=float, default=0.01)
  parser.add_argument('--pred_model_name', default='fm', help='nfm|fm')
  parser.add_argument('--impt_model_name', default='fm', help='nfm|fm')
  parser.add_argument('--pred_include_bias', type=int, default=0, help='0|1')
  parser.add_argument('--impt_include_bias', type=int, default=0, help='0|1')

  parser.add_argument('--verbose', type=int, default=0, help='1,...')
  parser.add_argument('--early_stop', type=int, default=1, help='0|1')
  parser.add_argument('--max_early_stop', type=int, default=50, help='1,...')

  parser.add_argument('--all_reg_coeff', type=float, default=0.001)
  parser.add_argument('--batch_norm', type=int, default=0, help='0|1')
  parser.add_argument('--batch_size', type=int, default=32)
  parser.add_argument('--num_batches', type=int, default=10)
  parser.add_argument('--num_factors', type=int, default=128)
  parser.add_argument('--keep_probs', type=str, default='[0.2,0.5]')
  parser.add_argument('--layer_sizes', type=str, default='[]')
  parser.add_argument('--activation_func', default='relu',
                 help='identity|relu|sigmoid|tanh')
  parser.add_argument('--optimizer_type', default='adagrad',
                 help='adagrad|adam|sgd|rmsprop')

  # naive error imputation
  parser.add_argument('--impt_rating', type=float, default=0.0)
  parser.add_argument('--impt_weight', type=float, default=0.0)
  # inverse propensity scoring
  parser.add_argument('--min_weight', type=float, default=1.0)
  parser.add_argument('--max_weight', type=float, default=0.0)

  return parser.parse_args()
